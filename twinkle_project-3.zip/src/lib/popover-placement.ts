export interface PopoverSize {
  width: number;
  height?: number;
}
export interface PopoverPlacement {
  left: number;
  top: number;
}

function rectOf(selector: string): DOMRect | null {
  try {
    const el = document.querySelector(selector) as HTMLElement | null;
    if (!el || el.offsetParent === null) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return null;
    return r;
  } catch {
    return null;
  }
}

/**
 * Topbar property menus must never cover the left rail, the tools panel,
 * or the canvas paper itself. They dock in the stage gutter *between* the
 * panel's right edge and the paper's left edge (the only free lane), falling
 * back to the right gutter and finally below the canvas.
 */
export function sidePopoverPlacement(anchor: DOMRect, size: PopoverSize, prefer: "left" | "right" = "left", options?: { gap?: number; margin?: number }): PopoverPlacement {
  const gap = options?.gap ?? 8, margin = options?.margin ?? 10;
  const viewportWidth = window.innerWidth, viewportHeight = window.innerHeight;

  const rail = rectOf(".editor-rail");
  const panel = rectOf(".editor-panel");
  const stage = rectOf(".editor-stage");
  const paper = rectOf(".canvas-paper");

  // Panel is a left sidebar only on wide layouts; on phones it becomes a
  // bottom sheet and must not steal the horizontal lane.
  const panelIsSide = !!panel && panel.height > viewportHeight * 0.5 && panel.left < viewportWidth * 0.5 && panel.width > 60 && panel.width < viewportWidth * 0.6;
  const railRight = rail ? rail.right : 0;
  const panelRight = panelIsSide ? panel.right : railRight;
  const stageLeft = stage ? stage.left : panelRight;
  const stageRight = stage ? stage.right : viewportWidth;
  const laneLeft = Math.max(panelRight + gap, stageLeft + gap, margin);
  const laneRight = paper ? paper.left - gap : stageRight - gap;

  const belowAnchor = anchor.bottom + gap;
  const clampLeft = (v: number) => Math.max(margin, Math.min(v, viewportWidth - size.width - margin));
  const clampTop = (v: number, h: number) => Math.max(margin, Math.min(v, viewportHeight - h - margin));

  const estHeight = Math.min(size.height ?? 320, viewportHeight - belowAnchor - margin, 560);

  // 1) Ideal lane: between panel and paper, just below the topbar.
  const laneWidth = laneRight - laneLeft;
  if (laneWidth >= size.width) {
    const left = clampLeft(Math.min(Math.max(anchor.left, laneLeft), laneRight - size.width));
    return { left, top: clampTop(belowAnchor, estHeight) };
  }

  // 2) Right gutter: between paper and stage edge.
  if (paper && stage) {
    const rightLaneLeft = paper.right + gap;
    const rightLaneRight = stage.right - gap;
    if (rightLaneRight - rightLaneLeft >= size.width) {
      const left = clampLeft(Math.min(Math.max(anchor.left, rightLaneLeft), rightLaneRight - size.width));
      return { left, top: clampTop(belowAnchor, estHeight) };
    }
    // 3) Below the canvas: full stage width, never over the paper.
    const belowPaper = paper.bottom + gap;
    if (viewportHeight - belowPaper - margin >= Math.min(estHeight, 220)) {
      const left = clampLeft(Math.min(Math.max(anchor.left, stage.left + gap), stage.right - size.width - gap));
      return { left, top: clampTop(belowPaper, estHeight) };
    }
  }

  // 4) Fallback: below the anchor, hard-clamped off the rail + panel,
  // and nudged out from under the paper when they overlap.
  let left = clampLeft(anchor.left);
  left = Math.max(left, laneLeft);
  if (paper && left + size.width > paper.left && left < paper.right && belowAnchor < paper.bottom) {
    // Push to whichever side of the paper has more room.
    const roomLeft = paper.left - gap - laneLeft;
    const roomRight = (stage ? stage.right - gap : viewportWidth - margin) - (paper.right + gap);
    if (roomRight >= roomLeft && paper.right + gap + size.width <= viewportWidth - margin) left = paper.right + gap;
    else if (roomLeft >= size.width) left = Math.max(laneLeft, paper.left - gap - size.width);
    else left = clampLeft(left);
  }
  void prefer;
  return { left, top: clampTop(belowAnchor, estHeight) };
}

/** Panels that logically belong beside an anchor rather than above the canvas. */
export function useSidePlacement() {
  return sidePopoverPlacement;
}
