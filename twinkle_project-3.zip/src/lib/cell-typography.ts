import type { DesignLayer } from "@/lib/designs";

export interface CellTextStyle {
  fontSize?: number;
  fontFamily?: string;
  fontWeight?: number;
  italic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  align?: "left" | "center" | "right";
  verticalAlign?: "top" | "middle" | "bottom";
  lineHeight?: number;
  letterSpacing?: number;
}
export const cellTextKeys: (keyof CellTextStyle)[] = ["fontSize", "fontFamily", "fontWeight", "italic", "underline", "strikethrough", "align", "verticalAlign", "lineHeight", "letterSpacing"];
export function cellTextOverrides(patch: Partial<DesignLayer> & CellTextStyle): CellTextStyle {
  const result: Record<string, unknown> = {};
  for (const key of cellTextKeys) if (patch[key] !== undefined) result[key] = patch[key];
  return result as CellTextStyle;
}
export function isCellTextStyle(value: unknown): value is CellTextStyle {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const v = value as CellTextStyle;
  const n = (value: unknown, lo: number, hi: number) => typeof value === "number" && Number.isFinite(value) && value >= lo && value <= hi;
  if (Object.keys(v).some(key => !cellTextKeys.includes(key as keyof CellTextStyle))) return false;
  if (v.fontSize !== undefined && !n(v.fontSize, 1, 1000)) return false;
  if (v.fontFamily !== undefined && !["Arial", "Georgia", "Verdana", "Courier New"].includes(v.fontFamily)) return false;
  if (v.fontWeight !== undefined && !n(v.fontWeight, 100, 900)) return false;
  for (const key of ["italic", "underline", "strikethrough"] as const) if (v[key] !== undefined && typeof v[key] !== "boolean") return false;
  if (v.align !== undefined && !["left", "center", "right"].includes(v.align)) return false;
  if (v.verticalAlign !== undefined && !["top", "middle", "bottom"].includes(v.verticalAlign)) return false;
  if (v.lineHeight !== undefined && !n(v.lineHeight, .8, 3)) return false;
  if (v.letterSpacing !== undefined && !n(v.letterSpacing, -100, 1000)) return false;
  return true;
}
