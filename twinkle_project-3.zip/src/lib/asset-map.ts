/**
 * Bundled image assets. Designs store short logical paths (e.g. "/images/coast.jpg")
 * so saved documents stay small; this map resolves them to the served URLs at render time.
 *
 * Ported to Next.js: the SVGs live in /public/images, so the map is a plain
 * logical-path → public-URL lookup (no bundler asset imports needed).
 */
const assetMap: Record<string, string> = {
  "/images/interior.jpg": "/images/interior.svg",
  "/images/coast.jpg": "/images/coast.svg",
  "/images/skincare.jpg": "/images/skincare.svg",
  "/images/photos/flowers.jpg": "/images/photos/flowers.svg",
  "/images/photos/meadow.jpg": "/images/photos/meadow.svg",
  "/images/photos/cosmos.jpg": "/images/photos/cosmos.svg",
  "/images/photos/coffee.jpg": "/images/photos/coffee.svg",
  "/images/photos/desk.jpg": "/images/photos/desk.svg",
  "/images/photos/notebook.jpg": "/images/photos/notebook.svg",
  "/images/photos/lake.jpg": "/images/photos/lake.svg",
  "/images/photos/alpine.jpg": "/images/photos/alpine.svg",
  "/images/photos/valley.jpg": "/images/photos/valley.svg",
  "/images/photos/gradient-paper.jpg": "/images/photos/gradient-paper.svg",
  "/images/photos/pastel-paper.jpg": "/images/photos/pastel-paper.svg",
  "/images/photos/blush-paper.jpg": "/images/photos/blush-paper.svg",
};

/** Resolves a stored image path (or data URL) to something the browser can load. */
export function resolveAsset(src?: string | null): string {
  if (!src) return "";
  return assetMap[src] ?? src;
}
