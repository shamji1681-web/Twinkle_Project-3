export interface HSV { h: number; s: number; v: number }
export interface RGB { r: number; g: number; b: number }

const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));

export function hexToRgb(hex: string): RGB {
  let h = hex.replace("#", "");
  if (h.length === 3 || h.length === 4) h = [...h.slice(0, 3)].map(c => c + c).join("");
  const n = parseInt(h.slice(0, 6), 16);
  if (Number.isNaN(n)) return { r: 0, g: 0, b: 0 };
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function rgbToHex({ r, g, b }: RGB) {
  return "#" + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0")).join("");
}

export function rgbToHsv({ r, g, b }: RGB): HSV {
  const rn = r / 255, gn = g / 255, bn = b / 255;
  const max = Math.max(rn, gn, bn), min = Math.min(rn, gn, bn), d = max - min;
  let h = 0;
  if (d) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s: max ? d / max : 0, v: max };
}

export function hsvToRgb({ h, s, v }: HSV): RGB {
  const c = v * s, x = c * (1 - Math.abs(((h / 60) % 2) - 1)), m = v - c;
  let r = 0, g = 0, b = 0;
  if (h < 60) [r, g, b] = [c, x, 0];
  else if (h < 120) [r, g, b] = [x, c, 0];
  else if (h < 180) [r, g, b] = [0, c, x];
  else if (h < 240) [r, g, b] = [0, x, c];
  else if (h < 300) [r, g, b] = [x, 0, c];
  else [r, g, b] = [c, 0, x];
  return { r: (r + m) * 255, g: (g + m) * 255, b: (b + m) * 255 };
}

export const hexToHsv = (hex: string) => rgbToHsv(hexToRgb(hex));
export const hsvToHex = (hsv: HSV) => rgbToHex(hsvToRgb(hsv));
export const isHex = (value: string) => /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value);

/** Parses "#rrggbb", "#rgb", or bare "rrggbb"; returns null when unusable. */
export function parseHexInput(value: string): string | null {
  const v = value.trim().replace(/^#?/, "#");
  return isHex(v) ? (v.length === 4 ? "#" + [...v.slice(1)].map(c => c + c).join("") : v).toLowerCase() : null;
}

/**
 * Solid-colour swatch grid for the fill picker, sampled from the reference palette.
 * Row-major in an 8-column grid: 4 rows × 8 columns, in the order shown.
 */
export const PRESET_SWATCHES = [
  "#000000", "#000066", "#663399", "#29abe2", "#990000", "#003333", "#cc3366", "#ffcc00",
  "#808080", "#003399", "#9900cc", "#5b9bd5", "#cc3300", "#009900", "#ff0066", "#ffff00",
  "#e0e0e0", "#0000ff", "#cc00ff", "#00ccff", "#ff0000", "#33cc33", "#ff3399", "#ffff66",
  "#ffffff", "#6666ff", "#cc66ff", "#99ffff", "#ff6600", "#99cc33", "#ff99ff", "#ffffcc",
];
