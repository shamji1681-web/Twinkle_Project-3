/**
 * Subscript / superscript for the *highlighted* words inside a text box.
 *
 * Selections are stored as offset ranges on the layer; the canvas renders those
 * spans as smaller, baseline-shifted glyphs (true H₂O / x² for every character).
 * Ranges follow their words while typing and travel with saving and export.
 */

export type ScriptKind = "sub" | "super";

/** One formatted span inside a text box. Offsets are UTF-16 units (match textarea selection). */
export interface ScriptRange { start: number; end: number; kind: ScriptKind }

const MAX_RANGES = 200;

/** Normalizes ranges: clamped, ordered, non-empty, non-overlapping (first wins). */
export function normalizeRanges(text: string, ranges: ScriptRange[]): ScriptRange[] {
  const len = (text || "").length;
  const clean = ranges
    .filter(r => r && Number.isInteger(r.start) && Number.isInteger(r.end))
    .map(r => ({ start: Math.max(0, Math.min(len, r.start)), end: Math.max(0, Math.min(len, r.end)), kind: r.kind }))
    .filter(r => r.start < r.end && (r.kind === "sub" || r.kind === "super"))
    .sort((a, b) => a.start - b.start || a.end - b.end)
    .slice(0, MAX_RANGES);
  const out: ScriptRange[] = [];
  for (const r of clean) {
    const last = out[out.length - 1];
    if (last && r.start < last.end) {
      // Overlap: trim the new range to start where the previous one ends.
      if (r.end > last.end) out.push({ start: last.end, end: r.end, kind: r.kind });
    } else out.push(r);
  }
  return out;
}

/** Sets or clears a script range over [start, end) without toggling. */
export function setScriptRange(text: string, ranges: ScriptRange[] | undefined, start: number, end: number, kind: ScriptKind | null): ScriptRange[] {
  const len = (text || "").length;
  const s = Math.max(0, Math.min(len, Math.min(start, end)));
  const e = Math.max(0, Math.min(len, Math.max(start, end)));
  const current = normalizeRanges(text, ranges || []);
  if (s >= e) return current;
  const kept = current.filter(r => r.end <= s || r.start >= e);
  if (!kind) return normalizeRanges(text, kept);
  return normalizeRanges(text, [...kept, { start: s, end: e, kind }]);
}

/**
 * Toggles a script range over [start, end): fully-covered selections are restored
 * to plain text, otherwise the span becomes sub/superscript (clearing overlaps).
 */
export function toggleScriptRange(text: string, ranges: ScriptRange[] | undefined, start: number, end: number, kind: ScriptKind): ScriptRange[] {
  const len = (text || "").length;
  const s = Math.max(0, Math.min(len, Math.min(start, end)));
  const e = Math.max(0, Math.min(len, Math.max(start, end)));
  if (s >= e) return normalizeRanges(text, ranges || []);
  const current = normalizeRanges(text, ranges || []);
  // Toggle rule: if every char in [s,e) already carries this kind, clear it.
  let fully = true;
  for (let i = s; i < e; i++) {
    if (!current.some(r => r.kind === kind && r.start <= i && r.end > i)) { fully = false; break; }
  }
  const kept = current.filter(r => r.end <= s || r.start >= e);
  if (fully) return kept;
  return normalizeRanges(text, [...kept, { start: s, end: e, kind }]);
}

/**
 * Keeps ranges attached to the right words while typing: diffs old→new text with a
 * common prefix/suffix, shifts ranges after the edit, drops ranges inside it.
 */
export function shiftScriptRanges(oldText: string, newText: string, ranges: ScriptRange[] | undefined): ScriptRange[] | undefined {
  if (!ranges?.length) return ranges?.length ? ranges : undefined;
  const a = oldText || "", b = newText || "";
  if (a === b) return ranges;
  let prefix = 0;
  while (prefix < a.length && prefix < b.length && a[prefix] === b[prefix]) prefix++;
  let suffix = 0;
  while (suffix < a.length - prefix && suffix < b.length - prefix && a[a.length - 1 - suffix] === b[b.length - 1 - suffix]) suffix++;
  const oldCut = a.length - suffix;
  const delta = b.length - a.length;
  const out: ScriptRange[] = [];
  for (const r of ranges) {
    if (r.end <= prefix) out.push({ ...r });
    else if (r.start >= oldCut) out.push({ start: r.start + delta, end: r.end + delta, kind: r.kind });
    // Ranges touching the edited middle are dropped — their words changed.
  }
  const clean = normalizeRanges(b, out);
  return clean.length ? clean : undefined;
}
