import type { DesignLayer } from "@/lib/designs";

let context: CanvasRenderingContext2D | null | undefined;

function measurer() {
  if (context === undefined) {
    if (typeof document === "undefined") context = null;
    else context = document.createElement("canvas").getContext("2d");
  }
  return context;
}

export const LINE_HEIGHT = 1.13;
/** SVG puts the first baseline 0.83em below the box top; every row shares that grid. */
export const FIRST_BASELINE = 0.83;
/**
 * Microsoft Word's subscript / superscript defaults (Font ▸ Advanced):
 * the run is set at 65% of the parent size and its baseline is offset by 33%
 * (superscript) or 25% (subscript) of the parent font size.
 */
export const SCRIPT_SIZE = 65;
export const SCRIPT_SUPER_OFFSET = 33;
export const SCRIPT_SUB_OFFSET = 25;
/** Cap height as a share of the em — used to span a drop cap across N lines. */
const CAP_HEIGHT = 0.7;

export type RunKind = "sub" | "super" | null;

export const fontSizeOf = (layer: Pick<DesignLayer, "fontSize">) => layer.fontSize || 40;
export const textLineHeight = (layer: Pick<DesignLayer, "lineHeight">) => layer.lineHeight ?? LINE_HEIGHT;

export interface ScriptMetrics { size: number; super: number; sub: number }

/** Word's Size / Offset percentages for sub and superscript runs. */
export function scriptMetricsOf(layer: Pick<DesignLayer, "scriptSize" | "scriptShift">): ScriptMetrics {
  const size = Math.max(20, Math.min(100, layer.scriptSize ?? SCRIPT_SIZE)) / 100;
  const shift = Math.max(0, Math.min(400, layer.scriptShift ?? 100)) / 100;
  return { size, super: (SCRIPT_SUPER_OFFSET / 100) * shift, sub: (SCRIPT_SUB_OFFSET / 100) * shift };
}

/** A whole-box script keeps the line grid and only shrinks the glyphs (Word's 65%). */
export function scriptScaleOf(layer: Pick<DesignLayer, "script" | "scriptSize" | "scriptShift">) {
  return layer.script ? scriptMetricsOf(layer).size : 1;
}

/**
 * Vertical headroom sub / superscript runs need so no glyph ever paints
 * outside the selection frame. Word grows the frame the same way: superscript
 * rises above the first baseline (top pad), subscript sinks below the last
 * one (bottom pad). Fractions come along since they are script runs too.
 */
export function scriptPadsOf(layer: DesignLayer): { top: number; bottom: number } {
  const base = fontSizeOf(layer);
  const metrics = scriptMetricsOf(layer);
  const hasSuper = layer.script === "super" || !!layer.scriptRanges?.some(r => r.kind === "super");
  const hasSub = layer.script === "sub" || !!layer.scriptRanges?.some(r => r.kind === "sub");
  return {
    top: hasSuper ? Math.ceil(metrics.super * base + base * 0.15) : 0,
    bottom: hasSub ? Math.ceil(metrics.sub * base + base * 0.15) : 0,
  };
}

export function segSizeOf(layer: DesignLayer, kind: RunKind) {
  return fontSizeOf(layer) * (kind ? scriptMetricsOf(layer).size : scriptScaleOf(layer));
}

/** Baseline offset for a run: Word raises superscripts and sinks subscripts. */
export function segShiftOf(layer: DesignLayer, kind: RunKind) {
  const metrics = scriptMetricsOf(layer);
  const base = fontSizeOf(layer);
  if (kind === "super" || (!kind && layer.script === "super")) return -metrics.super * base;
  if (kind === "sub" || (!kind && layer.script === "sub")) return metrics.sub * base;
  return 0;
}

function fontFor(size: number, layer: DesignLayer, customFont?: string) {
  const fam = customFont || layer.fontFamily || "Arial";
  return `${layer.italic ? "italic " : ""}${layer.fontWeight || 400} ${size}px ${fam}, Arial, sans-serif`;
}

export function measureAt(layer: DesignLayer, value: string, size: number, customFont?: string) {
  const target = measurer();
  const spacing = layer.letterSpacing || 0;
  if (target) {
    target.font = fontFor(size, layer, customFont);
    return Math.max(0, target.measureText(value).width + Math.max(0, Array.from(value).length - 1) * spacing);
  }
  return Math.max(6, value.length) * size * 0.58;
}

/** Measures one string at the size the layer actually renders it. */
function measureString(layer: DesignLayer, value: string) {
  return measureAt(layer, value, segSizeOf(layer, null));
}

/** Public measurer for render decisions (e.g. spacing that has to fill a gap). */
export function measureTextWidth(layer: DesignLayer, value: string) {
  return measureString(layer, value);
}

export interface Seg { text: string; kind: RunKind }

/** Width of a run list whose parts may sit at different sizes (sub / superscript). */
export function measureSegs(layer: DesignLayer, segs: Seg[]) {
  return segs.reduce((total, seg) => total + (seg.text ? measureAt(layer, seg.text, segSizeOf(layer, seg.kind)) : 0), 0);
}

/** Measures a slice of a paragraph with its script ranges applied. */
export function measureSpans(layer: DesignLayer, text: string, start: number, ranges?: DesignLayer["scriptRanges"]) {
  return measureSegs(layer, segmentRow(text, start, ranges));
}

/**
 * Narrowest safe text frame. A frame may become a one-character column, but it
 * must never become narrower than its widest rendered glyph (or its list/drop-cap
 * indent), otherwise SVG paints that glyph outside the selection frame.
 */
export function minimumTextWidth(layer: DesignLayer): number {
  const value = layer.text || "";
  const base = fontSizeOf(layer);
  let widest = Math.max(8, measureAt(layer, "M", segSizeOf(layer, null)));
  let offset = 0;
  for (const char of Array.from(value)) {
    widest = Math.max(widest, measureSpans(layer, char, offset, layer.scriptRanges));
    offset += char.length;
  }
  const listIndent = layer.listStyle && layer.listStyle !== "none" ? base * 1.15 : 0;
  const dropIndent = layer.dropCap ? dropCapIndentOf(layer) : 0;
  return Math.ceil(Math.max(8, widest + Math.max(1, layer.letterSpacing || 0), listIndent + widest, dropIndent + widest));
}

/** Measures each explicit (\n-separated) line so an auto-fit box can hug the widest one. */
export function measureTextLines(layer: DesignLayer) {
  return (layer.text || "").split("\n").map(line => measureString(layer, line || " "));
}

interface WrapFont { fontSize?: number; fontFamily?: string; fontWeight?: number; italic?: boolean; letterSpacing?: number }

/** Wraps a single string for an explicit font, used for table cells and other non-layer text. */
export function wrapString(value: string, maxWidth: number, font: WrapFont): string[] {
  const pseudo: DesignLayer = { id: "wrap", type: "text", x: 0, y: 0, width: maxWidth, height: font.fontSize || 40, fill: "#000", ...font };
  const limit = Math.max(1, maxWidth);
  const lines: string[] = [];
  for (const paragraph of (value || "").split("\n")) {
    if (paragraph === "") { lines.push(""); continue; }
    const words = paragraph.split(" ");
    let current = "";
    const breakWord = (word: string) => {
      let chunk = "";
      for (const char of Array.from(word)) {
        if (chunk && measureString(pseudo, chunk + char) > limit) { lines.push(chunk); chunk = char; }
        else chunk += char;
      }
      return chunk;
    };
    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (measureString(pseudo, candidate) <= limit || !current) {
        if (!current && measureString(pseudo, word) > limit) current = breakWord(word);
        else current = candidate;
      } else {
        lines.push(current);
        current = measureString(pseudo, word) > limit ? breakWord(word) : word;
      }
    }
    lines.push(current);
  }
  return lines.length ? lines : [""];
}

export type ListStyleKey = NonNullable<DesignLayer["listStyle"]>;
export const LIST_STYLES: { key: ListStyleKey; name: string; mark: string }[] = [
  { key: "none", name: "None", mark: "" },
  { key: "bullet", name: "Bullets", mark: "•" },
  { key: "number", name: "Numbered", mark: "1." },
  { key: "dash", name: "Dash", mark: "–" },
  { key: "arrow", name: "Arrow", mark: "→" },
  { key: "check", name: "Check", mark: "✓" },
  { key: "star", name: "Star", mark: "★" },
  { key: "diamond", name: "Diamond", mark: "◆" },
];

export const BULLET_VARIANTS = [
  { key: "bullet", name: "Solid Disc", mark: "•" },
  { key: "circle", name: "Hollow Circle", mark: "◦" },
  { key: "square", name: "Filled Square", mark: "▪" },
  { key: "check", name: "Checkmark", mark: "✓" },
  { key: "arrow", name: "Right Arrow", mark: "→" },
  { key: "diamond", name: "Diamond", mark: "◆" },
  { key: "star", name: "Star", mark: "★" },
  { key: "dash", name: "En Dash", mark: "–" },
] as const;

export const NUMBER_FORMATS = [
  { key: "number", name: "1. 2. 3.", sample: "1." },
  { key: "number-paren", name: "1) 2) 3)", sample: "1)" },
  { key: "alpha-lower", name: "a. b. c.", sample: "a." },
  { key: "alpha-lower-paren", name: "a) b) c)", sample: "a)" },
  { key: "alpha-upper", name: "A. B. C.", sample: "A." },
  { key: "roman-lower", name: "i. ii. iii.", sample: "i." },
  { key: "roman-upper", name: "I. II. III.", sample: "I." },
] as const;

const ROMAN_LOWER = ["i", "ii", "iii", "iv", "v", "vi", "vii", "viii", "ix", "x", "xi", "xii", "xiii", "xiv", "xv", "xvi", "xvii", "xviii", "xix", "xx"];
const ROMAN_UPPER = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII", "XIII", "XIV", "XV", "XVI", "XVII", "XVIII", "XIX", "XX"];
const ALPHA_LOWER = "abcdefghijklmnopqrstuvwxyz";
const ALPHA_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

function formatNumber(format: NonNullable<DesignLayer["listNumberFormat"]> | undefined, num: number): string {
  const n = Math.max(1, num);
  switch (format) {
    case "number-paren": return `${n})`;
    case "alpha-lower": return `${ALPHA_LOWER[(n - 1) % ALPHA_LOWER.length]}.`;
    case "alpha-lower-paren": return `${ALPHA_LOWER[(n - 1) % ALPHA_LOWER.length]})`;
    case "alpha-upper": return `${ALPHA_UPPER[(n - 1) % ALPHA_UPPER.length]}.`;
    case "roman-lower": return `${ROMAN_LOWER[(n - 1) % ROMAN_LOWER.length]}.`;
    case "roman-upper": return `${ROMAN_UPPER[(n - 1) % ROMAN_UPPER.length]}.`;
    case "number":
    default:
      return `${n}.`;
  }
}

/**
 * Word's multilevel list logic:
 * Level 0 uses the chosen listNumberFormat / listBulletVariant.
 * Deeper levels step cleanly through 1. -> a. -> i. -> 1) -> a) -> i)
 * and bullets step through • -> ◦ -> ▪ -> ◆ -> →
 */
export function listMarker(layer: DesignLayer, style: ListStyleKey, level: number, index: number): string {
  if (!style || style === "none") return "";
  const lvl = Math.max(0, Math.round(level));
  if (style === "number") {
    const baseFormat = layer.listNumberFormat || "number";
    if (lvl === 0) return formatNumber(baseFormat, index);
    if (lvl === 1) return `${ALPHA_LOWER[(index - 1) % ALPHA_LOWER.length]}.`;
    if (lvl === 2) return `${ROMAN_LOWER[(index - 1) % ROMAN_LOWER.length]}.`;
    if (lvl === 3) return `${index})`;
    if (lvl === 4) return `${ALPHA_LOWER[(index - 1) % ALPHA_LOWER.length]})`;
    return `${ROMAN_LOWER[(index - 1) % ROMAN_LOWER.length]})`;
  }
  if (style === "bullet") {
    const chosen = layer.listBulletVariant || "bullet";
    const bullets = [
      BULLET_VARIANTS.find(b => b.key === chosen)?.mark || "•",
      "◦",
      "▪",
      "◆",
      "→",
      "✓",
      "★",
      "–",
    ];
    return bullets[lvl % bullets.length];
  }
  const found = LIST_STYLES.find(item => item.key === style);
  return found ? found.mark : "";
}

export const clampLevel = (value: number | undefined) => Math.max(0, Math.min(8, Math.round(value ?? 0)));

/** A display line: its list marker, its words split into sub/superscript runs, and its frame. */
export interface ListedLine {
  marker: string;
  text: string;
  segs: Seg[];
  /** Left edge of this row's text column in layer space (marker column + drop cap + firstLineIndent). */
  indent: number;
  /** Where the paragraph marker is drawn (Word's hanging indent leaves it in its own column). */
  markerX: number;
  /** Last row of its paragraph — CorelDRAW's "Full justify" leaves that row at natural width. */
  end: boolean;
  /** Word outline level of the paragraph (Tab demotes, Shift+Tab promotes). */
  level: number;
  /** Index of the paragraph this line belongs to. */
  paraIndex: number;
  /** True if this is the very first visual row of its paragraph. */
  isFirstParaRow: boolean;
}

/** Splits a row's text into plain / script segments from the layer's script ranges. */
function segmentRow(text: string, rowStart: number, ranges: Array<{ start: number; end: number; kind: "sub" | "super" }> | undefined): Seg[] {
  if (!text || !ranges?.length) return [{ text, kind: null }];
  const rowEnd = rowStart + text.length;
  const hits = ranges
    .map(r => ({ start: Math.max(r.start, rowStart), end: Math.min(r.end, rowEnd), kind: r.kind }))
    .filter(r => r.start < r.end)
    .sort((a, b) => a.start - b.start);
  if (!hits.length) return [{ text, kind: null }];
  const segs: Seg[] = [];
  let pos = rowStart;
  for (const h of hits) {
    if (h.start > pos) segs.push({ text: text.slice(pos - rowStart, h.start - rowStart), kind: null });
    segs.push({ text: text.slice(Math.max(h.start, pos) - rowStart, h.end - rowStart), kind: h.kind });
    pos = Math.max(pos, h.end);
  }
  if (pos < rowEnd) segs.push({ text: text.slice(pos - rowStart), kind: null });
  return segs.filter(s => s.text);
}

interface WrapRow { text: string; start: number; end: number }

/**
 * Greedy word wrap that tracks UTF-16 offsets so inline script ranges land on the right
 * rows. Each row may use a different width, which is how a drop cap and first-line indent
 * narrow their wrap.
 */
function wrapRich(layer: DesignLayer, paragraph: string, paraStart: number, limitAt: (row: number) => number, ranges?: DesignLayer["scriptRanges"]): WrapRow[] {
  const rows: WrapRow[] = [];
  if (paragraph === "") { rows.push({ text: "", start: paraStart, end: paraStart }); return rows; }
  const width = (value: string, start: number) => measureSpans(layer, value, start, ranges);
  // Word offsets in UTF-16 units (split keeps empty runs, exactly like wrapText).
  const words = paragraph.split(" ");
  const starts: number[] = [];
  let cursor = 0;
  for (const word of words) { starts.push(cursor); cursor += word.length + 1; }
  const pushBrokenWord = (word: string, wordStart: number) => {
    let chunk = "", chunkStart = wordStart;
    for (const char of Array.from(word)) {
      if (chunk && width(chunk + char, paraStart + chunkStart) > limitAt(rows.length)) {
        rows.push({ text: chunk, start: paraStart + chunkStart, end: paraStart + chunkStart + chunk.length });
        chunkStart += chunk.length;
        chunk = char;
      } else chunk += char;
    }
    return { chunk, chunkStart };
  };
  let current = "", curStart = 0, curEnd = 0, hasCurrent = false;
  for (let wi = 0; wi < words.length; wi++) {
    const word = words[wi], wordStart = starts[wi];
    const candidate = current ? `${current} ${word}` : word;
    const candStart = current ? curStart : wordStart;
    if (width(candidate, paraStart + candStart) <= limitAt(rows.length) || !current) {
      if (!current && width(word, paraStart + wordStart) > limitAt(rows.length)) {
        const { chunk, chunkStart } = pushBrokenWord(word, wordStart);
        current = chunk; curStart = chunkStart; curEnd = chunkStart + chunk.length; hasCurrent = true;
      } else { current = candidate; curStart = candStart; curEnd = wordStart + word.length; hasCurrent = true; }
    } else {
      rows.push({ text: current, start: paraStart + curStart, end: paraStart + curEnd });
      if (width(word, paraStart + wordStart) > limitAt(rows.length)) {
        const { chunk, chunkStart } = pushBrokenWord(word, wordStart);
        current = chunk; curStart = chunkStart; curEnd = chunkStart + chunk.length;
      } else { current = word; curStart = wordStart; curEnd = wordStart + word.length; }
      hasCurrent = true;
    }
  }
  if (hasCurrent || !rows.length) rows.push({ text: current, start: paraStart + curStart, end: paraStart + curEnd });
  return rows;
}

/** Wraps the text into visual lines that each fit within maxWidth, breaking on words (then characters). */
export function wrapText(layer: DesignLayer, maxWidth: number): string[] {
  const limit = Math.max(1, maxWidth);
  const lines: string[] = [];
  for (const paragraph of (layer.text || "").split("\n")) {
    if (paragraph === "") { lines.push(""); continue; }
    const words = paragraph.split(" ");
    let current = "";
    const pushBrokenWord = (word: string) => {
      let chunk = "";
      for (const char of Array.from(word)) {
        if (chunk && measureString(layer, chunk + char) > limit) { lines.push(chunk); chunk = char; }
        else chunk += char;
      }
      return chunk;
    };
    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (measureString(layer, candidate) <= limit || !current) {
        if (!current && measureString(layer, word) > limit) current = pushBrokenWord(word);
        else current = candidate;
      } else {
        lines.push(current);
        current = measureString(layer, word) > limit ? pushBrokenWord(word) : word;
      }
    }
    lines.push(current);
  }
  return lines.length ? lines : [""];
}

/** The rendered lines for a layer: wrapped to its width when fixed-width, else split on newlines. */
export function renderedLines(layer: DesignLayer): string[] {
  return layer.autoFit === false ? wrapText(layer, layer.width) : (layer.text || "").split("\n");
}

/**
 * Word's Drop Cap: the paragraph's opening letter is set N lines tall, its cap top aligned
 * with the first line and its baseline with the Nth — so the letter spans exactly N rows and
 * the first N rows wrap beside it. "In margin" parks the letter outside the text column.
 */
export interface DropCapLayout {
  char: string;
  lines: number;
  size: number;
  font: string;
  fill: string;
  /** Glyph advance at `size`, gap included. */
  width: number;
  gap: number;
  /** How far the wrapped rows shift right (0 in margin mode). */
  indent: number;
  /** Left edge of the letter in layer space. */
  x: number;
  /** Baseline of the letter: the baseline of the Nth row. */
  baseline: number;
}

export function dropCapLayout(layer: DesignLayer): DropCapLayout | null {
  if (!layer.dropCap) return null;
  const chars = Array.from(layer.text || "");
  const char = chars[0];
  if (!char || !char.trim()) return null;
  const base = fontSizeOf(layer);
  const run = segSizeOf(layer, null);
  const rowH = base * textLineHeight(layer);
  const lines = Math.max(2, Math.min(10, Math.round(layer.dropCapLines ?? 3)));
  const size = run + ((lines - 1) * rowH) / CAP_HEIGHT;
  const gap = Math.max(0, layer.dropCapGap ?? 0);
  const font = layer.dropCapFont || layer.fontFamily || "Arial";
  const fill = layer.dropCapFill || layer.fill;
  // The capital always stays inside the frame (classic Word "Dropped");
  // margin mode is treated as a normal dropped cap so nothing paints outside
  // the selection box.
  const advance = measureAt(layer, char, size, font);
  return {
    char,
    lines,
    size,
    font,
    fill,
    gap,
    width: advance + gap,
    indent: advance + gap,
    x: 0,
    baseline: base * FIRST_BASELINE + (lines - 1) * rowH,
  };
}

/** Horizontal room a drop cap reserves (matches the canvas indent exactly). */
export function dropCapIndentOf(layer: DesignLayer) {
  return dropCapLayout(layer)?.indent ?? 0;
}

/** Only left-flavoured frames wrap around a drop cap (CorelDRAW's frame edge is the left one). */
export function dropCapWraps(layer: DesignLayer) {
  const align = layer.align || "left";
  return align === "left" || align === "justify" || align === "justify-all";
}

/**
 * Display-ready rows with list markers, hanging indents, first line indents and drop cap wrap applied.
 * Every paragraph gets its own marker; wrapped continuations simply share the indent,
 * exactly like Word's hanging indent.
 */
export function listedLines(layer: DesignLayer, maxWidth?: number): ListedLine[] {
  const style = layer.listStyle || "none";
  const listOn = style !== "none";
  const fixed = layer.autoFit === false;
  const boxWidth = Math.max(1, maxWidth ?? layer.width);
  const paragraphs = (layer.text || "").split("\n");
  const ranges = layer.scriptRanges;
  const drop = layer.dropCap ? dropCapLayout(layer) : null;
  const dropIndent = drop && dropCapWraps(layer) ? drop.indent : 0;
  const dropRows = dropIndent > 0 && drop ? drop.lines : 0;
  const firstLineIndent = layer.firstLineIndent || 0;

  const levels = paragraphs.map((_, i) => clampLevel(layer.paraLevels?.[i]));
  // Numbering counts paragraphs per level and restarts a deeper level when its parent moves on.
  const startNum = Math.max(1, layer.listStart ?? 1);
  const markers: string[] = [];
  const counters = new Array(9).fill(0);
  counters[0] = startNum - 1;

  paragraphs.forEach((paragraph, i) => {
    if (!paragraph.trim() || !listOn) { markers.push(""); return; }
    const level = levels[i];
    counters[level] += 1;
    for (let deeper = level + 1; deeper < counters.length; deeper++) counters[deeper] = 0;
    markers.push(listMarker(layer, style, level, counters[level]));
  });

  // The widest marker sets the level step, so every marker column and tab stop lines up.
  // Deep list levels can never push the text column past the frame's right edge:
  // the indent is capped at 70% of the frame, and its marker always hangs just
  // left of the body (never outside the selection box).
  const base = fontSizeOf(layer);
  const widest = markers.reduce((width, marker) => marker ? Math.max(width, measureString(layer, marker)) : width, base * 0.4);
  const unit = listOn ? widest + base * 0.45 : 0;
  const indentCap = Math.max(0, boxWidth * 0.7 - unit);
  const listIndentOf = (level: number) => listOn ? Math.max(unit, Math.min(boxWidth * 0.7, (level + 1) * unit)) : 0;
  const markerXOf = (level: number) => listOn ? Math.max(0, Math.min(indentCap, level * unit)) : 0;

  let paraStart = 0;
  const starts = paragraphs.map(p => { const s = paraStart; paraStart += p.length + 1; return s; });

  const out: ListedLine[] = [];
  let rowsUsed = 0;
  paragraphs.forEach((paragraph, pi) => {
    const level = levels[pi];
    const indent = listIndentOf(level);
    // The drop cap swallows the opening letter of the very first paragraph.
    const swallowed = pi === 0 && !!drop;
    const body = swallowed ? paragraph.slice(drop!.char.length) : paragraph;
    const bodyStart = starts[pi] + (swallowed ? drop!.char.length : 0);
    const dropHere = Math.max(0, Math.min(dropRows - rowsUsed, 20));
    
    // First line of each paragraph gets firstLineIndent applied (if no drop cap active on this row)
    const rowIndent = (row: number) => {
      const isDropRow = row < dropHere;
      const flIndent = row === 0 && !isDropRow ? firstLineIndent : 0;
      return Math.max(0, indent + (isDropRow ? dropIndent : 0) + flIndent);
    };
    const limitAt = (row: number) => Math.max(1, boxWidth - rowIndent(row));

    if (!body.trim()) {
      out.push({
        marker: "",
        text: "",
        segs: [{ text: "", kind: null }],
        indent: rowIndent(0),
        markerX: markerXOf(level),
        end: true,
        level,
        paraIndex: pi,
        isFirstParaRow: true,
      });
      rowsUsed += 1;
      return;
    }
    const rows: WrapRow[] = fixed
      ? wrapRich(layer, body, bodyStart, limitAt, ranges)
      : [{ text: body, start: bodyStart, end: bodyStart + body.length }];

    rows.forEach((row, i) => out.push({
      marker: i === 0 ? markers[pi] : "",
      text: row.text,
      segs: segmentRow(row.text, row.start, ranges),
      indent: rowIndent(i),
      markerX: markerXOf(level),
      end: i === rows.length - 1,
      level,
      paraIndex: pi,
      isFirstParaRow: i === 0,
    }));
    rowsUsed += rows.length;
  });

  return out.length ? out : [{ marker: "", text: "", segs: [{ text: "", kind: null }], indent: 0, markerX: 0, end: true, level: 0, paraIndex: 0, isFirstParaRow: true }];
}

/** Height needed to show the text wrapped at maxWidth — drop caps, paragraph
    spacing and sub / superscript headroom included, so nothing ever overflows. */
export function wrappedTextHeight(layer: DesignLayer, maxWidth: number): number {
  const base = fontSizeOf(layer);
  const drop = layer.dropCap ? dropCapLayout(layer) : null;
  const pads = scriptPadsOf(layer);
  const dropMin = drop ? Math.ceil(drop.lines * base * textLineHeight(layer)) : 0;
  const lines = listedLines(layer, maxWidth);
  const rowH = base * textLineHeight(layer);
  const paraCount = (layer.text || "").split("\n").filter(p => p.trim()).length;
  const extraParaSpace = Math.max(0, paraCount - 1) * (layer.paraSpacing || 0);
  return Math.max(Math.ceil(rowH), dropMin, Math.ceil(lines.length * rowH + extraParaSpace + pads.top + pads.bottom));
}

/**
 * Alignment change that keeps justification meaningful: justify needs a fixed frame,
 * so switching to it turns auto-fit off and widens a hug-tight box to give the
 * words room to wrap and spread. Returns the patch (and whether it converted).
 */
export function justifyAlignPatch(layer: DesignLayer, value: NonNullable<DesignLayer["align"]>, docWidth: number): { patch: Partial<DesignLayer>; converted: boolean } {
  if (value !== "justify" && value !== "justify-all") return { patch: { align: value }, converted: false };
  if (layer.autoFit === false) return { patch: { align: value }, converted: false };
  const avail = Math.max(layer.width, docWidth - layer.x - 16);
  const newWidth = Math.round(Math.max(layer.width, Math.min(avail, Math.max(420, layer.width * 1.5))));
  const next = { ...layer, align: value, autoFit: false as const };
  return { patch: { align: value, autoFit: false, width: newWidth, height: wrappedTextHeight(next, newWidth) }, converted: true };
}

/** Measures the actual natural width of text when wrapped at layer.width.
 * Used when a text box's width was dragged wider than its content: deselecting
 * snaps the width to the longest rendered line, so no empty space hangs on the right. */
export function contentBoundedWidth(layer: DesignLayer): number {
  const base = fontSizeOf(layer);
  const lines = listedLines(layer, layer.width);
  if (!lines.length) return Math.round(base * 0.6);
  const widths = lines.map(line => line.indent + (line.marker ? measureString(layer, line.marker) : 0) + measureSegs(layer, line.segs));
  const drop = layer.dropCap ? dropCapLayout(layer) : null;
  const hangLeft = drop && !drop.indent ? drop.width : 0;
  const padding = Math.max(4, Math.round(base * 0.08));
  return Math.max(Math.round(base * 0.6), Math.ceil(Math.max(...widths, 10) + padding + hangLeft));
}

/** Auto-fit box: wraps the box tightly around the words (one line per paragraph, no wrapping). */
export function fitTextBox(layer: DesignLayer): Partial<DesignLayer> {
  const base = fontSizeOf(layer);
  const display = listedLines(layer);
  const widths = display.map(line => line.indent + (line.marker ? measureString(layer, line.marker) : 0) + measureSegs(layer, line.segs));
  const drop = layer.dropCap ? dropCapLayout(layer) : null;
  // "In margin" hangs the letter outside the frame, so the box reaches left to hold it.
  const hangLeft = drop && !drop.indent ? drop.width : 0;
  const padding = Math.max(6, Math.round(base * 0.12));
  const width = Math.max(Math.round(base * 0.6), Math.ceil(Math.max(...widths, 10) + padding));
  const height = wrappedTextHeight(layer, width);
  const align = layer.align || "left";
  const x = align === "center" ? Math.round(layer.x + layer.width / 2 - width / 2) : align === "right" ? Math.round(layer.x + layer.width - width) : layer.x;
  return { width: width + hangLeft, height, x: x - hangLeft };
}
