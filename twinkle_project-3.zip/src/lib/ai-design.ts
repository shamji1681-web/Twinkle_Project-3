import { blankDocument, type DesignDocument, type DesignLayer } from "@/lib/designs";
import type { QRSettings } from "@/lib/qr";

export type AiDesignType = "Visiting card" | "Letterhead" | "Brochure" | "Template" | "Bill book" | "ID card" | "Mug" | "T-shirt" | "Bag" | "Envelope" | "Other";

export interface AiDesignBrief {
  type: AiDesignType;
  companyName: string;
  tagline?: string;
  personName?: string;
  designation?: string;
  mobileNumber?: string;
  whatsappNumber?: string;
  email?: string;
  website?: string;
  address?: string;
  socialMedia?: string;
  businessType?: string;
  description?: string;
  prompt?: string;
  image?: string;
  logo?: string;
  enableQr?: boolean;
  qr?: QRSettings;
  // Legacy compatibility fallbacks
  name?: string;
  contact?: string;
  social?: string;
  extras?: Record<string, string>;
}

export const aiDesignTypes: AiDesignType[] = ["Letterhead", "Visiting card", "Brochure", "Template", "Bill book", "ID card", "Mug", "T-shirt", "Bag", "Envelope", "Other"];

/**
 * Print-true canvas sizes at 300 DPI (pixels = millimetres × 300 / 25.4).
 *  - Letterhead  : A4 portrait — 210 × 297 mm  → 2480 × 3508 px
 *  - Visiting card: standard Indian/global card — 95 × 58 mm → 1122 × 685 px
 *  - Envelope    : DL — 220 × 110 mm → 2598 × 1299 px
 *  - Bill book   : A5 portrait — 148 × 210 mm → 1748 × 2480 px
 *  - Brochure    : A4 portrait (folded later) → same as letterhead
 */
export const designSizesMM: Record<AiDesignType, [number, number]> = {
  "Letterhead": [210, 297],      // A4 portrait
  "Visiting card": [95, 58],     // standard Indian business card (10.5 mm trim margin)
  "Brochure": [210, 297],        // A4 portrait, ready to fold
  "Template": [1080 / 300 * 25.4, 1080 / 300 * 25.4], // 1080 × 1080 px social square at 300 DPI
  "Bill book": [148, 210],       // A5 portrait
  "ID card": [85.6, 54],         // CR80 credit-card size
  "Mug": [210, 90],              // standard mug wrap print area
  "T-shirt": [300, 400],         // A3 print area
  "Bag": [300, 400],
  "Envelope": [220, 110],        // DL envelope
  "Other": [297, 210],           // A4 landscape
};

const MM_TO_PX = 300 / 25.4; // 300 DPI
export const pxFromMM = (mm: number) => Math.round(mm * MM_TO_PX);

const sizes: Record<AiDesignType, [number, number]> = Object.fromEntries(
  (Object.keys(designSizesMM) as AiDesignType[]).map(type => [
    type,
    [pxFromMM(designSizesMM[type][0]), pxFromMM(designSizesMM[type][1])] as [number, number],
  ])
) as Record<AiDesignType, [number, number]>;

export const defaultBriefValues: Record<AiDesignType, Partial<AiDesignBrief>> = {
  "Letterhead": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
    website: "www.reallygreatsite.com",
    mobileNumber: "123-456-7890",
    email: "hello@reallygreatsite.com",
    address: "123 Innovation Plaza, Silicon City",
    prompt: "corporate professional blue and grey clean header footer",
  },
  "Visiting card": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
    personName: "Alex Morgan",
    designation: "Founder & Creative Director",
    mobileNumber: "123-456-7890",
    whatsappNumber: "123-456-7890",
    email: "hello@reallygreatsite.com",
    website: "www.reallygreatsite.com",
    address: "123 Innovation Plaza, Silicon City",
    businessType: "UI/UX, Branding & Web Development",
    enableQr: true,
    prompt: "corporate professional blue and grey modern minimal",
  },
  "Brochure": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
    website: "www.reallygreatsite.com",
    email: "hello@reallygreatsite.com",
    mobileNumber: "123-456-7890",
    businessType: "Creative Solutions & Brand Architecture",
  },
  "Template": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
  },
  "Bill book": {
    companyName: "THYNK UNLIMITED",
    email: "accounts@reallygreatsite.com",
    mobileNumber: "123-456-7890",
  },
  "ID card": {
    companyName: "THYNK UNLIMITED",
    personName: "Alex Morgan",
    designation: "Creative Director",
  },
  "Mug": {
    companyName: "THYNK UNLIMITED",
    tagline: "Think Creative, Live Unlimited",
  },
  "T-shirt": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Collective 2026",
  },
  "Bag": {
    companyName: "THYNK UNLIMITED",
    tagline: "Sustainable Ideas, Unlimited Future",
  },
  "Envelope": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
    website: "www.reallygreatsite.com",
    address: "123 Innovation Plaza, Silicon City",
  },
  "Other": {
    companyName: "THYNK UNLIMITED",
    tagline: "Creative Company",
  },
};

const paths = {
  globe: "M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2Zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8Zm-1-14a13.9 13.9 0 0 0-3 6h6a13.9 13.9 0 0 0-3-6Zm-3.8 6a15.8 15.8 0 0 1 1.6-4.6A8.1 8.1 0 0 0 4.2 12Zm0 2h3.6a15.8 15.8 0 0 1-1.6 4.6 8.1 8.1 0 0 0-2-4.6Zm4.8 4a13.9 13.9 0 0 0 3-6H9a13.9 13.9 0 0 0 3 6Zm4.8-1.4a8.1 8.1 0 0 0 2-4.6h-3.6a15.8 15.8 0 0 1 1.6 4.6Zm2-6.6h-3.6a15.8 15.8 0 0 1-1.6-4.6 8.1 8.1 0 0 0 2 4.6Z",
  phone: "M6.6 3.6h3l1.5 4-2 1.5a11 11 0 0 0 5.8 5.8l1.5-2 4 1.5v3c-8 .6-15.4-6.8-14.8-14.8Z",
  mail: "M3.6 6h16.8v12H3.6zM3.6 7.2 12 13.4l8.4-6.2",
  pin: "M12 21s6.4-6.1 6.4-11a6.4 6.4 0 1 0-12.8 0C5.6 14.9 12 21 12 21Zm0-8.6a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  whatsapp: "M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91A9.92 9.92 0 0 0 12.04 2Zm0 18.17c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.18 8.18 0 0 1-1.26-4.4c0-4.52 3.68-8.2 8.2-8.2 2.19 0 4.25.85 5.8 2.4a8.15 8.15 0 0 1 2.4 5.8c0 4.52-3.68 8.2-8.2 8.2Zm4.49-6.14c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.98-.14.17-.29.19-.54.06-.25-.12-1.04-.38-1.98-1.22-.73-.65-1.23-1.46-1.37-1.71-.15-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.17-.25.25-.42.08-.17.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.85-.2-.49-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.23.25-.87.85-.87 2.08 0 1.22.89 2.4 1.02 2.57.12.17 1.76 2.69 4.26 3.77.6.26 1.06.41 1.42.53.6.19 1.15.16 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.15-1.18-.07-.12-.23-.19-.48-.31Z",
};

/** Palette based on prompt keywords, with Thynk corporate blue as crisp default. */
function palette(prompt: string = "") {
  const p = prompt.toLowerCase();
  if (/luxury|gold|elegant|premium/.test(p)) {
    return { primary: "#1c2430", secondary: "#c59b27", accent: "#e6c46a", grey: "#7b8390", lightGrey: "#f3f5f8", rule: "#d5dadf", ink: "#1c2430", paper: "#ffffff" };
  }
  if (/nature|organic|green|eco/.test(p)) {
    return { primary: "#134e4a", secondary: "#0d9488", accent: "#2dd4bf", grey: "#64748b", lightGrey: "#f0fdfa", rule: "#cbd5e1", ink: "#0f172a", paper: "#ffffff" };
  }
  if (/red|bold|energy|crimson/.test(p)) {
    return { primary: "#1e1e24", secondary: "#dc2626", accent: "#f87171", grey: "#6b7280", lightGrey: "#fef2f2", rule: "#e5e7eb", ink: "#111827", paper: "#ffffff" };
  }
  if (/purple|violet|creative|tech/.test(p)) {
    return { primary: "#1e1b4b", secondary: "#6366f1", accent: "#818cf8", grey: "#64748b", lightGrey: "#eef2ff", rule: "#e2e8f0", ink: "#0f172a", paper: "#ffffff" };
  }
  // Default: Thynk Unlimited Navy & Royal Blue with soft greys
  return {
    primary: "#0e6ba8",   // Thynk Cerulean / Royal
    secondary: "#0a4b78", // Deep blue pill
    accent: "#00a3e0",    // Cyan accent
    grey: "#64748b",      // Subtitle grey
    lightGrey: "#f0f4f8", // Watermark watermark tint
    rule: "#d9e2ec",      // Header underline grey
    ink: "#102a43",       // Primary bold text
    paper: "#ffffff",
  };
}

/**
 * The Thynk-style brand mark: nested 45° arrow chevrons drawn on a standard 24×24
 * icon grid so it scales precisely and stays strictly inside the element's selection box.
 */
function chevronLogoPath(): string {
  return "M12 3 L21 12 L17 16 L12 11 L7 16 L3 12 Z M12 8.5 L18 14.5 L15 17.5 L12 14.5 L9 17.5 L6 14.5 Z M12 14 L15 17 L13 19 L12 18 L11 19 L9 17 Z";
}

/** Shared brand mark factory: uploaded logo wins, otherwise the vector chevrons. */
function makeBrandMark(uid: (kind: string) => string, brief: AiDesignBrief, x: number, y: number, size: number, color: string): DesignLayer {
  if (brief.logo) {
    return { id: uid("logo"), type: "image", x: Math.round(x), y: Math.round(y), width: Math.round(size), height: Math.round(size), fill: "transparent", src: brief.logo };
  }
  return { id: uid("logo"), type: "icon", x: Math.round(x), y: Math.round(y), width: Math.round(size), height: Math.round(size), fill: color, path: chevronLogoPath(), outline: false };
}

export function buildAiDesign(brief: AiDesignBrief): DesignDocument {
  const [width, height] = sizes[brief.type] || [850, 1100];
  const color = palette(brief.prompt);
  const doc = blankDocument(width, height);
  doc.background = color.paper;

  let n = 0;
  const layers: DesignLayer[] = [];
  const uid = (kind: string) => `ai-${kind}-${++n}`;
  const fs = (factor: number) => Math.round(Math.min(width, height) * factor);

  const addText = (value: string, x: number, y: number, w: number, size: number, fill = color.ink, extra: Partial<DesignLayer> = {}) => {
    if (!value || !value.trim()) return;
    layers.push({
      id: uid("text"),
      type: "text",
      x,
      y,
      width: w,
      height: Math.ceil(size * 1.25 * Math.max(1, value.split("\n").length)),
      text: value,
      fontSize: size,
      fill,
      fontFamily: "Arial",
      ...extra,
    });
  };

  const addRect = (x: number, y: number, w: number, h: number, fill: string, extra: Partial<DesignLayer> = {}) => {
    layers.push({ id: uid("rect"), type: "rect", x, y, width: w, height: h, fill, ...extra });
  };

  const addIcon = (path: string, x: number, y: number, size: number, fill = color.primary) => {
    layers.push({ id: uid("icon"), type: "icon", x, y, width: size, height: size, fill, path, outline: false });
  };

  const addImage = (src: string, x: number, y: number, w: number, h: number, extra: Partial<DesignLayer> = {}) => {
    layers.push({ id: uid("image"), type: "image", x, y, width: w, height: h, fill: "transparent", src, ...extra });
  };

  // Resolve values prioritizing direct fields then fallbacks
  const company = (brief.companyName || brief.name || "THYNK UNLIMITED").trim();
  const tagline = (brief.tagline || brief.description || "Creative Company").trim();
  const person = (brief.personName || "").trim();
  const title = (brief.designation || "").trim();
  const phone = (brief.mobileNumber || brief.contact || "123-456-7890").trim();
  const whatsapp = (brief.whatsappNumber || "").trim();
  const email = (brief.email || "hello@reallygreatsite.com").trim();
  const site = (brief.website || "www.reallygreatsite.com").trim();
  const address = (brief.address || "123 Innovation Plaza, Silicon City").trim();
  const services = (brief.businessType || "").trim();

  // -------------------------------------------------------------
  // LETTERHEAD: Pixel-perfect replica of the provided reference image
  // -------------------------------------------------------------
  if (brief.type === "Letterhead") {
    // 1. Top-Right Abstract Header Shapes (Gray & Navy Overlapping Rounded Pills)
    // Gray pill at top right corner
    addRect(Math.round(width * 0.58), -Math.round(height * 0.014), Math.round(width * 0.35), Math.round(height * 0.05), "#cbd5e1", { radius: 24 });
    // Top navy deep rounded pill overlapping
    addRect(Math.round(width * 0.88), -Math.round(height * 0.009), Math.round(width * 0.25), Math.round(height * 0.055), color.secondary, { radius: 26 });
    // Main lower cerulean blue pill floating right
    addRect(Math.round(width * 0.76), Math.round(height * 0.015), Math.round(width * 0.35), Math.round(height * 0.065), color.primary, { radius: 32 });

    // 2. Header Brand Logo & Name (Top Left) — uploaded logo wins, chevrons otherwise
    const logoSize = Math.round(width * 0.12);
    const logoX = Math.round(width * 0.1);
    const logoY = Math.round(height * 0.035);
    layers.push(makeBrandMark(uid, brief, logoX, logoY, logoSize, color.primary));

    const brandX = logoX + logoSize + Math.round(width * 0.025);
    const brandY = logoY + Math.round(height * 0.012);
    addText(company, brandX, brandY, Math.round(width * 0.5), fs(0.045), color.ink, { fontWeight: 800, letterSpacing: 0.5 });
    addText(tagline, brandX, brandY + fs(0.052), Math.round(width * 0.5), fs(0.024), color.grey, { fontWeight: 400, letterSpacing: 1 });

    // 3. Top Horizontal Divider (Clean light-grey horizontal rule with left margin)
    addRect(Math.round(width * 0.08), Math.round(height * 0.125), Math.round(width * 0.84), Math.max(2, Math.round(fs(0.012))), color.rule, { radius: 2 });

    // 4. Large Faded Watermark in Canvas Center (45° Diagonal Big Logo Icon)
    const watermarkSize = Math.round(Math.min(width, height) * 0.52);
    const watermarkX = Math.round((width - watermarkSize) / 2);
    const watermarkY = Math.round((height - watermarkSize) / 2);
    layers.push({
      id: uid("watermark"),
      type: "icon",
      x: watermarkX,
      y: watermarkY,
      width: watermarkSize,
      height: watermarkSize,
      fill: "#e2e8f0",
      opacity: 0.28,
      rotation: -18,
      path: chevronLogoPath(),
      outline: false,
    });

    // 5. Bottom Thin Blue Separator Line
    addRect(Math.round(width * 0.08), Math.round(height * 0.94), Math.round(width * 0.84), Math.max(2, Math.round(fs(0.01))), color.primary, { radius: 1.5 });
    // Small corner accent pill right bottom
    addRect(Math.round(width * 0.84), Math.round(height * 0.938), Math.round(width * 0.12), Math.max(4, Math.round(fs(0.02))), "#cbd5e1", { radius: 3 });

    // 6. Bottom Contact Footer: Website, Phone, Email (with round filled icons)
    const footerY = Math.round(height * 0.955);
    const iconR = fs(0.022);

    // Left block: Website (globe)
    addIcon(paths.globe, Math.round(width * 0.1), footerY, iconR, color.primary);
    addText(site, Math.round(width * 0.1) + iconR + 8, footerY + 1, Math.round(width * 0.26), fs(0.016), color.grey);

    // Middle block: Phone
    addIcon(paths.phone, Math.round(width * 0.42), footerY, iconR, color.primary);
    addText(phone, Math.round(width * 0.42) + iconR + 8, footerY + 1, Math.round(width * 0.22), fs(0.016), color.grey);

    // Right block: Email
    addIcon(paths.mail, Math.round(width * 0.68), footerY, iconR, color.primary);
    addText(email, Math.round(width * 0.68) + iconR + 8, footerY + 1, Math.round(width * 0.26), fs(0.016), color.grey);

    doc.layers = layers;
    return doc;
  }

  // -------------------------------------------------------------
  // VISITING CARD: Same brand identity translated to business card ratio
  // -------------------------------------------------------------
  if (brief.type === "Visiting card") {
    // 1. Top-right geometric layered brand pills
    addRect(Math.round(width * 0.72), -Math.round(height * 0.025), Math.round(width * 0.24), Math.round(height * 0.12), "#cbd5e1", { radius: 18 });
    addRect(Math.round(width * 0.86), -Math.round(height * 0.016), Math.round(width * 0.22), Math.round(height * 0.14), color.secondary, { radius: 20 });
    addRect(Math.round(width * 0.78), Math.round(height * 0.02), Math.round(width * 0.26), Math.round(height * 0.16), color.primary, { radius: 24 });

    // 2. Watermark subtle chevron in background right
    const wmSize = Math.round(height * 0.72);
    layers.push({
      id: uid("watermark"),
      type: "icon",
      x: Math.round(width * 0.6),
      y: Math.round(height * 0.22),
      width: wmSize,
      height: wmSize,
      fill: "#e2e8f0",
      opacity: 0.22,
      rotation: -18,
      path: chevronLogoPath(),
      outline: false,
    });

    // 3. Logo and Company Header (Top Left)
    const logoSize = Math.round(height * 0.2);
    const leftX = Math.round(width * 0.06);
    const topY = Math.round(height * 0.09);

    layers.push(makeBrandMark(uid, brief, leftX, topY, logoSize, color.primary));

    const brandX = leftX + logoSize + Math.round(width * 0.02);
    addText(company, brandX, topY + Math.round(height * 0.01), Math.round(width * 0.5), fs(0.072), color.ink, { fontWeight: 800, letterSpacing: 0.5 });
    addText(tagline, brandX, topY + fs(0.08), Math.round(width * 0.5), fs(0.034), color.grey, { letterSpacing: 0.8 });

    // 4. Person Name & Designation (Middle Left)
    const personY = Math.round(height * 0.36);
    if (person) {
      addText(person, leftX, personY, Math.round(width * 0.55), fs(0.068), color.ink, { fontWeight: 700 });
      if (title) {
        addText(title, leftX, personY + fs(0.075), Math.round(width * 0.55), fs(0.034), color.primary, { fontWeight: 600 });
      }
    }

    // Services / Business type tagline
    if (services) {
      addText(services, leftX, person ? personY + fs(0.125) : personY, Math.round(width * 0.55), fs(0.026), color.grey, { italic: true });
    }

    // 5. Left accent line
    addRect(leftX, Math.round(height * 0.56), Math.round(width * 0.55), 2, color.rule);

    // 6. Contact Information rows
    let contactY = Math.round(height * 0.62);
    const rowStep = Math.round(height * 0.085);
    const iconSize = fs(0.038);

    if (phone) {
      addIcon(paths.phone, leftX, contactY, iconSize, color.primary);
      addText(phone, leftX + iconSize + 8, contactY + 2, Math.round(width * 0.4), fs(0.028), color.ink);
      contactY += rowStep;
    }
    if (whatsapp) {
      addIcon(paths.whatsapp, leftX, contactY, iconSize, "#25d366");
      addText(whatsapp, leftX + iconSize + 8, contactY + 2, Math.round(width * 0.4), fs(0.028), color.ink);
      contactY += rowStep;
    }
    if (email) {
      addIcon(paths.mail, leftX, contactY, iconSize, color.primary);
      addText(email, leftX + iconSize + 8, contactY + 2, Math.round(width * 0.45), fs(0.026), color.ink);
      contactY += rowStep;
    }
    if (site) {
      addIcon(paths.globe, leftX, contactY, iconSize, color.primary);
      addText(site, leftX + iconSize + 8, contactY + 2, Math.round(width * 0.45), fs(0.026), color.ink);
      contactY += rowStep;
    }
    if (address && contactY < Math.round(height * 0.92)) {
      addIcon(paths.pin, leftX, contactY, iconSize, color.primary);
      addText(address, leftX + iconSize + 8, contactY + 2, Math.round(width * 0.5), fs(0.024), color.grey);
    }

    // 7. QR Code or Photo on the right
    if (brief.enableQr || brief.qr) {
      const qrBox = Math.round(height * 0.38);
      const qrX = Math.round(width * 0.76);
      const qrY = Math.round(height * 0.5);
      // Soft background card for QR code
      addRect(qrX - 10, qrY - 10, qrBox + 20, qrBox + 20, "#ffffff", { radius: 10 });
      layers.push({
        id: uid("qr"),
        type: "image",
        x: qrX,
        y: qrY,
        width: qrBox,
        height: qrBox,
        fill: "transparent",
        qr: brief.qr || {
          text: site.startsWith("http") ? site : `https://${site}`,
          dotStyle: "rounded",
          cornerStyle: "rounded",
          margin: 2,
          errorCorrection: "M",
          fg: color.primary,
          fg2: color.secondary,
          gradient: false,
          bg: "#ffffff",
          transparent: false,
          logo: false,
          content: { type: "url", value: site.startsWith("http") ? site : `https://${site}` },
        },
      });
      addText("Scan for info", qrX - 10, qrY + qrBox + 14, qrBox + 20, fs(0.024), color.grey, { align: "center" });
    } else if (brief.image) {
      const photoSize = Math.round(height * 0.42);
      addImage(brief.image, Math.round(width * 0.74), Math.round(height * 0.48), photoSize, photoSize, { radius: photoSize / 2 });
    }

    // 8. Bottom accent rule
    addRect(0, height - 6, Math.round(width * 0.65), 6, color.primary);
    addRect(Math.round(width * 0.65) + 6, height - 6, Math.round(width * 0.35), 6, color.secondary);

    doc.layers = layers;
    return doc;
  }

  // -------------------------------------------------------------
  // OTHER DESIGN TYPES (Brochure, Bill book, ID card, etc.)
  // -------------------------------------------------------------
  if (brief.type === "Brochure") {
    addRect(0, 0, width, Math.round(height * 0.38), color.primary);
    addIcon(chevronLogoPath(), Math.round(width * 0.08), Math.round(height * 0.07), Math.round(width * 0.12), "#ffffff");
    addText(company, Math.round(width * 0.23), Math.round(height * 0.08), Math.round(width * 0.68), fs(0.065), "#ffffff", { fontWeight: 800 });
    addText(tagline, Math.round(width * 0.23), Math.round(height * 0.14), Math.round(width * 0.68), fs(0.028), "#cbd5e1");
    addText(services || brief.description || "Thoughtfully designed for real impact.", Math.round(width * 0.08), Math.round(height * 0.22), Math.round(width * 0.8), fs(0.032), "#ffffff", { lineHeight: 1.4 });

    [[paths.globe, "Digital Presence"], [paths.phone, "Connect Directly"], [paths.mail, "Collaborate"]].forEach(([p, label], i) => {
      const x = Math.round(width * (0.08 + i * 0.3));
      addRect(x, Math.round(height * 0.5), Math.round(width * 0.26), Math.round(height * 0.24), color.lightGrey, { radius: 14 });
      addIcon(p, x + 16, Math.round(height * 0.54), fs(0.045), color.primary);
      addText(label, x + 16, Math.round(height * 0.64), Math.round(width * 0.22), fs(0.024), color.ink, { fontWeight: 700 });
    });

    addRect(Math.round(width * 0.08), Math.round(height * 0.9), Math.round(width * 0.84), 2, color.primary);
    addText([phone, email, site].filter(Boolean).join("   ·   "), Math.round(width * 0.08), Math.round(height * 0.93), Math.round(width * 0.84), fs(0.02), color.grey, { align: "center" });

  } else if (brief.type === "Bill book") {
    addRect(0, 0, width, Math.round(height * 0.12), color.primary);
    addText(company, Math.round(width * 0.07), Math.round(height * 0.05), Math.round(width * 0.55), fs(0.055), "#ffffff", { fontWeight: 800 });
    addText("TAX INVOICE", Math.round(width * 0.65), Math.round(height * 0.055), Math.round(width * 0.28), fs(0.03), "#ffffff", { align: "right", fontWeight: 700 });
    addText(tagline, Math.round(width * 0.07), Math.round(height * 0.15), Math.round(width * 0.5), fs(0.024), color.grey);
    addText([phone, email, site].filter(Boolean).join("  |  "), Math.round(width * 0.07), Math.round(height * 0.19), Math.round(width * 0.86), fs(0.02), color.ink);

    layers.push({
      id: uid("table"),
      type: "table",
      x: Math.round(width * 0.07),
      y: Math.round(height * 0.26),
      width: Math.round(width * 0.86),
      height: Math.round(height * 0.48),
      fill: color.primary,
      cellFill: "transparent",
      lineColor: color.rule,
      lineWidth: 1.5,
      rows: 6,
      cols: 4,
      cells: [
        "S.No", "Description of Goods / Services", "Qty", "Amount (₹)",
        "1", "Branding & Identity Design", "1", "15,000",
        "2", "Letterhead & Visiting Card Printing", "500", "4,500",
        "3", "", "", "",
        "4", "", "", "",
        "Total", "", "", "19,500"
      ],
      colWidths: [0.1, 0.55, 0.12, 0.23],
      rowHeights: [0.15, 0.17, 0.17, 0.17, 0.17, 0.17],
    });

    addText("Thank you for your business!", Math.round(width * 0.07), Math.round(height * 0.86), Math.round(width * 0.86), fs(0.022), color.primary, { fontWeight: 600 });

  } else if (brief.type === "ID card") {
    // Top banner
    addRect(0, 0, width, Math.round(height * 0.25), color.primary);
    addText(company, Math.round(width * 0.06), Math.round(height * 0.07), Math.round(width * 0.88), fs(0.05), "#ffffff", { fontWeight: 800, align: "center" });

    // Photo placeholder
    const photoW = Math.round(width * 0.32);
    const photoH = Math.round(height * 0.45);
    const photoX = Math.round(width * 0.08);
    const photoY = Math.round(height * 0.35);
    if (brief.image) {
      addImage(brief.image, photoX, photoY, photoW, photoH, { radius: 10 });
    } else {
      addRect(photoX, photoY, photoW, photoH, color.lightGrey, { radius: 10 });
      addIcon(chevronLogoPath(), photoX + 24, photoY + 24, photoW - 48, color.primary);
    }

    const infoX = photoX + photoW + Math.round(width * 0.06);
    addText(person || "MEMBER NAME", infoX, Math.round(height * 0.38), Math.round(width * 0.48), fs(0.055), color.ink, { fontWeight: 800 });
    addText(title || "Designation", infoX, Math.round(height * 0.47), Math.round(width * 0.48), fs(0.032), color.primary, { fontWeight: 600 });
    addText("ID No: EMP-0042", infoX, Math.round(height * 0.55), Math.round(width * 0.48), fs(0.026), color.grey);
    addText(`Phone: ${phone}`, infoX, Math.round(height * 0.62), Math.round(width * 0.48), fs(0.024), color.ink);
    addText(`Email: ${email}`, infoX, Math.round(height * 0.69), Math.round(width * 0.48), fs(0.022), color.ink);

    addRect(0, height - 12, width, 12, color.primary);

  } else {
    // Generic clean layout
    addRect(0, 0, width, Math.round(height * 0.1), color.primary);
    addIcon(chevronLogoPath(), Math.round(width * 0.07), Math.round(height * 0.02), Math.round(height * 0.06), "#ffffff");
    addText(company, Math.round(width * 0.18), Math.round(height * 0.03), Math.round(width * 0.7), fs(0.05), "#ffffff", { fontWeight: 800 });
    addText(tagline, Math.round(width * 0.1), Math.round(height * 0.25), Math.round(width * 0.8), fs(0.06), color.ink, { fontWeight: 700, align: "center" });
    if (brief.image) addImage(brief.image, Math.round(width * 0.25), Math.round(height * 0.38), Math.round(width * 0.5), Math.round(height * 0.4), { radius: 16 });
    addText([phone, email, site].filter(Boolean).join("  ·  "), Math.round(width * 0.1), Math.round(height * 0.88), Math.round(width * 0.8), fs(0.022), color.grey, { align: "center" });
  }

  doc.layers = layers;
  return doc;
}
