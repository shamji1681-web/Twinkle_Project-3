import type { DesignDocument, DesignLayer } from "@/lib/designs";

export interface QuoteStyle { key: string; name: string; preview: string; build: (doc: DesignDocument) => DesignLayer[] }
export interface QuoteEntry { text: string; cat: string }
/** Short, design-friendly lines grouped so they are easy to browse. */
export const quoteLibrary: QuoteEntry[] = [
  { text: "Good things take time.", cat: "Motivation" },
  { text: "A little progress each day adds up.", cat: "Motivation" },
  { text: "Start where you are.\nUse what you have.", cat: "Motivation" },
  { text: "Do what you can,\nwith what you have.", cat: "Motivation" },
  { text: "Small steps, every single day.", cat: "Motivation" },
  { text: "Begin. The rest is momentum.", cat: "Motivation" },
  { text: "Less, but better.", cat: "Design" },
  { text: "Make it simple,\nbut significant.", cat: "Design" },
  { text: "Design is thinking\nmade visible.", cat: "Design" },
  { text: "Simplicity is the ultimate\nsophistication.", cat: "Design" },
  { text: "Good design is\nas little design as possible.", cat: "Design" },
  { text: "White space is not empty space.", cat: "Design" },
  { text: "Creativity takes courage.", cat: "Creativity" },
  { text: "Every big idea\nbegan as a small one.", cat: "Creativity" },
  { text: "Make something\nyou would want to keep.", cat: "Creativity" },
  { text: "Ideas are cheap.\nMaking them is everything.", cat: "Creativity" },
  { text: "Curiosity is the\nbest creative tool.", cat: "Creativity" },
  { text: "Done is better than perfect.", cat: "Work" },
  { text: "Focus is saying no\nto a thousand things.", cat: "Work" },
  { text: "Slow is smooth.\nSmooth is fast.", cat: "Work" },
  { text: "Do fewer things, better.", cat: "Work" },
  { text: "Quality is never an accident.", cat: "Work" },
  { text: "Grateful for\nthe ordinary days.", cat: "Life" },
  { text: "Take the scenic route.", cat: "Life" },
  { text: "Enjoy the little things.", cat: "Life" },
  { text: "Be where your feet are.", cat: "Life" },
  { text: "Collect moments,\nnot things.", cat: "Life" },
  { text: "Happy birthday,\nbeautiful soul.", cat: "Celebrate" },
  { text: "Here's to new beginnings.", cat: "Celebrate" },
  { text: "Congratulations!\nYou did it.", cat: "Celebrate" },
  { text: "Cheers to you.", cat: "Celebrate" },
  { text: "Thank you for everything.", cat: "Celebrate" },
];
export const quoteCategories = ["All", ...Array.from(new Set(quoteLibrary.map(q => q.cat)))];
export const quoteTexts = quoteLibrary.map(q => q.text);

let n = 0;
const id = () => `quote-${Date.now().toString(36)}-${++n}`;
const center = (doc: DesignDocument) => doc.width / 2;

export const quoteStyles: QuoteStyle[] = [
  { key: "classic", name: "Classic quote", preview: "Serif words with a large quotation mark.", build: doc => [
    { id: id(), type: "icon", x: doc.width * .1, y: doc.height * .12, width: doc.width * .16, height: doc.width * .16, fill: "#7952e9", path: quotePath, outline: true },
    { id: id(), type: "text", x: doc.width * .1, y: doc.height * .34, width: doc.width * .8, height: doc.width * .12, text: "Your words here.", fontSize: Math.round(doc.width * .072), fill: "#3b2f45", fontFamily: "Georgia", align: "center" },
    { id: id(), type: "text", x: doc.width * .1, y: doc.height * .68, width: doc.width * .8, height: 30, text: "— SOMEONE YOU ADMIRE", fontSize: Math.round(doc.width * .022), fill: "#8c7fa0", align: "center" },
  ] },
  { key: "framed", name: "Framed words", preview: "A thin border with centered text.", build: doc => [
    { id: id(), type: "shape", shape: "frame", x: doc.width * .1, y: doc.height * .12, width: doc.width * .8, height: doc.height * .76, fill: "#6b4f9c", outline: false },
    { id: id(), type: "text", x: doc.width * .16, y: doc.height * .4, width: doc.width * .68, height: doc.width * .1, text: "A thought worth keeping.", fontSize: Math.round(doc.width * .05), fill: "#4a3568", fontFamily: "Georgia", italic: true, align: "center" },
  ] },
  { key: "sparkle", name: "Sparkle quote", preview: "Playful text with a sparkle accent.", build: doc => [
    { id: id(), type: "shape", shape: "sparkle", x: doc.width * .12, y: doc.height * .16, width: doc.width * .16, height: doc.width * .16, fill: "#f59e0b" },
    { id: id(), type: "shape", shape: "sparkle", x: doc.width * .74, y: doc.height * .62, width: doc.width * .12, height: doc.width * .12, fill: "#f59e0b", rotation: 18 },
    { id: id(), type: "text", x: doc.width * .1, y: doc.height * .38, width: doc.width * .8, height: doc.width * .14, text: "Something worth saying.", fontSize: Math.round(doc.width * .065), fill: "#33253f", fontWeight: 700, align: "center" },
  ] },
  { key: "rule", name: "Rule and words", preview: "A quiet line above and below.", build: doc => [
    { id: id(), type: "stroke", variant: "solid", x: doc.width * .25, y: doc.height * .3, width: doc.width * .5, height: Math.max(6, doc.width * .006), fill: "#9a86b5", strokeWidth: Math.max(3, doc.width * .004) },
    { id: id(), type: "text", x: doc.width * .1, y: doc.height * .42, width: doc.width * .8, height: doc.width * .1, text: "Quiet words, loudly felt.", fontSize: Math.round(doc.width * .048), fill: "#4b3b5c", fontFamily: "Georgia", align: "center" },
    { id: id(), type: "stroke", variant: "solid", x: doc.width * .25, y: doc.height * .62, width: doc.width * .5, height: Math.max(6, doc.width * .006), fill: "#9a86b5", strokeWidth: Math.max(3, doc.width * .004) },
  ] },
  { key: "badge", name: "Quote badge", preview: "Text inside a soft badge shape.", build: doc => [
    { id: id(), type: "shape", shape: "rounded", x: doc.width * .12, y: doc.height * .3, width: doc.width * .76, height: doc.height * .4, fill: "#efe6fb" },
    { id: id(), type: "text", x: doc.width * .18, y: doc.height * .42, width: doc.width * .64, height: doc.width * .1, text: "Worth repeating.", fontSize: Math.round(doc.width * .055), fill: "#6c4a9c", fontWeight: 700, align: "center" },
    { id: id(), type: "text", x: doc.width * .18, y: doc.height * .58, width: doc.width * .64, height: 28, text: "A LITTLE TRUTH", fontSize: Math.round(doc.width * .02), fill: "#9a7fc4", align: "center" },
  ] },
];

const quotePath = "M9.4 6.2c-3.2 1.3-4.8 3.8-4.8 7.6v4.6h6.2v-6.2H7.4c0-2.1.9-3.5 2.8-4.4Zm9.8 0c-3.2 1.3-4.8 3.8-4.8 7.6v4.6h6.2v-6.2h-3.4c0-2.1.9-3.5 2.8-4.4Z";
export const quoteCenterX = center;
