import QRCode from "qrcode";
import { brandLogoKey, isBrandLogo, type QRSettings } from "@/lib/qr";
import { drawBrandLogo } from "@/lib/brand-logos";

const MODULE = 8;
const OUTPUT = 1024;

/** Builds a fully styled QR code as an SVG string (modules, finders, colors, gradient). */
export function buildQrSvg(text: string, settings: QRSettings) {
  const qr = QRCode.create(text, { errorCorrectionLevel: settings.errorCorrection });
  const count = qr.modules.size;
  const data = qr.modules.data;
  const margin = settings.margin;
  const extent = (count + margin * 2) * MODULE;
  const fill = settings.gradient ? "url(#qrGradient)" : settings.fg;
  const dark = (row: number, col: number) => row >= 0 && col >= 0 && row < count && col < count && data[row * count + col] === 1;
  const finder = (row: number, col: number) => (row < 7 && col < 7) || (row < 7 && col >= count - 7) || (row >= count - 7 && col < 7);
  const parts: string[] = [];

  if (!settings.transparent) parts.push(`<rect width="${extent}" height="${extent}" fill="${settings.bg}"/>`);
  if (settings.gradient) parts.push(`<defs><linearGradient id="qrGradient" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="${settings.fg}"/><stop offset="100%" stop-color="${settings.fg2}"/></linearGradient></defs>`);

  for (let row = 0; row < count; row++) {
    for (let col = 0; col < count; col++) {
      if (!dark(row, col) || finder(row, col)) continue;
      const x = (col + margin) * MODULE, y = (row + margin) * MODULE;
      if (settings.dotStyle === "dots") parts.push(`<circle cx="${x + MODULE / 2}" cy="${y + MODULE / 2}" r="${MODULE * 0.45}" fill="${fill}"/>`);
      else if (settings.dotStyle === "diamond") parts.push(`<path d="M${x + MODULE / 2} ${y}L${x + MODULE} ${y + MODULE / 2}L${x + MODULE / 2} ${y + MODULE}L${x} ${y + MODULE / 2}Z" fill="${fill}"/>`);
      else if (settings.dotStyle === "rounded") parts.push(`<rect x="${x}" y="${y}" width="${MODULE}" height="${MODULE}" rx="${MODULE * 0.42}" fill="${fill}"/>`);
      else parts.push(`<rect x="${x}" y="${y}" width="${MODULE}" height="${MODULE}" fill="${fill}"/>`);
    }
  }

  for (const [row, col] of [[0, 0], [0, count - 7], [count - 7, 0]]) {
    const x = (col + margin) * MODULE, y = (row + margin) * MODULE;
    if (settings.cornerStyle === "circle") {
      parts.push(`<circle cx="${x + 3.5 * MODULE}" cy="${y + 3.5 * MODULE}" r="${3 * MODULE}" fill="none" stroke="${fill}" stroke-width="${MODULE}"/>`);
      parts.push(`<circle cx="${x + 3.5 * MODULE}" cy="${y + 3.5 * MODULE}" r="${1.5 * MODULE}" fill="${fill}"/>`);
    } else {
      const outer = settings.cornerStyle === "rounded" ? MODULE * 2 : 0;
      const inner = settings.cornerStyle === "rounded" ? MODULE * 0.9 : 0;
      parts.push(`<rect x="${x + MODULE / 2}" y="${y + MODULE / 2}" width="${6 * MODULE}" height="${6 * MODULE}" rx="${outer}" fill="none" stroke="${fill}" stroke-width="${MODULE}"/>`);
      parts.push(`<rect x="${x + 2 * MODULE}" y="${y + 2 * MODULE}" width="${3 * MODULE}" height="${3 * MODULE}" rx="${inner}" fill="${fill}"/>`);
    }
  }

  return { svg: `<svg xmlns="http://www.w3.org/2000/svg" width="${extent}" height="${extent}" viewBox="0 0 ${extent} ${extent}">${parts.join("")}</svg>`, extent };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Image failed to load"));
    image.src = src;
  });
}

async function svgToImage(svg: string) {
  const blob = new Blob([svg], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  try { return await loadImage(url); }
  finally { setTimeout(() => URL.revokeObjectURL(url), 500); }
}

function roundedRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/** Renders a styled QR code to a PNG data URL in the browser, optionally with the brand logo in the middle. */
export async function renderQrPng(text: string, settings: QRSettings, logo?: string | null): Promise<string> {
  const { svg } = buildQrSvg(text, settings);
  const canvas = document.createElement("canvas");
  canvas.width = OUTPUT;
  canvas.height = OUTPUT;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas isn't available in this browser.");

  if (!settings.transparent) { ctx.fillStyle = settings.bg; ctx.fillRect(0, 0, OUTPUT, OUTPUT); }
  const qrImage = await svgToImage(svg);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.drawImage(qrImage, 0, 0, OUTPUT, OUTPUT);

  const logoSrc = settings.customLogo || (settings.logo ? logo : null);
  if (logoSrc) {
    try {
      const scale = Number.isFinite(settings.logoScale) ? Math.max(.12, Math.min(.34, settings.logoScale as number)) : 0.23;
      const size = Math.round(OUTPUT * scale);
      const inner = Math.round(size * 0.86);
      const offset = Math.round((OUTPUT - size) / 2);
      const innerOffset = Math.round((OUTPUT - inner) / 2);
      // A white plate keeps the logo clear of the QR modules.
      ctx.fillStyle = settings.transparent ? "#ffffff" : settings.bg;
      roundedRectPath(ctx, offset, offset, size, size, Math.round(size * 0.22));
      ctx.fill();

      if (isBrandLogo(logoSrc)) {
        // Built-in brand marks are painted directly on the canvas — crisp at any size.
        ctx.save();
        ctx.translate(innerOffset, innerOffset);
        drawBrandLogo(ctx, brandLogoKey(logoSrc), inner);
        ctx.restore();
      } else if (/^data:image\/(png|jpeg|webp|svg\+xml)[;,]/.test(logoSrc)) {
        const artwork = await loadImage(logoSrc);
        if (artwork.naturalWidth) {
          const fit = Math.min(inner / artwork.naturalWidth, inner / artwork.naturalHeight);
          const w = artwork.naturalWidth * fit, h = artwork.naturalHeight * fit;
          ctx.drawImage(artwork, innerOffset + (inner - w) / 2, innerOffset + (inner - h) / 2, w, h);
        }
      }
    } catch (error) {
      console.warn("QR logo overlay skipped:", error);
    }
  }

  return canvas.toDataURL("image/png");
}
