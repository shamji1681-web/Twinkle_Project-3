import { useEffect, useRef, useState } from "react";
import { Link2, Unlink2 } from "lucide-react";
import type { DesignLayer } from "@/lib/designs";

interface Props {
  layer: DesignLayer | null;
  docWidth: number;
  docHeight: number;
  /** Applies a new size to the selected element (already rounded, always > 0). */
  onLayerSize: (width: number, height: number) => void;
  /** Applies a new canvas size when nothing is selected. */
  onCanvasSize: (width: number, height: number) => void;
}

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

/**
 * Width / height number fields for the canvas toolbar.
 * With no selection they resize the canvas; with a selection they resize that element.
 * The chain button keeps the original aspect ratio while typing.
 */
export default function SizeFields({ layer, docWidth, docHeight, onLayerSize, onCanvasSize }: Props) {
  const [link, setLink] = useState(false);
  const targetWidth = layer ? layer.width : docWidth;
  const targetHeight = layer ? layer.height : docHeight;
  const [draft, setDraft] = useState<{ w: string; h: string }>({ w: String(Math.round(targetWidth)), h: String(Math.round(targetHeight)) });
  const editing = useRef<"w" | "h" | null>(null);
  const locked = !!layer?.locked;

  useEffect(() => {
    // Keep the fields in sync with the canvas (drag, resize, undo) unless they are being typed in.
    setDraft(current => ({
      w: editing.current === "w" ? current.w : String(Math.round(targetWidth)),
      h: editing.current === "h" ? current.h : String(Math.round(targetHeight)),
    }));
  }, [targetWidth, targetHeight, layer?.id]);

  function commit(axis: "w" | "h", raw: string) {
    const value = Number(raw);
    if (!Number.isFinite(value) || value <= 0) return;
    if (!layer) {
      const size = clamp(Math.round(value), 64, 5000);
      if (axis === "w") {
        const height = link ? clamp(Math.round(size * (docHeight / docWidth || 1)), 64, 5000) : docHeight;
        onCanvasSize(size, height);
      } else {
        const width = link ? clamp(Math.round(size * (docWidth / docHeight || 1)), 64, 5000) : docWidth;
        onCanvasSize(width, size);
      }
      return;
    }
    if (locked) return;
    const size = clamp(Math.round(value), 2, 20000);
    if (axis === "w") {
      const ratio = size / (layer.width || 1);
      onLayerSize(size, link ? Math.max(2, Math.round(layer.height * ratio)) : Math.round(layer.height));
    } else {
      const ratio = size / (layer.height || 1);
      onLayerSize(link ? Math.max(2, Math.round(layer.width * ratio)) : Math.round(layer.width), size);
    }
  }

  const field = (axis: "w" | "h", label: string) => (
    <label className="size-field" title={layer ? `${label === "W" ? "Width" : "Height"} of the selected element (px)` : `Canvas ${label === "W" ? "width" : "height"} (px)`}>
      <span>{label}</span>
      <input
        type="number"
        min={layer ? 2 : 64}
        max={layer ? 20000 : 5000}
        step={1}
        disabled={locked}
        aria-label={layer ? `Selected element ${label === "W" ? "width" : "height"}` : `Canvas ${label === "W" ? "width" : "height"}`}
        value={axis === "w" ? draft.w : draft.h}
        onFocus={() => { editing.current = axis; }}
        onBlur={event => { editing.current = null; const value = event.target.value; setDraft(current => ({ ...current, [axis]: String(Math.round(axis === "w" ? targetWidth : targetHeight)) })); commit(axis, value); }}
        onChange={event => {
          const next = event.target.value;
          setDraft(current => ({ ...current, [axis]: next }));
          if (next.trim() !== "" && Number(next) > 0) commit(axis, next);
        }}
        onKeyDown={event => {
          if (event.key === "Enter") { event.preventDefault(); commit(axis, (event.target as HTMLInputElement).value); (event.target as HTMLInputElement).blur(); }
          event.stopPropagation();
        }}
      />
    </label>
  );

  return <div className={`size-fields${locked ? " is-locked" : ""}`} role="group" aria-label={layer ? "Element size" : "Canvas size"}>
    {field("w", "W")}
    <button
      type="button"
      className={`size-link ${link ? "active" : ""}`}
      aria-pressed={link}
      aria-label={link ? "Unlink width and height" : "Link width and height"}
      title={link ? "Aspect ratio locked" : "Lock aspect ratio"}
      onClick={() => setLink(!link)}
    >
      {link ? <Link2 size={13} /> : <Unlink2 size={13} />}
    </button>
    {field("h", "H")}
  </div>;
}
