import { useEffect, useRef, useState, type RefObject } from "react";
import { resolveAsset } from "@/lib/asset-map";
import { gradientStops, hexWithAlpha, isGradient, type GradientFill, type GradientStop } from "@/lib/designs";
import { createPortal } from "react-dom";
import RemoveBackgroundButton from "@/components/remove-background-button";
import TableProperties from "@/components/table-properties";
import TextProperties from "@/components/text-properties";
import TableTextProperties from "@/components/table-text-properties";
import RangeControl from "@/components/range-control";
import { ArrowDown, ChevronDown, ChevronLeft, ChevronRight, Copy, Crop, Eye, EyeOff, Maximize, Plus, QrCode, Sparkles, Wand2, X } from "lucide-react";
import { gradientCss, transformCase, type DesignLayer, type TextCase } from "@/lib/designs";
import { BULLET_VARIANTS, NUMBER_FORMATS } from "@/lib/text-fit";
import { FRACTION_GALLERY, convertTextFractions, formatFraction, insertFractionIntoText } from "@/lib/fractions";
import FillPicker from "@/components/fill-picker";
import { MASKS } from "@/lib/table";
import type { EditorContext } from "@/components/editor-panels";
import { sidePopoverPlacement } from "@/lib/popover-placement";

interface Props { ctx: EditorContext; onOpenPanel: (tool: string) => void; textInputRef: RefObject<HTMLInputElement | null> }
const NAMES: Record<string, string> = { text: "Text", rect: "Rectangle", ellipse: "Ellipse", image: "Image", star: "Star", flower: "Flower", line: "Rule", icon: "Icon", shape: "Shape", stroke: "Line", table: "Table", draw: "Drawing", pattern: "Pattern" };
const PALETTE = ["#7952e9", "#f8cbd7", "#064e48", "#ff8250", "#f59e0b", "#8caba4", "#24232b", "#ffffff"];

/** Canvas background as a virtual layer so the shared FillPicker (solid / gradient / image) can edit it. */
function parseBackgroundGradient(background: string): GradientFill | undefined {
  if (!isGradient(background)) return undefined;
  const { colors, angle } = gradientStops(background);
  const percents = background.match(/(\d+(?:\.\d+)?)%/g)?.map(v => Number(v.replace("%", "")) / 100) || [];
  const stops: GradientStop[] = colors.map((raw, index) => {
    const color = raw.length === 9 ? raw.slice(0, 7) : raw.length === 5 ? raw.slice(0, 4) : raw;
    const alpha = raw.length === 9 ? parseInt(raw.slice(7), 16) / 255 : 1;
    const offset = percents.length === colors.length ? percents[index] : index / Math.max(1, colors.length - 1);
    return { offset, color, alpha: alpha < 1 ? alpha : undefined };
  });
  return { type: background.startsWith("radial") ? "radial" : "linear", angle, stops };
}

export default function ContextBar({ ctx, onOpenPanel, textInputRef }: Props) {
  const [popover, setPopover] = useState<null | "fill" | "background" | "case" | "mask" | "spacing" | "list" | "fraction">(null);
  const [listTab, setListTab] = useState<"bullets" | "numbers">("bullets");
  const [fracMode, setFracMode] = useState<"normal" | "super" | "sub">("normal");
  const [customNum, setCustomNum] = useState("1");
  const [customDen, setCustomDen] = useState("2");
  const selected = ctx.selected;
  const barRef = useRef<HTMLDivElement>(null);
  const colors = [...new Set([...(ctx.workspace?.colors || []), ...PALETTE])].slice(0, 14);

  useEffect(() => {
    if (!popover) return;
    function away(event: MouseEvent) {
      const target = event.target as HTMLElement;
      if (!target.closest("[data-context-popover]") && !target.closest("[data-popover-trigger]")) setPopover(null);
    }
    function escape(event: KeyboardEvent) { if ((event.target as Element).matches?.('input[type="number"]')) return; if (event.key === "Escape") { event.preventDefault(); event.stopImmediatePropagation(); setPopover(null); } }
    document.addEventListener("pointerdown", away, true);
    document.addEventListener("keydown", escape, true);
    return () => { document.removeEventListener("pointerdown", away, true); document.removeEventListener("keydown", escape, true); };
  }, [popover]);

  const [popoverPos, setPopoverPos] = useState<{ x: number; y: number } | null>(null);
  useEffect(() => { setPopover(null); }, [selected?.id]);

  useEffect(() => {
    if (!popover) { setPopoverPos(null); return; }
    function place() {
      const button = barRef.current?.querySelector(`[data-popover-trigger="${popover}"]`) as HTMLElement | null;
      if (!button) return;
      const rect = button.getBoundingClientRect();
      const width = popover === "fill" || popover === "background" ? 268 : popover === "spacing" ? 260 : popover === "list" ? 260 : popover === "fraction" ? 260 : popover === "mask" ? 240 : popover === "case" ? 210 : 196;
      const height = popover === "fill" || popover === "background" ? 620 : popover === "spacing" ? 300 : popover === "list" ? 380 : popover === "fraction" ? 380 : popover === "mask" ? 320 : popover === "case" ? 300 : 260;
      const { left, top } = sidePopoverPlacement(rect, { width, height });
      setPopoverPos({ x: left, y: top });
    }
    place();
    const bar = barRef.current;
    const stage = document.querySelector(".editor-stage");
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    bar?.addEventListener("scroll", place);
    stage?.addEventListener("scroll", place);
    return () => { window.removeEventListener("resize", place); window.removeEventListener("scroll", place, true); bar?.removeEventListener("scroll", place); stage?.removeEventListener("scroll", place); };
  }, [popover, selected?.id]);

  useEffect(() => { const node = barRef.current; if (node) node.scrollLeft = 0; }, [selected?.id, ctx.tool]);

  /** Toolbar overflow: show arrows only when there is something hidden on that side. */
  const [overflow, setOverflow] = useState({ left: false, right: false });
  useEffect(() => {
    const node = barRef.current;
    if (!node) return;
    const sync = () => {
      const max = node.scrollWidth - node.clientWidth;
      setOverflow({ left: node.scrollLeft > 2, right: node.scrollLeft < max - 2 });
    };
    sync();
    node.addEventListener("scroll", sync, { passive: true });
    const observer = new ResizeObserver(sync);
    observer.observe(node);
    for (const child of Array.from(node.children)) observer.observe(child);
    window.addEventListener("resize", sync);
    return () => { node.removeEventListener("scroll", sync); observer.disconnect(); window.removeEventListener("resize", sync); };
  }, [selected?.id, selected?.type, ctx.tool, ctx.cellTextMode, ctx.cropMode]);

  /** A plain mouse wheel scrolls the strip sideways, so hidden buttons are reachable. */
  function wheelScroll(event: React.WheelEvent<HTMLDivElement>) {
    const node = barRef.current;
    if (!node) return;
    if (event.deltaX !== 0) return; // trackpads already scroll horizontally
    const max = node.scrollWidth - node.clientWidth;
    if (max <= 0) return;
    const next = Math.max(0, Math.min(max, node.scrollLeft + event.deltaY));
    if (next !== node.scrollLeft) { node.scrollLeft = next; event.preventDefault(); }
  }

  function nudge(direction: -1 | 1) {
    const node = barRef.current;
    if (!node) return;
    node.scrollBy({ left: direction * Math.max(160, node.clientWidth * 0.6), behavior: "smooth" });
  }

  const isQR = selected?.type === "image" && !!selected.qr;
  const colorValue = selected && selected.type !== "image" ? selected.fill : ctx.doc.background;
  const Icon = (_props: { layer: DesignLayer }) => <Sparkles size={14} />;

  const isFullBleed = (layer: DesignLayer) => layer.type === "image" && !layer.qr && layer.x === 0 && layer.y === 0 && layer.width === ctx.doc.width && layer.height === ctx.doc.height;
  let backgroundImageIndex = -1;
  ctx.doc.layers.forEach((layer, index) => { if (isFullBleed(layer)) backgroundImageIndex = index; });
  const backgroundImage = backgroundImageIndex >= 0 ? ctx.doc.layers[backgroundImageIndex] : null;
  const backgroundGradient = parseBackgroundGradient(ctx.doc.background);
  const backgroundSolid = isGradient(ctx.doc.background) ? (backgroundGradient?.stops[0]?.color || "#ffffff") : ctx.doc.background.slice(0, 7);
  const backgroundAlpha = !isGradient(ctx.doc.background) && ctx.doc.background.length === 9 ? parseInt(ctx.doc.background.slice(7), 16) / 255 : 1;
  const backgroundLayer: DesignLayer = { id: "canvas-background", type: "rect", x: 0, y: 0, width: ctx.doc.width, height: ctx.doc.height, fill: backgroundSolid, fillAlpha: backgroundAlpha < 1 ? backgroundAlpha : undefined, fillGradient: backgroundGradient, fillImage: backgroundImage?.src };
  function patchBackground(updates: Partial<DesignLayer>) {
    let layers = ctx.doc.layers;
    let background = ctx.doc.background;
    if ("fillImage" in updates) {
      if (updates.fillImage) {
        const layer: DesignLayer = { id: `bg-${Date.now().toString(36)}`, type: "image", x: 0, y: 0, width: ctx.doc.width, height: ctx.doc.height, fill: "transparent", src: updates.fillImage };
        layers = backgroundImageIndex >= 0 ? layers.map((l, i) => i === backgroundImageIndex ? layer : l) : [layer, ...layers];
      } else if (backgroundImageIndex >= 0) layers = layers.filter((_, i) => i !== backgroundImageIndex);
    }
    if (updates.fillGradient) background = gradientCss(updates.fillGradient);
    else if (updates.fill !== undefined) background = hexWithAlpha(updates.fill, updates.fillAlpha ?? 1);
    else if ("fillGradient" in updates && !updates.fillGradient && isGradient(background)) background = backgroundSolid;
    if (updates.fillAlpha !== undefined && updates.fill === undefined && !isGradient(background)) background = hexWithAlpha(backgroundSolid, updates.fillAlpha);
    ctx.changeDoc({ ...ctx.doc, background, layers });
  }

  const backgroundSwatch = backgroundImage ? `url(${resolveAsset(backgroundImage.src || "")}) center/cover` : backgroundGradient ? gradientCss(backgroundGradient) : ctx.doc.background;

  void textInputRef;

  function applyFraction(fracSymbol: string, mode: "normal" | "super" | "sub") {
    if (!selected || selected.type !== "text") return;
    const overlay = ctx.editingId === selected.id ? document.querySelector<HTMLTextAreaElement>(".text-edit-overlay") : null;
    const rawText = selected.text || "";
    const start = overlay?.selectionStart ?? rawText.length;
    const end = overlay?.selectionEnd ?? rawText.length;

    const result = insertFractionIntoText(rawText, start, end, fracSymbol, mode, selected.scriptRanges);
    ctx.patch(selected.id, { text: result.text, scriptRanges: result.ranges });
    const modeLabel = mode === "super" ? "superscript fraction (^½)" : mode === "sub" ? "subscript fraction (v½)" : "fraction (½)";
    ctx.notify(`Inserted ${fracSymbol} as ${modeLabel}.`);

    requestAnimationFrame(() => {
      const node = document.querySelector<HTMLTextAreaElement>(".text-edit-overlay");
      if (node) {
        node.focus({ preventScroll: true });
        node.setSelectionRange(result.start, result.end);
      }
    });
  }

  function convertAllFractionsInText() {
    if (!selected || selected.type !== "text") return;
    const res = convertTextFractions(selected.text || "", selected.scriptRanges);
    ctx.patch(selected.id, { text: res.text, scriptRanges: res.ranges });
    ctx.notify(res.count ? `Converted ${res.count} fraction${res.count === 1 ? "" : "s"} in text.` : "No plain fractions (e.g. 1/2) found to convert.");
  }

  return <div className={`context-bar-shell${overflow.left ? " can-left" : ""}${overflow.right ? " can-right" : ""}`} data-keep-cell-editing data-keep-text-editing>
    <button type="button" className="context-scroll-arrow left" aria-label="Scroll toolbar left" tabIndex={overflow.left ? 0 : -1} onPointerDown={e => e.preventDefault()} onClick={() => nudge(-1)}><ChevronLeft size={16} /></button>
    <button type="button" className="context-scroll-arrow right" aria-label="Scroll toolbar right" tabIndex={overflow.right ? 0 : -1} onPointerDown={e => e.preventDefault()} onClick={() => nudge(1)}><ChevronRight size={16} /></button>
    <div className="editor-context-bar" data-keep-cell-editing data-keep-text-editing role="toolbar" aria-label="Element properties" ref={barRef} onWheel={wheelScroll}>
    <span className="context-chip">{selected ? <><Icon layer={selected} />{NAMES[selected.type] || "Element"}{selected.qr ? " · QR" : ""}</> : "Canvas"}</span>
    <span className="context-divider" />
    {selected?.type === "table" && ctx.cellTextMode ? <TableTextProperties key={selected.id} ctx={ctx} /> : selected?.type === "table" ? <TableProperties key={selected.id} ctx={ctx} /> : selected?.type === "text" ? <TextProperties key={selected.id} ctx={ctx} activeMenu={popover} onMenu={name => setPopover(popover === name ? null : name)} /> : <>
      {!selected && <>
        <label className="context-field"><span>W</span><input className="context-input short" type="number" min={64} max={5000} value={ctx.doc.width} aria-label="Canvas width" onChange={event => ctx.changeDoc({ ...ctx.doc, width: Math.min(5000, Math.max(64, Number(event.target.value))) })} /></label>
        <label className="context-field"><span>H</span><input className="context-input short" type="number" min={64} max={5000} value={ctx.doc.height} aria-label="Canvas height" onChange={event => ctx.changeDoc({ ...ctx.doc, height: Math.min(5000, Math.max(64, Number(event.target.value))) })} /></label>
        <button data-popover-trigger="background" className={`context-button context-fill-main ${popover === "background" ? "active" : ""}`} aria-label="Canvas background fill" aria-expanded={popover === "background"} title="Background: solid, gradient or image" onClick={() => setPopover(popover === "background" ? null : "background")}><span className="context-swatch context-swatch-lg" style={{ background: backgroundSwatch }} /><span className="context-fill-label">Background</span><ChevronDown size={13} /></button>
        <button className="context-button" onClick={() => onOpenPanel("background")}><Sparkles size={14} />Backgrounds</button>
        <button className="context-button" onClick={() => onOpenPanel("design")}><Maximize size={14} />Presets</button>
      </>}
      {selected?.type === "image" && isQR && <>
        <button className="context-button" onClick={() => onOpenPanel("qr")}><QrCode size={14} />Edit QR code</button>
        <button className={`context-button ${ctx.tool === "effects" ? "active" : ""}`} onClick={() => onOpenPanel("effects")}><Wand2 size={14} />Effects</button>
      </>}
      {selected?.type === "image" && !isQR && <>
        <button className={`context-button ${ctx.cropMode ? "active" : ""}`} onClick={() => ctx.setCropMode(!ctx.cropMode)}><Crop size={14} />{ctx.cropMode ? "Done crop" : "Crop photo"}</button>
        {ctx.cropMode && <RangeControl compact label="Crop zoom" min={1} max={4} step={0.05} value={selected.cropZoom || 1} unit="×" onChange={v => ctx.patch(selected.id, { cropZoom: v })} />}
        <RemoveBackgroundButton key={selected.id} ctx={ctx} />
        <button data-popover-trigger="mask" className={`context-button ${selected.mask && selected.mask !== "none" ? "active" : ""}`} aria-label="Mask image" onClick={() => setPopover(popover === "mask" ? null : "mask")}>Mask</button>
      </>}
      {selected && selected.type !== "image" && <button data-popover-trigger="fill" className="context-button" aria-label="Element fill" onClick={() => setPopover(popover === "fill" ? null : "fill")}><span className="context-swatch" style={{ background: selected.fillImage ? `url(${resolveAsset(selected.fillImage)}) center/cover` : selected.fillGradient ? gradientCss(selected.fillGradient) : colorValue, opacity: selected.fillGradient || selected.fillImage ? 1 : (selected.fillAlpha ?? 1) }} />{selected.fillImage ? "Image" : selected.fillGradient ? "Gradient" : String(colorValue).toUpperCase().slice(0, 8)}<ChevronDown size={13} /></button>}
      {selected && <button className={`context-icon ${selected.hidden ? "active" : ""}`} aria-label={selected.hidden ? "Show element" : "Hide element"} title={selected.hidden ? "Show" : "Hide"} onClick={() => ctx.patch(selected.id, { hidden: !selected.hidden })}>{selected.hidden ? <EyeOff size={16} /> : <Eye size={16} />}</button>}
      {selected?.type === "image" && !selected.qr && <button className="context-button" onClick={() => onOpenPanel("effects")}><Wand2 size={14} />Image options</button>}
      {selected && (selected.type === "icon" || selected.type === "shape" || selected.type === "stroke" || selected.type === "draw") && <button className="context-button" onClick={() => onOpenPanel("effects")}><Wand2 size={14} />More effects</button>}
      {selected && <button className="context-icon" aria-label="Clear selection" title="Clear selection" onClick={() => ctx.select(null)}><X size={16} /></button>}
    </>}

    {popoverPos && popover === "fill" && selected && createPortal(<div data-context-popover className="context-popover fixed fill-popover" style={{ left: popoverPos.x, top: popoverPos.y, width: 268 }}>
      <FillPicker layer={selected} brandColors={colors} onPatch={updates => ctx.patch(selected.id, updates)} onUploadFill={file => ctx.uploadFillImage(file)} />
    </div>, document.body)}

    {popoverPos && popover === "background" && !selected && createPortal(<div data-context-popover className="context-popover fixed fill-popover" style={{ left: popoverPos.x, top: popoverPos.y, width: 268 }}>
      <p className="context-popover-title">Canvas background</p>
      <FillPicker layer={backgroundLayer} brandColors={colors} onPatch={patchBackground} onUploadFill={file => void ctx.uploadBackgroundImage(file)} />
    </div>, document.body)}

    {popoverPos && popover === "mask" && selected && createPortal(<div data-context-popover className="context-popover fixed" style={{ left: popoverPos.x, top: popoverPos.y, width: 240 }}>
      <p className="context-popover-title">Photo mask</p>
      <div className="mask-grid">{MASKS.map(mask => <button key={mask.key} className={(selected.mask || "none") === mask.key ? "active" : ""} aria-label={`${mask.name} mask`} onClick={() => ctx.patch(selected.id, { mask: mask.key === "none" ? undefined : mask.key })}>{mask.name}</button>)}</div>
    </div>, document.body)}

    {popoverPos && popover === "spacing" && selected?.type === "text" && createPortal(<div className="context-popover fixed text-spacing-popover" data-context-popover data-keep-text-editing style={{ left: popoverPos.x, top: popoverPos.y, width: 260 }}>
      <p className="context-popover-title">Line Spacing</p>
      <RangeControl label="Letter spacing" min={-5} max={30} step={.5} value={selected.letterSpacing || 0} unit="px" onChange={v => ctx.patch(selected.id, { letterSpacing: v })} />
      <RangeControl label="Line spacing" min={.8} max={3} step={.05} value={selected.lineHeight ?? 1.13} onChange={v => ctx.patch(selected.id, { lineHeight: v })} />
      <RangeControl label="Word spacing" min={50} max={250} step={5} value={Math.round((selected.wordSpacing ?? 1) * 100)} unit="%" onChange={v => ctx.patch(selected.id, { wordSpacing: v / 100 })} />
      <button className="secondary-button full-width" onClick={() => ctx.patch(selected.id, { letterSpacing: 0, lineHeight: 1.13, wordSpacing: 1 })}>Reset spacing</button>
    </div>, document.body)}

    {popoverPos && popover === "case" && selected?.type === "text" && createPortal(<div data-context-popover className="context-popover fixed" style={{ left: popoverPos.x, top: popoverPos.y, width: 210 }}>
      <p className="context-popover-title">Text case</p>
      <div className="context-case-list">{([["upper", "UPPERCASE"], ["lower", "lowercase"], ["title", "Title Case"], ["sentence", "Sentence case"], ["toggle", "tOGGLE cASE"]] as [TextCase, string][]).map(([mode, label]) => <button key={mode} aria-label={`Apply ${label}`} onClick={() => ctx.patch(selected.id, { text: transformCase(selected.text || "", mode) })}>{label}</button>)}</div>
    </div>, document.body)}

    {popoverPos && popover === "list" && selected?.type === "text" && createPortal(<div data-context-popover className="context-popover fixed" style={{ left: popoverPos.x, top: popoverPos.y, width: 260 }}>
      <div className="typo-tab-row" role="tablist">
        <button className={listTab === "bullets" ? "active" : ""} onClick={() => setListTab("bullets")}>Bullets</button>
        <button className={listTab === "numbers" ? "active" : ""} onClick={() => setListTab("numbers")}>Numbered</button>
      </div>

      {listTab === "bullets" && <>
        <p className="context-popover-title">Word Bullet Library</p>
        <div className="list-style-grid">
          {BULLET_VARIANTS.map(item => {
            const active = selected.listStyle === "bullet" && (selected.listBulletVariant || "bullet") === item.key;
            return <button key={item.key} className={active ? "active" : ""} aria-label={item.name} title={item.name} onClick={() => ctx.patch(selected.id, { listStyle: "bullet", listBulletVariant: item.key })} style={{ fontSize: 18, fontWeight: 700 }}>
              {item.mark}
            </button>;
          })}
        </div>
        <button className="secondary-button full-width" style={{ marginTop: 8 }} onClick={() => ctx.patch(selected.id, { listStyle: undefined, listBulletVariant: undefined })}>Remove bullets</button>
      </>}

      {listTab === "numbers" && <>
        <p className="context-popover-title">Word Numbering Library</p>
        <div className="typo-number-grid">
          {NUMBER_FORMATS.map(fmt => {
            const active = selected.listStyle === "number" && (selected.listNumberFormat || "number") === fmt.key;
            return <button key={fmt.key} className={active ? "active" : ""} title={fmt.name} onClick={() => ctx.patch(selected.id, { listStyle: "number", listNumberFormat: fmt.key })}>
              <span>{fmt.sample}</span>
              <small style={{ color: "#9a85b3" }}>{fmt.name.split(" ")[0]}</small>
            </button>;
          })}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", margin: "8px 0" }}>
          <span style={{ fontSize: 11, color: "#7a628e" }}>Start numbering at:</span>
          <input type="number" min={1} max={9999} style={{ width: 60, height: 26, border: "1px solid #d8c6ec", borderRadius: 4, padding: "0 6px", fontSize: 11, textAlign: "center" }} value={selected.listStart || 1} onChange={e => ctx.patch(selected.id, { listStart: Math.max(1, Number(e.target.value) || 1) })} />
        </div>
        <button className="secondary-button full-width" onClick={() => ctx.patch(selected.id, { listStyle: undefined, listNumberFormat: undefined, listStart: undefined })}>Remove numbering</button>
      </>}
    </div>, document.body)}

    {popoverPos && popover === "fraction" && selected?.type === "text" && createPortal(<div data-context-popover className="context-popover fixed text-spacing-popover" style={{ left: popoverPos.x, top: popoverPos.y, width: 260 }}>
      <p className="context-popover-title">Fraction Style</p>
      <div className="typo-tab-row" role="tablist">
        <button className={fracMode === "normal" ? "active" : ""} onClick={() => setFracMode("normal")} title="Normal inline fraction (e.g. 2½)">Normal (½)</button>
        <button className={fracMode === "super" ? "active" : ""} onClick={() => setFracMode("super")} title="Superscript fraction — exponent style (e.g. 2½)">Super (^½)</button>
        <button className={fracMode === "sub" ? "active" : ""} onClick={() => setFracMode("sub")} title="Subscript fraction — chemical style (e.g. CH½)">Sub (v½)</button>
      </div>

      <p className="context-popover-title">Quick Fractions</p>
      <div className="fraction-grid">
        {FRACTION_GALLERY.map(item => (
          <button
            key={item.symbol}
            onClick={() => applyFraction(item.symbol, fracMode)}
            title={`${item.label} · Insert as ${fracMode === "super" ? "superscript" : fracMode === "sub" ? "subscript" : "normal"} fraction`}
          >
            {item.symbol}
          </button>
        ))}
      </div>

      <p className="context-popover-title">Custom Fraction</p>
      <div className="fraction-custom-row">
        <input
          type="text"
          maxLength={4}
          aria-label="Numerator"
          value={customNum}
          onChange={e => setCustomNum(e.target.value.replace(/[^\d]/g, ""))}
          placeholder="1"
        />
        <span>/</span>
        <input
          type="text"
          maxLength={4}
          aria-label="Denominator"
          value={customDen}
          onChange={e => setCustomDen(e.target.value.replace(/[^\d]/g, ""))}
          placeholder="2"
        />
        <button
          className="secondary-button"
          style={{ flex: 1, minHeight: 28, fontSize: 10 }}
          onClick={() => {
            if (!customNum.trim() || !customDen.trim()) return;
            const frac = formatFraction(customNum, customDen);
            applyFraction(frac, fracMode);
          }}
        >
          Insert {fracMode === "super" ? "^" : fracMode === "sub" ? "v" : ""}{formatFraction(customNum || "1", customDen || "2")}
        </button>
      </div>

      <button
        className="secondary-button full-width"
        style={{ marginTop: 2, marginBottom: 8 }}
        onClick={convertAllFractionsInText}
        title="Finds any 1/2, 3/4, etc. in the whole text box and turns them into typographic fractions"
      >
        Convert all “a/b” in text
      </button>

      <p className="context-popover-note" style={{ lineHeight: 1.7 }}>
        <strong>How to use:</strong><br />
        1. Pick a position: <strong>Normal (½)</strong>, <strong>Super (^½)</strong>, or <strong>Sub (v½)</strong>.<br />
        2. Click a quick fraction, or enter your own numerator / denominator and press Insert.<br />
        <span style={{ display: "block", marginTop: 6 }}>
          <strong>Examples:</strong><br />
          • Normal → <strong>2½</strong> &nbsp;• Super → <strong>2¹⁄₂</strong> &nbsp;• Sub → <strong>CH₁⸝₂</strong>
        </span>
      </p>
    </div>, document.body)}
    </div>
  </div>;
}
