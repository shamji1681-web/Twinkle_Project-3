import { useCallback, useEffect, useRef, useState, type ElementType } from "react";
import { ArrowDownToLine, ArrowRight, Bell, BookOpen, Check, ChevronDown, ChevronRight, CircleHelp, Clapperboard, Coffee, Copy, CreditCard, Crown, Ellipsis, Flag, FlagTriangleRight, Flower2, Folder, Gift, Globe, Grid2X2, Heart, House, IdCard, ImagePlus, Camera as Instagram, Layers, LayoutGrid, LayoutTemplate, List, MailOpen, Megaphone, Menu, Monitor, Moon, NotebookPen, Palette, Pencil, PenLine, Plus, Presentation, Printer, ReceiptText, RotateCcw, ScrollText, Search, Settings2, Shirt, Smartphone, Sparkles, Star, Sun, Trash2, Upload, Video, X, FileText, ArrowUpRight } from "lucide-react";
import { blankDocument, categories, cloneDocument, templates, type DesignDocument, type DesignProject, type DesignTemplate, type Workspace } from "@/lib/designs";
import { readImage } from "@/lib/export";
import { resolveAsset } from "@/lib/asset-map";
import DesignCanvas from "@/components/design-canvas";
import Editor from "@/components/editor";
import { api, EmptyState, Logo, Modal, Spinner, timeAgo, Toast } from "@/components/ui";
import { toggleTheme, useTheme } from "@/lib/theme";

type View = "home" | "templates" | "projects" | "brand" | "starred" | "trash";
type Dialog = "create" | "pro" | "help" | "account" | "app" | null;
interface InstallPrompt extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }
// One icon per category, chosen to match what that product actually is.
const categoryIcons: ElementType[] = [
  LayoutGrid,        // All
  CreditCard,        // Business card
  IdCard,            // ID card
  PenLine,           // Letterhead
  MailOpen,          // Envelope
  Megaphone,         // Flayer (promotional flyer)
  ScrollText,        // Boucher (brochure)
  Coffee,            // Mug
  Shirt,             // T-Shirt
  NotebookPen,       // Dairie (diary)
  ReceiptText,       // Bill & Vouch Book
  FlagTriangleRight, // Banner
  Gift,              // Customise Gift
  Instagram,         // Social Media
  Globe,             // Websites
  Clapperboard,      // Video
  Ellipsis,          // More
];
const viewTitles: Record<View, string> = { home: "Home", templates: "Templates", projects: "Your projects", brand: "Brand kit", starred: "Starred", trash: "Trash" };
const formats = [
  { name: "Business card", category: "Business card", width: 1050, height: 600, icon: CreditCard, color: "blue" },
  { name: "ID card", category: "ID card", width: 660, height: 1040, icon: IdCard, color: "purple" },
  { name: "Letterhead", category: "Letterhead", width: 850, height: 1100, icon: PenLine, color: "green" },
  { name: "Envelope", category: "Envelope", width: 1000, height: 500, icon: MailOpen, color: "orange" },
  { name: "Flyer", category: "Flayer", width: 1000, height: 1400, icon: Megaphone, color: "pink" },
  { name: "Brochure", category: "Boucher", width: 1400, height: 1000, icon: ScrollText, color: "mint" },
  { name: "Mug wrap", category: "Mug", width: 2400, height: 1100, icon: Coffee, color: "orange" },
  { name: "T-shirt print", category: "T-Shirt", width: 1800, height: 2400, icon: Shirt, color: "blue" },
  { name: "Diary cover", category: "Dairie", width: 1000, height: 1400, icon: NotebookPen, color: "purple" },
  { name: "Bill book", category: "Bill & Vouch Book", width: 1200, height: 800, icon: ReceiptText, color: "green" },
  { name: "Flex banner", category: "Banner", width: 2000, height: 800, icon: FlagTriangleRight, color: "pink" },
  { name: "Gift photo frame", category: "Customise Gift", width: 1200, height: 1200, icon: Gift, color: "mint" },
  { name: "Instagram post", category: "Social Media", width: 1080, height: 1080, icon: Instagram, color: "pink" },
  { name: "Instagram story", category: "Social Media", width: 1080, height: 1920, icon: Smartphone, color: "purple" },
  { name: "Website hero", category: "Websites", width: 1600, height: 1000, icon: Globe, color: "green" },
  { name: "Video cover", category: "Video", width: 1600, height: 900, icon: Clapperboard, color: "mint" },
  { name: "Poster", category: "More", width: 1200, height: 1600, icon: Printer, color: "blue" },
  { name: "Document", category: "More", width: 850, height: 1100, icon: FileText, color: "green" },
];

export default function Dashboard() {
  const [view, setView] = useState<View>("home");
  const [workspace, setWorkspace] = useState<Workspace | null>(null);
  const [projects, setProjects] = useState<DesignProject[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [dialog, setDialog] = useState<Dialog>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [editor, setEditor] = useState<DesignProject | null>(null);
  const [toast, setToast] = useState<{ message: string; error?: boolean } | null>(null);
  const [projectMenu, setProjectMenu] = useState<string | null>(null);
  const [rename, setRename] = useState<DesignProject | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteProject, setDeleteProject] = useState<DesignProject | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [listMode, setListMode] = useState(false);
  const [sort, setSort] = useState("recent");
  const [notifications, setNotifications] = useState(false);
  const [unread, setUnread] = useState(true);
  const [installPrompt, setInstallPrompt] = useState<InstallPrompt | null>(null);
  const [customWidth, setCustomWidth] = useState("1080");
  const [customHeight, setCustomHeight] = useState("1080");
  const [accountName, setAccountName] = useState("");
  const [busy, setBusy] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const theme = useTheme();
  const closeToast = useCallback(() => setToast(null), []);
  const notify = useCallback((message: string, error = false) => setToast({ message, error }), []);
  const proActive = !!workspace?.trialStartedAt && Date.now() - new Date(workspace.trialStartedAt).getTime() < 14 * 86400000;

  const loadWorkspace = useCallback(async () => {
    setLoading(true); setLoadError(false);
    try {
      const data = await api<{ workspace: Workspace; designs: DesignProject[] }>("/api/workspace");
      setWorkspace(data.workspace); setProjects(data.designs); setAccountName(data.workspace.name);
      const id = new URLSearchParams(window.location.search).get("design");
      if (id) setEditor(data.designs.find(p => p.id === id && !p.trashed) || null);
    } catch { setLoadError(true); notify("Your workspace couldn't load. Please try again.", true); }
    finally { setLoading(false); }
  }, [notify]);

  useEffect(() => {
    void loadWorkspace();
    try { setFavorites(JSON.parse(localStorage.getItem("creato-favorites") || "[]")); } catch { /* A new workspace starts with no saved templates. */ }
    function keyboard(event: KeyboardEvent) { if ((event.metaKey || event.ctrlKey) && event.key === "k") { event.preventDefault(); searchRef.current?.focus(); } }
    function install(event: Event) { event.preventDefault(); setInstallPrompt(event as InstallPrompt); }
    document.addEventListener("keydown", keyboard);
    window.addEventListener("beforeinstallprompt", install);
    return () => { document.removeEventListener("keydown", keyboard); window.removeEventListener("beforeinstallprompt", install); };
  }, [loadWorkspace]);

  useEffect(() => {
    function pop() { const id = new URLSearchParams(window.location.search).get("design"); setEditor(id ? projects.find(p => p.id === id) || null : null); }
    window.addEventListener("popstate", pop);
    return () => window.removeEventListener("popstate", pop);
  }, [projects]);

  useEffect(() => {
    if (!projectMenu && !notifications) return;
    function close(event: MouseEvent) { if (!(event.target as HTMLElement).closest("[data-popup]")) { setProjectMenu(null); setNotifications(false); } }
    function escape(event: KeyboardEvent) { if (event.key === "Escape") { setProjectMenu(null); setNotifications(false); } }
    document.addEventListener("click", close); document.addEventListener("keydown", escape);
    return () => { document.removeEventListener("click", close); document.removeEventListener("keydown", escape); };
  }, [projectMenu, notifications]);

  function navigate(next: View) { setView(next); setSearch(""); setCategory("All"); setMobileOpen(false); setProjectMenu(null); window.scrollTo({ top: 0, behavior: "smooth" }); }
  function updateProject(project: DesignProject) { setProjects(current => [project, ...current.filter(p => p.id !== project.id)]); }
  function openEditor(project: DesignProject) { setEditor(project); setProjectMenu(null); window.history.pushState({}, "", `?design=${project.id}`); }
  function closeEditor() { setEditor(null); window.history.replaceState({}, "", window.location.pathname); }

  async function createDesign(content: DesignDocument, title: string, designCategory: string) {
    if (!workspace) { notify("Please wait for your workspace to load.", true); return; }
    setCreating(true);
    try {
      const project = await api<DesignProject>("/api/designs", { method: "POST", body: JSON.stringify({ title, category: designCategory, content: cloneDocument(content) }) });
      updateProject(project); setDialog(null); openEditor(project);
    } catch (error) { notify((error as Error).message, true); }
    finally { setCreating(false); }
  }

  function useTemplate(template: DesignTemplate) {
    if (template.pro && !proActive) { setDialog("pro"); return; }
    void createDesign(template.content, template.title, template.category);
  }

  async function patchProject(project: DesignProject, updates: Partial<DesignProject>, message?: string) {
    setBusy(true);
    try {
      const updated = await api<DesignProject>(`/api/designs/${project.id}`, { method: "PATCH", body: JSON.stringify(updates) });
      updateProject(updated); if (message) notify(message); return true;
    } catch (error) { notify((error as Error).message, true); return false; }
    finally { setBusy(false); setProjectMenu(null); }
  }

  async function duplicate(project: DesignProject) {
    setProjectMenu(null); setBusy(true);
    try { const copy = await api<DesignProject>("/api/designs", { method: "POST", body: JSON.stringify({ title: `${project.title.slice(0, 110)} (copy)`, category: project.category, content: project.content }) }); updateProject(copy); notify("A fresh copy is ready in your projects."); }
    catch (error) { notify((error as Error).message, true); }
    finally { setBusy(false); }
  }

  function toggleFavorite(id: string) {
    const next = favorites.includes(id) ? favorites.filter(f => f !== id) : [...favorites, id];
    setFavorites(next); localStorage.setItem("creato-favorites", JSON.stringify(next));
    notify(next.includes(id) ? "Template added to Starred." : "Template removed from Starred.");
  }

  async function saveWorkspace(updates: Record<string, unknown>) {
    const updated = await api<Workspace>("/api/workspace", { method: "PATCH", body: JSON.stringify(updates) });
    setWorkspace(updated); return updated;
  }

  const normalizedSearch = search.toLowerCase().trim();
  const visibleTemplates = templates.filter(t => (category === "All" || t.category.toLowerCase() === category.toLowerCase()) && `${t.title} ${t.tag} ${t.category}`.toLowerCase().includes(normalizedSearch));
  const visibleProjects = projects.filter(p => (view === "trash" ? p.trashed : !p.trashed) && (view !== "starred" || p.starred) && `${p.title} ${p.category}`.toLowerCase().includes(normalizedSearch)).sort((a, b) => sort === "name" ? a.title.localeCompare(b.title) : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  const renderTemplate = (template: DesignTemplate) => <article className="template-card" key={template.id}>
    <div className="template-image" style={{ background: template.content.background }}>
      <button className="template-open" onClick={() => useTemplate(template)} aria-label={`Use ${template.title} template`} disabled={creating}><DesignCanvas document={template.content} /><span className="template-hover">Make it yours <ArrowRight size={14} /></span></button>
      <button className={`favorite-button ${favorites.includes(template.id) ? "is-favorite" : ""}`} onClick={() => toggleFavorite(template.id)} aria-label={`${favorites.includes(template.id) ? "Unstar" : "Star"} ${template.title}`}><Star size={15} fill={favorites.includes(template.id) ? "currentColor" : "none"} /></button>
      {template.pro && <span className="template-pro" title="Premium template"><Crown size={12} fill="currentColor" /></span>}
    </div>
    <button className="template-title" onClick={() => useTemplate(template)}>{template.title}</button><p>{template.tag}</p>
  </article>;

  const renderProject = (project: DesignProject) => <article className={`project-card ${listMode ? "project-list-card" : ""} ${projectMenu === project.id ? "menu-open" : ""}`} key={project.id}>
    <button className="project-image" style={{ background: project.content.background }} onClick={() => view === "trash" ? notify("Restore this design to continue editing.") : openEditor(project)} aria-label={`Open ${project.title}`}><DesignCanvas document={project.content} />{project.starred && <span className="project-star"><Star size={12} fill="currentColor" /></span>}</button>
    <div className="project-details"><button className="project-title" onClick={() => view === "trash" ? notify("Restore this design to continue editing.") : openEditor(project)}>{project.title}</button><p>{project.category} <span>·</span> Edited {timeAgo(project.updatedAt)}</p></div>
    <div className="project-menu-wrap" data-popup><button className={`icon-button project-more ${projectMenu === project.id ? "selected" : ""}`} aria-label={`Options for ${project.title}`} aria-expanded={projectMenu === project.id} onClick={() => setProjectMenu(projectMenu === project.id ? null : project.id)}><Ellipsis size={19} /></button>
      {projectMenu === project.id && <div className="dropdown project-dropdown">{view === "trash" ? <><button onClick={() => void patchProject(project, { trashed: false }, "Design restored to your projects.")}><RotateCcw size={16} /> Restore design</button><button className="danger-text" onClick={() => { setDeleteProject(project); setProjectMenu(null); }}><Trash2 size={16} /> Delete permanently</button></> : <><button onClick={() => openEditor(project)}><Pencil size={15} /> Edit design</button><button onClick={() => { setRename(project); setRenameValue(project.title); setProjectMenu(null); }}><FileText size={15} /> Rename</button><button onClick={() => void duplicate(project)}><Copy size={15} /> Make a copy</button><button onClick={() => void patchProject(project, { starred: !project.starred }, project.starred ? "Removed from Starred." : "Added to Starred.")}><Star size={15} /> {project.starred ? "Remove from Starred" : "Add to Starred"}</button><span className="dropdown-divider" /><button className="danger-text" onClick={() => void patchProject(project, { trashed: true }, "Design moved to Trash.")}><Trash2 size={15} /> Move to Trash</button></>}</div>}
    </div>
  </article>;

  return <>
    <div className="app-shell">
      {mobileOpen && <button className="sidebar-overlay" onClick={() => setMobileOpen(false)} aria-label="Close navigation" />}
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <button className="sidebar-brand" onClick={() => navigate("home")} aria-label="Creato home"><Logo /></button>
        <button className="workspace-switch" onClick={() => { setAccountName(workspace?.name || ""); setDialog("account"); }}><span className="workspace-avatar">{(workspace?.name || "Alex").charAt(0)}</span><span><strong>Personal workspace</strong><small>{proActive ? "Pro trial" : "Free plan"}</small></span><ChevronDown size={14} /></button>
        <nav aria-label="Main navigation" className="main-nav">
          {([{ id: "home", icon: House, label: "Home" }, { id: "templates", icon: LayoutTemplate, label: "Templates" }, { id: "projects", icon: Folder, label: "Your projects" }, { id: "brand", icon: Palette, label: "Brand kit" }] as { id: View; icon: ElementType; label: string }[]).map(({ id, icon: Icon, label }) => <button key={id} className={`nav-item ${view === id ? "active" : ""}`} onClick={() => navigate(id)}><Icon size={19} strokeWidth={1.8} /><span>{label}</span>{id === "brand" && <Crown size={13} className="nav-crown" />}</button>)}
          <div className="nav-divider" /><p className="nav-label">YOUR WORKSPACE</p>
          <button className={`nav-item ${view === "starred" ? "active" : ""}`} onClick={() => navigate("starred")}><Star size={19} strokeWidth={1.8} /><span>Starred</span></button>
          <button className={`nav-item ${view === "trash" ? "active" : ""}`} onClick={() => navigate("trash")}><Trash2 size={19} strokeWidth={1.8} /><span>Trash</span></button>
        </nav>
        <div className="sidebar-bottom"><button className="mobile-app-link" onClick={() => setDialog("app")}><Smartphone size={17} /><span>Create on the go</span><ArrowUpRight size={14} /></button><div className="pro-card"><span className="pro-card-icon"><Crown size={21} /></span><span className="pro-decoration">✦</span><h3>{proActive ? "Your ideas. No limits." : "A little more possibility."}</h3><p>{proActive ? "Your Pro trial is ready to explore." : "Big ideas deserve a little Pro magic."}</p><button onClick={() => setDialog("pro")}><Sparkles size={14} />{proActive ? "Explore your Pro trial" : "Try Pro for free"}</button></div><div className="profile"><button className="profile-main" onClick={() => { setAccountName(workspace?.name || ""); setDialog("account"); }}><span className="user-avatar">{(workspace?.name || "Alex Morgan").split(" ").map(s => s.charAt(0)).slice(0, 2).join("")}</span><span><strong>{workspace?.name || "Alex Morgan"}</strong><small>Personal account</small></span></button><button className="icon-button" aria-label="Account settings" onClick={() => { setAccountName(workspace?.name || ""); setDialog("account"); }}><Ellipsis size={18} /></button></div></div>
      </aside>
      <main className="main-shell">
        <header className="topbar"><div className="topbar-left"><button className="icon-button hamburger" onClick={() => setMobileOpen(true)} aria-label="Open navigation"><Menu size={21} /></button><span className="header-page">{viewTitles[view]}</span><span className="header-slash">/</span><span className="header-subtitle">Your creative space</span></div><div className="topbar-actions"><button className="icon-button theme-toggle" aria-label={theme === "dark" ? "Switch to day mode" : "Switch to night mode"} title={theme === "dark" ? "Day mode" : "Night mode"} onClick={toggleTheme}>{theme === "dark" ? <Sun size={19} /> : <Moon size={19} />}</button><button className="icon-button help-button" aria-label="Help and resources" onClick={() => setDialog("help")}><CircleHelp size={20} /></button><div className="notification-wrap" data-popup><button className="icon-button notification-button" aria-label="Notifications" aria-expanded={notifications} onClick={() => { setNotifications(!notifications); setUnread(false); }}><Bell size={19} />{unread && <i />}</button>{notifications && <div className="dropdown notifications"><h3>A little inspiration for you</h3><div><span className="notification-icon"><Sparkles size={19} /></span><p><strong>Your next great idea starts here</strong><small>Explore {templates.length} fresh, fully editable templates.</small></p></div><div><span className="notification-icon green"><Check size={18} /></span><p><strong>Your workspace is all set</strong><small>Your designs save automatically as you create.</small></p></div><button onClick={() => { navigate("templates"); setNotifications(false); }}>Find your next template <ArrowRight size={15} /></button></div>}</div><span className="topbar-divider" /><button className="primary-button create-top" disabled={creating || loading} onClick={() => setDialog("create")}>{creating ? <Spinner size={17} /> : <Plus size={18} />}<span>Create a design</span></button></div></header>
        <div className="page-content">
          {loadError && <div className="load-error"><span>We couldn’t connect to your workspace.</span><button onClick={() => void loadWorkspace()}>Try again <RotateCcw size={14} /></button></div>}
          {view === "home" && <>
            <section className="hero"><div className="hero-content"><div className="hero-eyebrow"><Sparkles size={13} /> A LITTLE IDEA. ENDLESS POSSIBILITIES.</div><h1>What will you <span>design</span> today?</h1><p>Bring your ideas to life. A little inspiration is all it takes.</p><form className="hero-search" onSubmit={event => { event.preventDefault(); setView("templates"); }}><Search size={19} /><input ref={searchRef} value={search} onChange={e => setSearch(e.target.value)} placeholder="Search templates, styles, and inspiration" aria-label="Search templates" />{search ? <button type="button" onClick={() => setSearch("")} aria-label="Clear search"><X size={16} /></button> : <kbd>⌘ K</kbd>}</form></div><div className="hero-art" aria-hidden="true"><span className="hero-dotted-orbit" /><span className="art-spark spark-one">✦</span><span className="art-spark spark-two">✳</span><div className="art-card art-orange"><DesignCanvas document={templates.find(t => t.id === "make-something")!.content} /></div><div className="art-card art-photo"><img src={resolveAsset("/images/interior.jpg")} alt="" /><span>a fresh perspective.</span></div><div className="art-card art-green"><DesignCanvas document={templates[3].content} /></div><span className="made-by-you">a little more you <Heart size={11} /></span></div></section>
          </>}
          {view === "templates" && <div className="page-heading"><div><span className="eyebrow">START WITH SOMETHING YOU LOVE</span><h1>A template for every idea.</h1><p>Beautifully designed. Endlessly customizable. Completely yours.</p></div><div className="standard-search"><Search size={18} /><input ref={searchRef} value={search} onChange={e => setSearch(e.target.value)} placeholder="Find your perfect template" aria-label="Search templates" />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={16} /></button>}</div></div>}
          {(view === "home" || view === "templates") && <>
            <div className="category-row" role="group" aria-label="Design categories">{categories.map((name, index) => { const Icon = categoryIcons[index]; return <button key={name} className={`category-item category-${index} ${category === name ? "category-active" : ""}`} onClick={() => { if (name === "More") { setView("templates"); setCategory("More"); } else setCategory(name); }} aria-pressed={category === name}><span className="category-icon"><Icon size={24} strokeWidth={1.65} /></span><span>{name}</span></button>; })}</div>
            <section className="template-section"><div className="section-heading"><div><h2>{normalizedSearch ? `Templates for “${search}”` : category === "All" ? view === "home" ? "A little inspiration to get you started" : "Find your next favorite" : `${category} templates`}{view === "home" && !normalizedSearch && <span className="little-spark">✧</span>}</h2><p>{view === "home" ? "Fresh templates. A world of possibilities." : `${visibleTemplates.length} thoughtfully designed templates to make your own.`}</p></div>{view === "home" && <button className="text-button" onClick={() => { setView("templates"); window.scrollTo({ top: 0, behavior: "smooth" }); }}>Explore all templates <ArrowRight size={15} /></button>}</div>{visibleTemplates.length ? <div className={`template-grid ${view === "templates" ? "all-templates" : ""}`}>{(view === "home" ? visibleTemplates.slice(0, 5) : visibleTemplates).map(renderTemplate)}</div> : <EmptyState title="No templates just yet" description="Try a different search or explore another category." action={<button className="secondary-button" onClick={() => { setSearch(""); setCategory("All"); }}>Explore all templates</button>} />}</section>
          </>}
          {(view === "home" || view === "projects" || view === "starred" || view === "trash") && <section className={`projects-section ${view !== "home" ? "full-projects" : ""}`}>
            {view !== "home" && <div className="page-heading"><div><span className="eyebrow">A SPACE FOR YOUR IDEAS</span><h1>{view === "projects" ? "Made by you." : view === "starred" ? "Your favorites, all together." : "A second chance for your ideas."}</h1><p>{view === "projects" ? "Every big idea, work in progress, and little masterpiece." : view === "starred" ? "The designs and templates you keep coming back to." : "Restore a design, or let it go for good. Nothing is deleted automatically."}</p></div><div className="standard-search"><Search size={18} /><input ref={searchRef} value={search} onChange={e => setSearch(e.target.value)} placeholder="Search your designs" aria-label="Search your designs" /></div></div>}
            <div className="section-heading recent-heading"><div><h2>{view === "home" ? "Pick up where you left off" : view === "trash" ? "Recently removed" : view === "starred" ? "Starred designs" : "All your designs"}{view !== "home" && <span className="count-badge">{visibleProjects.length}</span>}</h2>{view === "home" && <p>Your ideas, still in the making.</p>}</div><div className="section-actions">{view === "home" ? <button className="text-button" onClick={() => navigate("projects")}>View all projects <ArrowRight size={15} /></button> : <select className="sort-select" aria-label="Sort projects" value={sort} onChange={e => setSort(e.target.value)}><option value="recent">Last edited</option><option value="name">Name A–Z</option></select>}<div className="view-toggle"><button className={!listMode ? "active" : ""} onClick={() => setListMode(false)} aria-label="Grid view" aria-pressed={!listMode}><Grid2X2 size={15} /></button><button className={listMode ? "active" : ""} onClick={() => setListMode(true)} aria-label="List view" aria-pressed={listMode}><List size={16} /></button></div></div></div>
            {loading ? <div className="project-grid">{[0, 1, 2, 3].map(n => <div key={n} className="project-skeleton"><span /><i /><i /></div>)}</div> : visibleProjects.length ? <div className={listMode ? "project-list" : "project-grid"}>{(view === "home" ? visibleProjects.slice(0, 4) : visibleProjects).map(renderProject)}</div> : <EmptyState title={search ? "No matching designs" : view === "trash" ? "A clean slate" : view === "starred" ? "Keep your favorites close" : "Your next idea belongs here"} description={search ? "Try another keyword to find your design." : view === "trash" ? "Designs you move to Trash will appear here." : view === "starred" ? "Star a design from its menu to find it here." : "Start with a template, or see where a blank canvas takes you."} action={view !== "trash" && <button className="primary-button" onClick={() => setDialog("create")}><Plus size={16} /> Create a design</button>} />}
            {view === "starred" && <section className="starred-templates"><div className="section-heading"><h2>Starred templates <span className="count-badge">{favorites.length}</span></h2></div>{favorites.length ? <div className="template-grid">{templates.filter(t => favorites.includes(t.id)).map(renderTemplate)}</div> : <p className="muted">Tap the star on any template to save a little inspiration for later.</p>}</section>}
          </section>}
          {view === "brand" && workspace && <BrandKit workspace={workspace} onSave={saveWorkspace} notify={notify} />}
          {view === "home" && <div className="bottom-note"><Flower2 size={16} /><span>A blank canvas. A fresh perspective. Something only you can make.</span><button onClick={() => setDialog("create")}>Let’s create <ArrowRight size={14} /></button></div>}
          <footer className="page-footer"><span>A little creativity goes a long way.</span><button onClick={() => setDialog("help")}>Need a hand? <CircleHelp size={13} /></button></footer>
        </div>
      </main>
    </div>
    {editor && <Editor key={editor.id} project={editor} workspace={workspace} onClose={closeEditor} onSaved={updateProject} onOpenProject={next => { updateProject(next); openEditor(next); }} notify={notify} />}
    {dialog === "create" && <Modal title="What would you like to create?" onClose={() => !creating && setDialog(null)} wide><p className="modal-intro">A new idea deserves a fresh canvas. Pick your starting point.</p><div className="format-grid">{formats.map(format => <button key={format.name} className="format-option" disabled={creating} onClick={() => void createDesign(blankDocument(format.width, format.height), `Untitled ${format.name.toLowerCase()}`, format.category)}><span className={`format-icon ${format.color}`}><format.icon size={24} /></span><strong>{format.name}</strong><small>{format.width} × {format.height} px</small><ArrowUpRight size={15} className="format-arrow" /></button>)}</div><div className="custom-size"><div><h3>Have a size in mind?</h3><p>Make a custom canvas, just for you.</p></div><form onSubmit={event => { event.preventDefault(); const width = Number(customWidth), height = Number(customHeight); if (![width, height].every(n => Number.isFinite(n) && n >= 64 && n <= 5000)) return notify("Choose dimensions between 64 and 5000 pixels.", true); void createDesign(blankDocument(width, height), "Untitled design", "Custom design"); }}><label><span>Width</span><input type="number" min="64" max="5000" value={customWidth} onChange={e => setCustomWidth(e.target.value)} required /></label><span className="size-times">×</span><label><span>Height</span><input type="number" min="64" max="5000" value={customHeight} onChange={e => setCustomHeight(e.target.value)} required /></label><span className="size-unit">px</span><button className="primary-button" disabled={creating} type="submit">{creating ? <Spinner /> : <ArrowRight size={18} />}</button></form></div><div className="modal-footnote"><Sparkles size={14} /> Not sure? Start with a template and make it your own.</div></Modal>}
    {dialog === "pro" && <Modal title="A little more magic." onClose={() => setDialog(null)} className="pro-modal"><div className="pro-modal-art"><Crown size={43} strokeWidth={1.3} /><span>CREATO PRO</span><i>✦</i></div><h3>{proActive ? "Your next big idea is unlimited." : workspace?.trialStartedAt ? "Keep your creativity going." : "Great ideas deserve room to grow."}</h3><p>{proActive ? `Your free trial is active until ${new Date(new Date(workspace!.trialStartedAt!).getTime() + 14 * 86400000).toLocaleDateString(undefined, { month: "long", day: "numeric" })}. Explore every premium template and make it yours.` : workspace?.trialStartedAt ? "Your 14-day trial has ended. Your saved designs are still yours, and our free templates and editor are always ready for your next idea." : "Explore every premium template with a 14-day Pro trial. A little extra inspiration, on us."}</p><ul>{["Full access to premium templates", "Beautiful, fully editable artwork", "Keep every design you create"].map(t => <li key={t}><Check size={17} />{t}</li>)}</ul><button className="primary-button full-width" disabled={busy || loading} onClick={async () => { if (proActive || workspace?.trialStartedAt) { setDialog(null); navigate("templates"); return; } setBusy(true); try { await saveWorkspace({ startTrial: true }); setDialog(null); notify("Your 14-day Pro trial is active. Go make something great!"); } catch (error) { notify((error as Error).message, true); } finally { setBusy(false); } }}>{busy ? <Spinner /> : <Sparkles size={17} />}{proActive ? "Explore premium templates" : workspace?.trialStartedAt ? "Explore free templates" : "Start my free trial"}</button><small className="pro-fine-print">No credit card. No automatic charges. Just creativity.</small></Modal>}
    {dialog === "help" && <Modal title="A little help, a lot of possibility." onClose={() => setDialog(null)}><p className="modal-intro">Your quick guide to making something great in Creato.</p><div className="help-steps">{[{ icon: LayoutTemplate, title: "Find your starting point", text: "Browse templates, search for a style, or create a blank canvas in your own size." }, { icon: Pencil, title: "Make it your own", text: "Fifteen panels on the left: design, templates, text, icons, shapes, lines, photos, backgrounds, quotes, tables, drawing, QR codes, uploads, layers, and your brand kit. Click any element to edit it, drag to move it, and use the corner to resize." }, { icon: Folder, title: "Your ideas, safely saved", text: "Edits save automatically in this browser’s personal workspace. Use project menus to rename, copy, star, or restore a design." }, { icon: ArrowDownToLine, title: "Share with the world", text: "Download a crisp PNG or an editable SVG from the editor. Your design is ready to go." }].map(({ icon: Icon, title, text }, index) => <div key={title}><span><Icon size={21} /></span><section><h3>{index + 1}. {title}</h3><p>{text}</p></section></div>)}</div><div className="keyboard-tip"><kbd>⌘ / Ctrl</kbd> + <kbd>K</kbd><span>Find your next idea, faster.</span></div><button className="primary-button full-width" onClick={() => { setDialog(null); setView("templates"); }}>Let’s make something <ArrowRight size={16} /></button></Modal>}
    {dialog === "account" && <Modal title="Your personal workspace" onClose={() => setDialog(null)}><div className="account-avatar"><span className="user-avatar">{(workspace?.name || "A").split(" ").map(s => s.charAt(0)).slice(0, 2).join("")}</span><div><h3>Good to have you here.</h3><p>A little space for everything you create.</p></div></div><form onSubmit={async event => { event.preventDefault(); setBusy(true); try { await saveWorkspace({ name: accountName }); setDialog(null); notify("Your workspace has a fresh new name."); } catch (error) { notify((error as Error).message, true); } finally { setBusy(false); } }}><label className="field-label">Your name<input className="form-input" value={accountName} onChange={e => setAccountName(e.target.value)} maxLength={80} required placeholder="What should we call you?" /></label><div className="workspace-info"><span>Current plan</span><strong>{proActive ? "Creato Pro · Free trial" : "Creato Free"}</strong></div><p className="privacy-note">This is a personal demo workspace, linked to this browser. Designs are stored in the database; clearing your browser cookies disconnects this workspace. No sign-in or email is required.</p><button className="primary-button full-width" disabled={busy || loading} type="submit">{busy ? <Spinner /> : <Check size={17} />}Save changes</button></form></Modal>}
    {dialog === "app" && <Modal title="A little creativity. Wherever you go." onClose={() => setDialog(null)}><div className="mobile-preview"><div className="phone-mockup"><div className="phone-notch" /><Logo /><h3>Big ideas.<br /><em>Small screen.</em></h3><div className="phone-templates"><DesignCanvas document={templates[1].content} /><DesignCanvas document={templates[3].content} /></div><span>Made for your next big idea.</span></div><div className="mobile-spark">✦</div></div><p className="modal-intro">Your creative space works on your phone, too. Install the web app for a full-screen, app-like experience.</p>{installPrompt ? <button className="primary-button full-width" onClick={async () => { await installPrompt.prompt(); const result = await installPrompt.userChoice; if (result.outcome === "accepted") { notify("Creato is ready on your home screen."); setInstallPrompt(null); setDialog(null); } }}><Smartphone size={18} />Add Creato to your home screen</button> : <div className="install-instructions"><p><strong>On Android</strong> Open this site in Chrome → tap ⋮ → Add to Home screen.</p><p><strong>On iPhone</strong> Open in Safari → tap Share → Add to Home Screen.</p></div>}<p className="privacy-note">An internet connection is needed to load and save your designs. This installs the web app, not a native Flutter APK.</p></Modal>}
    {rename && <Modal title="Give your idea a name" onClose={() => setRename(null)}><p className="modal-intro">Something memorable. Something you.</p><form onSubmit={async e => { e.preventDefault(); if (await patchProject(rename, { title: renameValue }, "Design renamed.")) setRename(null); }}><label className="field-label">Design name<input className="form-input" value={renameValue} onChange={e => setRenameValue(e.target.value)} maxLength={120} required autoFocus /></label><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setRename(null)}>Cancel</button><button type="submit" className="primary-button" disabled={busy}>{busy ? <Spinner /> : <Check size={16} />}Save name</button></div></form></Modal>}
    {deleteProject && <Modal title="Let this design go?" onClose={() => setDeleteProject(null)}><p className="modal-intro">“{deleteProject.title}” will be permanently deleted. This can’t be undone.</p><div className="modal-actions"><button className="secondary-button" onClick={() => setDeleteProject(null)}>Keep it</button><button className="danger-button" disabled={busy} onClick={async () => { setBusy(true); try { await api(`/api/designs/${deleteProject.id}`, { method: "DELETE" }); setProjects(current => current.filter(p => p.id !== deleteProject.id)); setDeleteProject(null); notify("Design permanently deleted."); } catch (error) { notify((error as Error).message, true); } finally { setBusy(false); } }}>{busy ? <Spinner /> : <Trash2 size={16} />}Delete permanently</button></div></Modal>}
    {toast && <Toast {...toast} onClose={closeToast} />}
  </>;
}

function BrandKit({ workspace, onSave, notify }: { workspace: Workspace; onSave: (updates: Record<string, unknown>) => Promise<Workspace>; notify: (message: string, error?: boolean) => void }) {
  const [name, setName] = useState(workspace.brandName);
  const [colors, setColors] = useState(workspace.colors);
  const [logo, setLogo] = useState(workspace.logo);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  async function save() { setSaving(true); try { await onSave({ brandName: name, colors, logo }); notify("Your brand kit is saved. Looking good!"); } catch (error) { notify((error as Error).message, true); } finally { setSaving(false); } }
  return <div className="brand-page"><div className="page-heading"><div><span className="eyebrow">CONSISTENTLY, BEAUTIFULLY YOU</span><h1>Your brand. Your signature.</h1><p>Keep the little things that make your brand unmistakable, all in one place.</p></div><button className="primary-button" disabled={saving} onClick={() => void save()}>{saving ? <Spinner /> : <Check size={17} />}Save brand kit</button></div><div className="brand-banner"><span>MAKE YOUR MARK</span><h2>{name || "Your creative studio"}<i>®</i></h2><p>A familiar feeling. Every single time.</p><Flower2 size={110} strokeWidth={.9} /></div><div className="brand-grid"><section className="settings-card"><div className="settings-title"><h2>The essentials</h2><Palette size={20} /></div><label className="field-label">Brand name<input className="form-input" value={name} maxLength={100} onChange={e => setName(e.target.value)} /></label><label className="field-label">Your logo</label><input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={async e => { const file = e.target.files?.[0]; if (file) try { setLogo(await readImage(file)); } catch (error) { notify((error as Error).message, true); } e.target.value = ""; }} /><button className={`logo-upload ${logo ? "has-logo" : ""}`} onClick={() => fileRef.current?.click()}>{logo ? <img src={logo} alt="Your brand logo" /> : <><Upload size={24} /><strong>Drop your mark here</strong><span>Click to upload a PNG, JPG, or WebP</span><small>Up to 2.8 MB</small></>}</button>{logo && <button className="text-button danger-text" onClick={() => setLogo(null)}>Remove logo</button>}</section><section className="settings-card"><div className="settings-title"><h2>Your color story</h2><span>{colors.length} / 12 colors</span></div><p className="muted">A palette that feels like you. Click a color to make it your own.</p><div className="brand-colors">{colors.map((color, i) => <div key={i} className="brand-color"><label style={{ background: color }}><input type="color" value={color} aria-label={`Brand color ${i + 1}`} onChange={e => setColors(current => current.map((c, index) => index === i ? e.target.value : c))} /></label><span>{color.toUpperCase()}</span><button aria-label={`Remove color ${color}`} onClick={() => setColors(current => current.filter((_, index) => i !== index))}><X size={13} /></button></div>)}{colors.length < 12 && <button className="add-color" onClick={() => setColors([...colors, "#c8dfcb"])}><Plus size={22} /><span>Add color</span></button>}</div><div className="palette-preview" style={{ background: colors[1] || "#eee8fb", color: colors[0] || "#7952e9" }}><span>A LITTLE COLOR. A LOT OF CHARACTER.</span><h3>Distinctly<br /><em>you.</em></h3><Sparkles size={38} /></div></section></div><p className="brand-note"><Check size={16} />Your saved palette is available in the editor’s color controls.</p></div>;
}
