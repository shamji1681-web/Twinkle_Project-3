import { useEffect, useRef, useState, type RefObject, type ElementType } from "react";
import { resolveAsset } from "@/lib/asset-map";
import { ArrowDown, ArrowUp, Brush, Check, ChevronLeft, ChevronRight, GripVertical, Eraser, Highlighter, Pen, Pencil, ChevronsDown, ChevronsUp, Copy, Crown, Eye, EyeOff, Lock, Maximize, Minus, Plus, Search, Sparkles, Table2, Trash2, Unlock, Upload, Wand2, X, QrCode } from "lucide-react";
import { FONTS, newId, makeIcon, makePattern, makePhoto, makeShape, makeStroke, makeTable, makeText, templates, MAX_LAYERS, type DesignDocument, type DesignLayer, type DesignTemplate, type Workspace } from "@/lib/designs";
import { canvasPresets, gradients, patterns as patternAssets, stockPhotos } from "@/lib/assets";
import { cornerStyles, defaultQRSettings, dotStyles, errorLevels, normalizeQRContent, normalizeQRSettings, qrPayload, qrPresets, validQRContent, type QRContent, type QRDotStyle, type QRSettings } from "@/lib/qr";
import { iconGroups, iconPath } from "@/lib/icons";
import { shapes } from "@/lib/shapes";
import { quoteCategories, quoteLibrary } from "@/lib/quotes";
import { api } from "@/components/ui";
import { readImage } from "@/lib/export";
import { aiDesignTypes, defaultBriefValues, type AiDesignBrief, type AiDesignType } from "@/lib/ai-design";
import type { CellTextStyle } from "@/lib/cell-typography";
import type { TextCase } from "@/lib/designs";
import { justifyAlignPatch } from "@/lib/text-fit";
import DesignCanvas from "@/components/design-canvas";
import { Spinner } from "@/components/ui";
import { uploadFont, removeFont } from "@/lib/fonts";
import { useCustomFonts } from "@/lib/use-fonts";
import RangeControl from "@/components/range-control";

export type DrawTool = "pencil" | "marker" | "highlighter" | "brush" | "eraser";
export interface Brush { color: string; size: number; tool: DrawTool }
export interface EditorContext {
  doc: DesignDocument;
  workspace: Workspace | null;
  selected: DesignLayer | null;
  selectedId: string | null;
  multiSelect?: string[];
  toggleMultiSelect?: (id: string) => void;
  proActive: boolean;
  full: boolean;
  drawMode: boolean;
  eraseMode: boolean;
  setEraseMode: (value: boolean) => void;
  eraseStrength: number;
  setEraseStrength: (value: number) => void;
  clearErase: (id: string) => void;
  brush: Brush;
  setDrawMode: (value: boolean) => void;
  setBrush: (brush: Brush) => void;
  add: (layer: DesignLayer) => void;
  moveLayer: (id: string, toIndex: number) => void;
  addMany: (layers: DesignLayer[]) => void;
  patch: (id: string, updates: Partial<DesignLayer>, record?: boolean) => void;
  remove: (id: string) => void;
  duplicate: (id: string) => void;
  select: (id: string | null) => void;
  changeDoc: (next: DesignDocument, record?: boolean) => void;
  reorder: (id: string, direction: "front" | "back" | "up" | "down") => void;
  useTemplate: (template: DesignTemplate) => void;
  upload: (file?: File) => void;
  uploads: string[];
  notify: (message: string, error?: boolean) => void;
  tool: string;
  openPanel: (tool: string) => void;
  fitText: (id: string) => void;
  editingId: string | null;
  startEditing: (id: string) => void;
  stopEditing: () => void;
  fitTextUpdates: (id: string) => Partial<DesignLayer>;
  generateQR: (settings: QRSettings, mode: "add" | "update", dimension?: number) => Promise<boolean>;
  previewQR: (settings: QRSettings) => Promise<string | null>;
  selectedCells: { r: number; c: number }[];
  editingCell: { r: number; c: number } | null;
  cellTextMode: boolean;
  beginCellText: (cell?: { r: number; c: number }) => void;
  finishCellText: () => void;
  formatCellText: (updates: CellTextStyle & { fill?: string }) => void;
  changeCellTextCase: (mode: TextCase) => void;
  cropMode: boolean;
  setCropMode: (value: boolean) => void;
  mergeSelected: () => void;
  splitSelected: () => void;
  setFillImage: (src: string) => void;
  uploadFillImage: (file: File) => void;
  uploadBackgroundImage: (file: File) => Promise<void>;
  fadeEditingId: string | null;
  editOpacityFade: (editing: boolean) => void;
  tableStyleOpen: boolean;
  setTableStyleOpen: (open: boolean) => void;
  tableInsert: (axis: "row" | "column", atEnd?: boolean) => void;
  tableDelete: (axis: "row" | "column") => void;
  tableResize: (rows: number, cols: number) => void;
  tableDistribute: (axis: "row" | "column") => void;
  tableClear: () => void;
  selectTableCells: (cells: { r: number; c: number }[]) => void;
  applyAiDesign: (brief: AiDesignBrief) => void;
  styleClipboard: Partial<DesignLayer> | null;
  copyStyle: () => void;
  pasteStyle: () => void;
  fitImageToCanvas: () => void;
}

const swatches = ["#7952e9", "#f8cbd7", "#064e48", "#ff8250", "#f59e0b", "#8caba4", "#24232b", "#ffffff"];
const brandColors = (ctx: EditorContext) => [...new Set([...(ctx.workspace?.colors || []), ...swatches])].slice(0, 14);

/** Horizontal category chip bar with arrow buttons and edge fades so long lists scroll cleanly. */
function CategoryScroller({ categories, value, onChange, label }: { categories: string[]; value: string; onChange: (name: string) => void; label: string }) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [edges, setEdges] = useState({ start: false, end: false });
  const measure = () => {
    const el = trackRef.current;
    if (!el) return;
    setEdges({ start: el.scrollLeft > 2, end: el.scrollLeft + el.clientWidth < el.scrollWidth - 2 });
  };
  useEffect(() => {
    measure();
    const el = trackRef.current;
    el?.addEventListener("scroll", measure, { passive: true });
    window.addEventListener("resize", measure);
    return () => { el?.removeEventListener("scroll", measure); window.removeEventListener("resize", measure); };
  }, [categories.length]);
  useEffect(() => {
    const el = trackRef.current;
    const active = el?.querySelector<HTMLElement>("button.active");
    active?.scrollIntoView({ block: "nearest", inline: "nearest" });
  }, [value]);
  const nudge = (direction: number) => trackRef.current?.scrollBy({ left: direction * 130, behavior: "smooth" });
  return (
    <div className={`category-scroller ${edges.start ? "at-start" : ""} ${edges.end ? "at-end" : ""}`}>
      <button type="button" className="category-arrow start" aria-label="Scroll categories left" tabIndex={-1} onClick={() => nudge(-1)}><ChevronLeft size={14} /></button>
      <div className="category-track" role="tablist" aria-label={label} ref={trackRef}>
        {categories.map(name => <button key={name} role="tab" aria-selected={value === name} className={value === name ? "active" : ""} onClick={() => onChange(name)}>{name}</button>)}
      </div>
      <button type="button" className="category-arrow end" aria-label="Scroll categories right" tabIndex={-1} onClick={() => nudge(1)}><ChevronRight size={14} /></button>
    </div>
  );
}

function Mini({ width, height, layers, background = "transparent" }: { width: number; height: number; layers: DesignLayer[]; background?: string }) {
  const doc: DesignDocument = { width, height, background, layers };
  return <DesignCanvas document={doc} />;
}

export function Swatches({ ctx, onPick }: { ctx: EditorContext; onPick: (color: string) => void }) {
  return <div className="color-swatches">{brandColors(ctx).map(color => <button key={color} style={{ background: color }} title={color} aria-label={`Use color ${color}`} onClick={() => onPick(color)} />)}</div>;
}

export function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (color: string) => void }) {
  const hex = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i.test(value) ? value : "#7952e9";
  return <label className="color-input"><input type="color" value={hex} aria-label={label} onChange={event => onChange(event.target.value)} /><span>{value.toUpperCase().slice(0, 22)}</span></label>;
}

export function DesignPanel({ ctx }: { ctx: EditorContext }) {
  const [width, setWidth] = useState(String(ctx.doc.width));
  const [height, setHeight] = useState(String(ctx.doc.height));
  function resize(nextWidth: number, nextHeight: number) {
    if (![nextWidth, nextHeight].every(value => Number.isFinite(value) && value >= 64 && value <= 5000)) return ctx.notify("Choose dimensions between 64 and 5000 pixels.", true);
    ctx.changeDoc({ ...ctx.doc, width: Math.round(nextWidth), height: Math.round(nextHeight) });
  }
  return <>
    <p className="editor-panel-description">Pick a canvas, or set your own size.</p>
    <div className="preset-grid">{canvasPresets.map(preset => <button key={preset.name} className={ctx.doc.width === preset.width && ctx.doc.height === preset.height ? "active" : ""} onClick={() => { resize(preset.width, preset.height); setWidth(String(preset.width)); setHeight(String(preset.height)); }}><strong>{preset.name}</strong><small>{preset.width} × {preset.height}</small></button>)}</div>
    <h3 className="panel-subtitle">Custom size</h3>
    <div className="size-row"><label><span>Width</span><input type="number" min={64} max={5000} value={width} aria-label="Canvas width" onChange={event => setWidth(event.target.value)} onBlur={() => resize(Number(width), Number(height))} /></label><label><span>Height</span><input type="number" min={64} max={5000} value={height} aria-label="Canvas height" onChange={event => setHeight(event.target.value)} onBlur={() => resize(Number(width), Number(height))} /></label><button className="icon-button" aria-label="Apply canvas size" onClick={() => resize(Number(width), Number(height))}><Maximize size={15} /></button></div>
    <h3 className="panel-subtitle">Background color</h3>
    <ColorField label="Canvas background color" value={ctx.doc.background} onChange={color => ctx.changeDoc({ ...ctx.doc, background: color })} />
    <Swatches ctx={ctx} onPick={color => ctx.changeDoc({ ...ctx.doc, background: color })} />
    <div className="editor-tip"><Sparkles size={19} /><p>Gradients, patterns, and photo backgrounds live in the Background panel.</p></div>
  </>;
}

export function TemplatePanel({ ctx, search, setSearch }: { ctx: EditorContext; search: string; setSearch: (value: string) => void }) {
  const matches = templates.filter(template => `${template.title} ${template.category} ${template.tag}`.toLowerCase().includes(search.toLowerCase()));
  return <>
    <div className="editor-template-search"><Search size={16} /><input placeholder="Search templates" value={search} onChange={event => setSearch(event.target.value)} aria-label="Search editor templates" /></div>
    <p className="editor-panel-description">{matches.length} starting points. Every element stays editable.</p>
    <div className="editor-template-grid">{matches.map(template => <button className="editor-template" key={template.id} onClick={() => ctx.useTemplate(template)}><span style={{ background: template.content.background }}><DesignCanvas document={template.content} />{template.pro && <Crown size={11} />}</span><small>{template.title}</small></button>)}</div>
    {!matches.length && <p className="muted">No matches. Try “summer”, “menu”, or “brand”.</p>}
  </>;
}

export function TextPanel({ ctx }: { ctx: EditorContext }) {
  const fontInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [section, setSection] = useState<"text" | "style" | "font">("text");
  const customFontList = useCustomFonts();
  const selectedText = ctx.selected?.type === "text" ? ctx.selected : null;
  async function addFont(file: File) {
    setUploading(true);
    try { const name = await uploadFont(file); ctx.notify(`“${name}” is ready — pick it from the toolbar Font menu.`); }
    catch (error) { ctx.notify((error as Error).message, true); }
    finally { setUploading(false); }
  }
  /** Applies a styled preset to the selected text, or drops a new text box using it. */
  function applyStyle(preset: Partial<DesignLayer>, label: string) {
    if (selectedText) { ctx.patch(selectedText.id, preset); ctx.notify(`${label} applied.`); }
    else ctx.add({ ...makeText(ctx.doc, "heading"), ...preset });
  }
  const textStyles: { name: string; preset: Partial<DesignLayer>; sample: React.CSSProperties }[] = [
    { name: "Title", preset: { fontFamily: "Arial", fontWeight: 800, letterSpacing: -1, lineHeight: 1.05 }, sample: { fontFamily: "Arial", fontWeight: 800, letterSpacing: "-.5px" } },
    { name: "Elegant", preset: { fontFamily: "Georgia", fontWeight: 400, italic: true, lineHeight: 1.25 }, sample: { fontFamily: "Georgia", fontStyle: "italic" } },
    { name: "Editorial", preset: { fontFamily: "Georgia", fontWeight: 700, letterSpacing: -0.5 }, sample: { fontFamily: "Georgia", fontWeight: 700 } },
    { name: "Caps", preset: { fontFamily: "Arial", fontWeight: 700, letterSpacing: 6 }, sample: { fontFamily: "Arial", fontWeight: 700, letterSpacing: "3px", textTransform: "uppercase" } },
    { name: "Mono", preset: { fontFamily: "Courier New", fontWeight: 400, letterSpacing: 1 }, sample: { fontFamily: "Courier New" } },
    { name: "Soft", preset: { fontFamily: "Verdana", fontWeight: 400, lineHeight: 1.6 }, sample: { fontFamily: "Verdana" } },
    { name: "Outline", preset: { textFillTransparent: true, textStrokeColor: ctx.workspace?.colors[0] || "#7952e9", textStrokeWidth: 2, fontWeight: 800 }, sample: { fontWeight: 800, WebkitTextStroke: "1px #7952e9", color: "transparent" } },
    { name: "Quiet", preset: { fontFamily: "Arial", fontWeight: 300, letterSpacing: 2, opacity: .7 }, sample: { fontFamily: "Arial", fontWeight: 300, letterSpacing: "1.5px", opacity: .7 } },
  ];
  return <>
    <div className="panel-sections" role="tablist" aria-label="Text sections">
      <button role="tab" aria-selected={section === "text"} className={section === "text" ? "active" : ""} onClick={() => setSection("text")}>Text</button>
      <button role="tab" aria-selected={section === "style"} className={section === "style" ? "active" : ""} onClick={() => setSection("style")}>Text Style</button>
      <button role="tab" aria-selected={section === "font"} className={section === "font" ? "active" : ""} onClick={() => setSection("font")}>Upload Font</button>
    </div>

    {section === "text" && <div className="panel-section-body">
      <p className="editor-panel-description">Good words make great designs.</p>
      <button className="primary-button full-width" onClick={() => ctx.add(makeText(ctx.doc, "heading"))}><Plus size={17} />Add a text box</button>
      <div className="text-presets">
        <button onClick={() => ctx.add(makeText(ctx.doc, "heading"))}><strong>Add a heading</strong><span>For your biggest ideas.</span></button>
        <button onClick={() => ctx.add(makeText(ctx.doc, "subheading"))}><h3>Add a subheading</h3><span>A little more of the story.</span></button>
        <button onClick={() => ctx.add(makeText(ctx.doc, "body"))}><p>Add a little body text</p><span>The details that matter.</span></button>
      </div>
      <div className="editor-tip"><Sparkles size={19} /><p>Double-click any text on the canvas to edit it. Font, size and colour live in the toolbar above.</p></div>
    </div>}

    {section === "style" && <div className="panel-section-body">
      <p className="editor-panel-description">{selectedText ? "Tap a style to restyle your selected text." : "Tap a style to add text already dressed up."}</p>
      <div className="text-style-grid">{textStyles.map(style => <button key={style.name} onClick={() => applyStyle(style.preset, style.name)} title={style.name}><span className="text-style-sample" style={style.sample}>Aa</span><small>{style.name}</small></button>)}</div>
      <h3 className="panel-subtitle">Alignment</h3>
      <div className="panel-toggle panel-toggle-wrap">{(["left", "center", "right", "justify", "justify-all"] as const).map(align => <button key={align} className={selectedText?.align === align ? "active" : ""} disabled={!selectedText} title={align === "justify-all" ? "CorelDRAW Force justify: every line stretches to the frame, last lines and single words included" : align === "justify" ? "CorelDRAW Full justify: every line stretches to the frame; each paragraph's last line stays natural" : undefined} onClick={() => { if (!selectedText) return; const { patch, converted } = justifyAlignPatch(selectedText, align, ctx.doc.width); ctx.patch(selectedText.id, patch); if (converted) ctx.notify("Justification uses a fixed frame — auto-fit is off."); }}>{align === "justify-all" ? "Force justify" : align === "justify" ? "Full justify" : align[0].toUpperCase() + align.slice(1)}</button>)}</div>
      <h3 className="panel-subtitle">Emphasis</h3>
      <div className="panel-toggle">
        <button className={selectedText && (selectedText.fontWeight || 400) >= 600 ? "active" : ""} disabled={!selectedText} onClick={() => selectedText && ctx.patch(selectedText.id, { fontWeight: (selectedText.fontWeight || 400) >= 600 ? 400 : 700 })}>Bold</button>
        <button className={selectedText?.italic ? "active" : ""} disabled={!selectedText} onClick={() => selectedText && ctx.patch(selectedText.id, { italic: !selectedText.italic })}>Italic</button>
        <button className={selectedText?.underline ? "active" : ""} disabled={!selectedText} onClick={() => selectedText && ctx.patch(selectedText.id, { underline: !selectedText.underline })}>Underline</button>
      </div>
      {!selectedText && <div className="editor-tip"><Sparkles size={19} /><p>Select a text box on the canvas to use alignment and emphasis.</p></div>}
    </div>}

    {section === "font" && <div className="panel-section-body">
      <p className="editor-panel-description">Bring your own typeface — it appears in the toolbar Font menu.</p>
      <input ref={fontInputRef} type="file" accept=".ttf,.otf,.woff,.woff2,font/*" hidden aria-hidden="true" onChange={e => { const file = e.target.files?.[0]; if (file) void addFont(file); e.target.value = ""; }} />
      <button className="secondary-button full-width" disabled={uploading} onClick={() => fontInputRef.current?.click()}>{uploading ? <Spinner size={15} /> : <Upload size={15} />}{uploading ? "Adding font…" : "Upload TTF, OTF or WOFF"}</button>
      {customFontList.length > 0
        ? <div className="uploaded-fonts">{customFontList.map(font => <div key={font.name} className="uploaded-font"><button className="uploaded-font-use" style={{ fontFamily: font.name }} onClick={() => ctx.add({ ...makeText(ctx.doc, "heading"), fontFamily: font.name })}><span className="uploaded-font-sample">Ag</span><span className="uploaded-font-name">{font.name}</span></button><button className="uploaded-font-remove" aria-label={`Remove ${font.name}`} title="Remove font" onClick={() => removeFont(font.name)}><X size={13} /></button></div>)}</div>
        : <div className="empty-uploads"><Sparkles size={22} /><p>No uploaded fonts yet. Add a TTF, OTF, WOFF or WOFF2 file up to 2 MB and it stays available in this browser.</p></div>}
    </div>}
  </>;
}

export function IconPanel({ ctx }: { ctx: EditorContext }) {
  const [search, setSearch] = useState(""); const [outline, setOutline] = useState(true); const color = ctx.workspace?.colors[0] || "#7952e9"; const [category, setCategory] = useState("All");
  const categories = ["All", ...iconGroups.map(group => group.group)];
  const groups = iconGroups.map(group => ({ ...group, icons: group.icons.filter(icon => (category === "All" || group.group === category) && `${icon.name} ${group.group}`.toLowerCase().includes(search.toLowerCase())) })).filter(group => group.icons.length);
  return <>
    <div className="editor-template-search"><Search size={16} /><input placeholder="Search icons" value={search} onChange={event => setSearch(event.target.value)} aria-label="Search icons" /></div>
    <CategoryScroller categories={categories} value={category} onChange={setCategory} label="Icon categories" />
    <div className="panel-toggle"><button className={outline ? "active" : ""} onClick={() => setOutline(true)}>Outline</button><button className={!outline ? "active" : ""} onClick={() => setOutline(false)}>Filled</button></div>
    {groups.map(group => <section key={group.group} className="panel-group"><h3 className="panel-subtitle">{group.group}</h3><div className="asset-grid">{group.icons.map(icon => { const path = iconPath(icon, outline); return <button key={icon.name} title={icon.name} aria-label={`Add ${icon.name} ${outline ? "outline" : "filled"} icon`} onClick={() => ctx.add(makeIcon(ctx.doc, path, !outline, .2, color))}><Mini width={64} height={64} layers={[{ id: `p-${icon.name}-${outline ? "o" : "f"}`, type: "icon", x: 12, y: 12, width: 40, height: 40, fill: "#6d5a80", path, outline }]} /></button>; })}</div></section>)}
    {!groups.length && <p className="muted">No icons match that search.</p>}<div className="editor-tip"><Sparkles size={19} /><p>Pick an icon, then change its colour from the toolbar above the canvas.</p></div>
  </>;
}

export function ShapePanel({ ctx }: { ctx: EditorContext }) {
  const [outline, setOutline] = useState(false); const color = ctx.workspace?.colors[0] || "#7952e9"; const [category, setCategory] = useState("All");
  const groups: Record<string, string[]> = { Regular: ["square","rounded","circle","triangle","diamond","pentagon","hexagon","octagon","oval","pill","trapezoid","parallelogram"], Symbols: ["heart","star5","sparkle","star6","badge","plus","cross","check","diamond"], Arrows: ["arrowRight","arrowUp","arrowDouble","zigzag"], Organic: ["flower","leaf","cloud","blob","wave","crescent"], Frames: ["frame","speech","bookmarkShape","shield","ring","corner"] };
  const names = Object.keys(groups);
  const categories = ["All", ...names];
  const sections = (category === "All" ? names : [category])
    .map(group => ({ group, items: shapes.filter(shape => groups[group].includes(shape.key)) }))
    .filter(section => section.items.length);
  return <>
    <CategoryScroller categories={categories} value={category} onChange={setCategory} label="Shape categories" />
    <div className="panel-toggle"><button className={!outline ? "active" : ""} onClick={() => setOutline(false)}>Filled</button><button className={outline ? "active" : ""} onClick={() => setOutline(true)}>Outline</button></div>
    {sections.map(section => <section key={section.group} className="panel-group"><h3 className="panel-subtitle">{section.group}</h3><div className="asset-grid">{section.items.map(shape => <button key={shape.key} title={shape.name} aria-label={`Add ${shape.name} shape`} onClick={() => ctx.add(makeShape(ctx.doc, shape.key, color, .32, outline))}><Mini width={64} height={64} layers={[{ id: `p-${shape.key}`, type: "shape", x: 10, y: 10, width: 44, height: 44, fill: "#6d5a80", shape: shape.key, outline }]} /><small>{shape.name}</small></button>)}</div></section>)}
    <div className="editor-tip"><Sparkles size={19} /><p>Shapes start with one colour and can be customized with fills, outlines, and effects.</p></div>
  </>;
}

export function LinePanel({ ctx }: { ctx: EditorContext }) {
  const color = ctx.workspace?.colors[0] || "#7952e9";
  const [category, setCategory] = useState("All");
  const categories = ["All", "Basic", "Decorative", "Pages Border", "Pages Corner"];
  const lineData: Array<{ key: string; name: string; group: string }> = [
    { key: "solid", name: "Solid", group: "Basic" },
    { key: "dashed", name: "Dashed", group: "Basic" },
    { key: "dotted", name: "Dotted", group: "Basic" },
    { key: "double", name: "Double", group: "Basic" },
    { key: "arrow", name: "Arrow", group: "Basic" },
    { key: "wave", name: "Wave", group: "Decorative" },
    { key: "zigzag", name: "Zigzag", group: "Decorative" },
    { key: "border-solid", name: "Solid Page Border", group: "Pages Border" },
    { key: "border-rounded", name: "Rounded Border", group: "Pages Border" },
    { key: "border-double", name: "Double Border", group: "Pages Border" },
    { key: "border-inset", name: "Inset Border", group: "Pages Border" },
    { key: "border-dashed", name: "Dashed Border", group: "Pages Border" },
    { key: "border-dotted", name: "Dotted Border", group: "Pages Border" },
    { key: "corner-solid", name: "Plain Corner", group: "Pages Corner" },
    { key: "corner-round", name: "Rounded Corner", group: "Pages Corner" },
    { key: "corner-double", name: "Double Corner", group: "Pages Corner" },
    { key: "corner-bracket", name: "Bracket Corner", group: "Pages Corner" },
    { key: "corner-flourish", name: "Flourish Corner", group: "Pages Corner" },
    { key: "corner-grid", name: "Grid Corner", group: "Pages Corner" },
    { key: "corner-boxline", name: "Box Line Corner", group: "Pages Corner" },
    { key: "corner-arrow", name: "Arrow Corner", group: "Pages Corner" },
    { key: "corner-leaf", name: "Leaf Corner", group: "Pages Corner" },
    { key: "corner-vine", name: "Vine Corner", group: "Pages Corner" },
    { key: "corner-curl", name: "Curl Corner", group: "Pages Corner" },
    { key: "corner-scroll", name: "Scroll Corner", group: "Pages Corner" },
    { key: "corner-star", name: "Star Corner", group: "Pages Corner" },
    { key: "corner-diamond", name: "Diamond Corner", group: "Pages Corner" },
    { key: "corner-bow", name: "Bow Corner", group: "Pages Corner" },
    { key: "corner-shield", name: "Shield Corner", group: "Pages Corner" },
    { key: "corner-nested", name: "Nested Corner", group: "Pages Corner" },
  ];
  const styles = category === "All" ? lineData : lineData.filter(item => item.group === category);

  /** Borders span the page, corners sit in the top-left square; plain lines stay centred strokes. */
  function addItem(item: typeof lineData[number]) {
    const { doc } = ctx;
    if (item.group === "Pages Border") {
      const pad = Math.round(Math.min(doc.width, doc.height) * .04);
      ctx.add({ ...makeStroke(doc, item.key, color, Math.max(3, Math.round(Math.min(doc.width, doc.height) * .006))), x: pad, y: pad, width: doc.width - pad * 2, height: doc.height - pad * 2 });
    } else if (item.group === "Pages Corner") {
      const side = Math.round(Math.min(doc.width, doc.height) * .38);
      ctx.add({ ...makeStroke(doc, item.key, color, Math.max(3, Math.round(side * .022))), x: Math.round(doc.width * .05), y: Math.round(doc.height * .05), width: side, height: side });
    } else {
      ctx.add(makeStroke(doc, item.key, color, 4));
    }
  }

  return <>
    <p className="editor-panel-description">Give your layout structure with clean, resizable lines.</p>
    <CategoryScroller categories={categories} value={category} onChange={setCategory} label="Line categories" />
    <div className="line-grid">{styles.map(item => <button key={item.key} aria-label={`Add ${item.name}`} onClick={() => addItem(item)}><Mini width={72} height={48} layers={[{ id: `p-${item.key}`, type: "stroke", x: item.group === "Pages Border" ? 3 : item.group === "Pages Corner" ? 4 : 4, y: item.group === "Pages Border" ? 2 : item.group === "Pages Corner" ? 2 : 20, width: item.group === "Pages Border" ? 66 : item.group === "Pages Corner" ? 44 : 64, height: item.group === "Pages Border" ? 44 : item.group === "Pages Corner" ? 44 : 8, fill: "#6d5a80", variant: item.key, strokeWidth: 3 }]} /><small>{item.name}</small></button>)}</div>
    <div className="editor-tip"><Sparkles size={19} /><p>Drag a line&apos;s handles on the canvas to stretch it or change thickness in the toolbar.</p></div>
  </>;
}

export function PhotoPanel({ ctx }: { ctx: EditorContext }) {
  const [search, setSearch] = useState("");
  const filtered = stockPhotos.filter(p => `${p.name} ${p.tags}`.toLowerCase().includes(search.trim().toLowerCase()));
  return <>
    <div className="editor-template-search"><Search size={16} /><input placeholder="Search stock photos" value={search} onChange={e => setSearch(e.target.value)} aria-label="Search stock photos" /></div>
    <p className="editor-panel-description">Choose an image to add it to your canvas.</p>
    <div className="photo-grid">{filtered.map(photo => <button type="button" key={photo.src} aria-label={`Add ${photo.name} to canvas`} title={photo.name} onClick={() => ctx.add(makePhoto(ctx.doc, photo.src, .45))}><img src={resolveAsset(photo.src)} alt={photo.name} loading="lazy" decoding="async" /><span>{photo.name}</span></button>)}</div>
    {!filtered.length && <p className="muted" role="status">No images match your search. Try a different word.</p>}
  </>;
}

export function BackgroundPanel({ ctx }: { ctx: EditorContext }) {
  return <>
    <p className="editor-panel-description">Set a colour, gradient or textured background for the canvas.</p>
    <h3 className="panel-subtitle">Solid colour</h3>
    <ColorField label="Canvas background" value={ctx.doc.background} onChange={color => ctx.changeDoc({ ...ctx.doc, background: color })} />
    <Swatches ctx={ctx} onPick={color => ctx.changeDoc({ ...ctx.doc, background: color })} />
    <h3 className="panel-subtitle">Gradient presets</h3>
    <div className="gradient-grid">{gradients.map((grad, i) => <button key={i} style={{ background: grad.value }} aria-label={grad.name} onClick={() => ctx.changeDoc({ ...ctx.doc, background: grad.value })} />)}</div>
    <h3 className="panel-subtitle">Patterns</h3>
    <div className="asset-grid">{patternAssets.map(pat => <button key={pat.key} onClick={() => ctx.add(makePattern(ctx.doc, pat.key, ctx.workspace?.colors[0] || "#7c4de0"))}><Mini width={64} height={64} layers={[{ id: `pat-${pat.key}`, type: "pattern", x: 0, y: 0, width: 64, height: 64, fill: "#7c4de0", pattern: pat.key, tile: 24 }]} /><small>{pat.name}</small></button>)}</div>
  </>;
}

export function QuotePanel({ ctx }: { ctx: EditorContext }) {
  const selectedText = ctx.selected?.type === "text" ? ctx.selected : null;
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const query = search.trim().toLowerCase();
  const visible = quoteLibrary.filter(q =>
    (category === "All" || q.cat === category) && (!query || q.text.toLowerCase().includes(query))
  );
  function useQuote(text: string) {
    if (selectedText) {
      ctx.patch(selectedText.id, { text, height: text.split("\n").length * (selectedText.fontSize || 40) * 1.13 });
      ctx.notify("Quote added to your selected text.");
    } else {
      ctx.add({ ...makeText(ctx.doc, "subheading"), text, fontFamily: "Georgia", italic: true, align: "center" });
    }
  }
  return <>
    <p className="editor-panel-description">Words worth keeping, styled for you.</p>
    <div className="editor-template-search"><Search size={16} /><input placeholder="Search quotes" value={search} onChange={event => setSearch(event.target.value)} aria-label="Search quotes" /></div>
    <CategoryScroller categories={quoteCategories} value={category} onChange={setCategory} label="Quote categories" />
    {visible.length ? <div className="quote-texts">{visible.map(quote => <button key={quote.text} onClick={() => useQuote(quote.text)}><span className="quote-mark">“</span><span className="quote-line">{quote.text}</span><small>{quote.cat}</small></button>)}</div>
      : <p className="muted">No quotes match that search.</p>}
    <div className="editor-tip"><Sparkles size={19} /><p>Select a text box first to swap in a quote without adding a new layer.</p></div>
  </>;
}

export function TablePanel({ ctx }: { ctx: EditorContext }) {
  const [rows, setRows] = useState(4);
  const [cols, setCols] = useState(3);
  const table = ctx.selected?.type === "table" ? ctx.selected : ctx.doc.layers.find(layer => layer.type === "table") || null;
  return <>
    <p className="editor-panel-description">Menus, price lists, schedules — neatly lined up.</p>
    <div className="table-controls">
      {([["Rows", rows, setRows, 1, 20], ["Columns", cols, setCols, 1, 12]] as [string, number, (value: number) => void, number, number][]).map(([label, value, setValue, min, max]) => <div key={label} className="stepper"><span>{label}</span><div><button aria-label={`Fewer ${label.toLowerCase()}`} disabled={value <= min} onClick={() => setValue(value - 1)}><Minus size={14} /></button><strong>{value}</strong><button aria-label={`More ${label.toLowerCase()}`} disabled={value >= max} onClick={() => setValue(value + 1)}><Plus size={14} /></button></div></div>)}
    </div>
    <button className="primary-button full-width" onClick={() => { ctx.add(makeTable(ctx.doc, rows, cols, ctx.workspace?.colors[0] || "#7952e9")); ctx.notify(`${rows} × ${cols} table added. Double-click a cell to type; use the topbar for styling.`); }}><Table2 size={17} />Insert {rows} × {cols} table</button>
    <div className="table-preview"><Mini width={180} height={Math.round(180 * rows / cols * .7)} layers={[{ id: "table-preview", type: "table", x: 10, y: 10, width: 160, height: Math.max(30, 180 * rows / cols * .7 - 20), fill: ctx.workspace?.colors[0] || "#7952e9", rows, cols, cells: Array.from({ length: rows * cols }, () => ""), cellFill: "transparent", lineColor: ctx.workspace?.colors[0] || "#7952e9" }]} /></div>
    {table && <div className="table-panel-guide"><Table2 size={24} /><h3>Make the table yours</h3><p>Select a cell to edit its borders and fill in the topbar. Double-click to type. Use the floating toolbar to add, remove or arrange your rows and columns.</p><button className="secondary-button full-width" onClick={() => { ctx.select(table.id); ctx.setTableStyleOpen(true); }}>Open table properties</button></div>}
  </>;
}

export function DrawPanel({ ctx }: { ctx: EditorContext }) {
  const tools: { id: DrawTool; name: string; size: number; opacity: number; Icon: ElementType }[] = [{id:"pencil",name:"Pencil",size:5,opacity:1,Icon:Pencil},{id:"marker",name:"Marker",size:12,opacity:.58,Icon:Pen},{id:"highlighter",name:"Highlighter",size:26,opacity:.32,Icon:Highlighter},{id:"brush",name:"Brush",size:18,opacity:1,Icon:Brush},{id:"eraser",name:"Eraser",size:24,opacity:1,Icon:Eraser}];
  const active = ctx.brush.tool;
  return <>
    <p className="editor-panel-description">Choose a tool, then draw directly on the canvas.</p><div className="draw-tool-grid" role="group" aria-label="Drawing tools">{tools.map(tool => <button key={tool.id} className={active===tool.id?"active":""} aria-pressed={active===tool.id} onClick={() => { ctx.setBrush({ ...ctx.brush, tool:tool.id, size:tool.size }); ctx.setDrawMode(true); }}><tool.Icon size={20} strokeWidth={1.9} />{tool.name}</button>)}</div>
    <button className={`primary-button full-width ${ctx.drawMode ? "draw-active" : ""}`} onClick={() => ctx.setDrawMode(!ctx.drawMode)}>{ctx.drawMode ? "Drawing is on — tap to stop" : "Start drawing"}</button>
    {ctx.drawMode && <p className="draw-live"><span className="pulse" />{active === "eraser" ? "Tap a drawing stroke to erase it." : `${tools.find(t=>t.id===active)?.name} is ready — draw on your canvas.`}</p>}
    {active !== "eraser" && <><h3 className="panel-subtitle">Colour</h3><ColorField label="Brush color" value={ctx.brush.color} onChange={color => ctx.setBrush({ ...ctx.brush, color })} /><Swatches ctx={ctx} onPick={color => ctx.setBrush({ ...ctx.brush, color })} /></>}
    <h3 className="panel-subtitle">{active === "eraser" ? "Eraser size" : "Stroke size"}</h3><RangeControl label="Brush size" min={2} max={60} value={ctx.brush.size} unit="px" onChange={size => ctx.setBrush({ ...ctx.brush, size })} /><div className="brush-preview"><span style={{ background: active === "eraser" ? "#e2d8ea" : ctx.brush.color, opacity: tools.find(t=>t.id===active)?.opacity, height: Math.min(46,ctx.brush.size), width:Math.min(46,ctx.brush.size)}} /></div>
  </>;
}

export function UploadPanel({ ctx, fileRef }: { ctx: EditorContext; fileRef: RefObject<HTMLInputElement | null> }) {
  return <>
    <p className="editor-panel-description">Your photos make it unmistakably yours.</p>
    <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={event => { ctx.upload(event.target.files?.[0]); event.target.value = ""; }} />
    <button className="upload-dropzone" onClick={() => fileRef.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); ctx.upload(event.dataTransfer.files[0]); }}><Upload size={29} /><strong>Upload an image</strong><span>or drop it right here</span><small>PNG, JPG, WebP · up to 2.8 MB</small></button>
    {ctx.workspace?.logo && <button className="editor-brand-logo" onClick={() => ctx.add(makePhoto(ctx.doc, ctx.workspace!.logo!, .3))}><img src={ctx.workspace.logo} alt="Your brand logo" /><span>Add your logo <Plus size={14} /></span></button>}
    <h3 className="panel-subtitle">Your uploads</h3>
    {ctx.uploads.length ? (
      <>
        <div className="upload-gallery">{ctx.uploads.map(src => <button key={src.slice(-28) + src.length} className="upload-gallery-item" aria-label="Add this upload to the canvas" onClick={() => ctx.add(makePhoto(ctx.doc, src))}><img src={src} alt="" loading="lazy" /><Plus size={13} /></button>)}</div>
        <div className="editor-tip"><Sparkles size={19} /><p>Uploads are kept in a temporary space until your design is saved — reopen the editor any time before saving to add them again.</p></div>
      </>
    ) : (
      <div className="empty-uploads"><Sparkles size={22} /><p>Nothing here yet. Images you upload stay in a temporary space until the design is saved, so you can keep adding them while you work.</p></div>
    )}
  </>;
}

export function LayerPanel({ ctx }: { ctx: EditorContext }) {
  const layers = [...ctx.doc.layers].reverse();
  const listRef = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{ id: string; y: number; over: number | null } | null>(null);
  const dragRef = useRef<{ id: string; pointerId: number; startY: number; moved: boolean; over: number | null } | null>(null);

  function slotAt(clientY: number): number {
    const rows = Array.from(listRef.current?.querySelectorAll<HTMLElement>("[data-layer-row]") || []);
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i].getBoundingClientRect();
      if (clientY < r.top + r.height / 2) return i;
    }
    return rows.length;
  }
  function onHandleDown(event: React.PointerEvent, id: string) {
    event.preventDefault();
    (event.currentTarget as HTMLElement).setPointerCapture(event.pointerId);
    dragRef.current = { id, pointerId: event.pointerId, startY: event.clientY, moved: false, over: null };
    setDrag({ id, y: event.clientY, over: null });
  }
  function onHandleMove(event: React.PointerEvent) {
    const d = dragRef.current; if (!d) return;
    if (!d.moved && Math.abs(event.clientY - d.startY) < 3) return;
    d.moved = true;
    const over = slotAt(event.clientY);
    d.over = over;
    setDrag({ id: d.id, y: event.clientY, over });
    const list = listRef.current; if (list) { const r = list.getBoundingClientRect(); if (event.clientY < r.top + 24) list.scrollTop -= 8; else if (event.clientY > r.bottom - 24) list.scrollTop += 8; }
  }
  function onHandleUp() {
    const d = dragRef.current; dragRef.current = null;
    if (d && d.moved && d.over !== null) {
      const visualFrom = layers.findIndex(l => l.id === d.id);
      let visualTo = d.over; if (visualTo > visualFrom) visualTo -= 1;
      const stackIndex = ctx.doc.layers.length - 1 - visualTo;
      ctx.moveLayer(d.id, stackIndex);
    }
    setDrag(null);
  }

  return <>
    <p className="editor-panel-description">{ctx.doc.layers.length} of {MAX_LAYERS} elements on this canvas.</p>
    {layers.length ? <div className={`layer-manager ${drag ? "is-dragging" : ""}`} ref={listRef}>{layers.map((layer, index) => {
      const position = ctx.doc.layers.length - 1 - index;
      const isSelected = layer.id === ctx.selectedId;
      const name = layer.type === "text" ? (layer.text?.slice(0, 20) || "Text") : `${layer.type[0].toUpperCase()}${layer.type.slice(1)}`;
      return <div key={layer.id} data-layer-row className={`layer-row ${isSelected ? "active" : ""} ${layer.hidden ? "is-hidden" : ""}`} onClick={() => ctx.select(layer.id)}>
        <span className="layer-drag-handle" onPointerDown={e => onHandleDown(e, layer.id)} onPointerMove={onHandleMove} onPointerUp={onHandleUp} onPointerCancel={onHandleUp}><GripVertical size={14} /></span>
        <button type="button" className="layer-select" aria-label={`Select ${name}`}>
          <span className="layer-chip" style={{ background: layer.fill || "#7c4de0" }}>{position + 1}</span>
          <span className="layer-name">{name}</span>
        </button>
        <div className="layer-actions">
          <button aria-label={layer.hidden ? `Show ${name}` : `Hide ${name}`} title={layer.hidden ? "Show" : "Hide"} onClick={() => ctx.patch(layer.id, { hidden: !layer.hidden })}>{layer.hidden ? <EyeOff size={14} /> : <Eye size={14} />}</button>
          <button aria-label={layer.locked ? `Unlock ${name}` : `Lock ${name}`} title={layer.locked ? "Unlock" : "Lock"} onClick={() => ctx.patch(layer.id, { locked: !layer.locked })}>{layer.locked ? <Lock size={14} /> : <Unlock size={14} />}</button>
          <button aria-label={`Delete ${name}`} title="Delete" className="danger-hover" onClick={() => ctx.remove(layer.id)}><Trash2 size={14} /></button>
        </div>
      </div>;
    })}</div> : <div className="empty-layers"><Sparkles size={26} /><p>Your canvas is full of possibility. Add some text, a shape, or a photo to get started.</p></div>}
    <div className="editor-tip"><GripVertical size={19} /><p>Drag the grip on any layer up or down to change its order. Top of the list is the front of your design.</p></div>
  </>;
}

/**
 * AI Create Panel: Clean single-source form for all design types.
 * No duplicate fields — each detail appears once, logically organized,
 * pre-filled with high-quality defaults for instant generation.
 */
export function AiCreatePanel({ ctx }: { ctx: EditorContext }) {
  const [brief, setBrief] = useState<AiDesignBrief>(() => ({
    type: "Letterhead",
    companyName: defaultBriefValues["Letterhead"].companyName || "THYNK UNLIMITED",
    tagline: defaultBriefValues["Letterhead"].tagline || "Creative Company",
    website: defaultBriefValues["Letterhead"].website || "www.reallygreatsite.com",
    mobileNumber: defaultBriefValues["Letterhead"].mobileNumber || "123-456-7890",
    email: defaultBriefValues["Letterhead"].email || "hello@reallygreatsite.com",
    address: defaultBriefValues["Letterhead"].address || "123 Innovation Plaza, Silicon City",
    prompt: defaultBriefValues["Letterhead"].prompt || "",
    personName: defaultBriefValues["Visiting card"].personName || "Alex Morgan",
    designation: defaultBriefValues["Visiting card"].designation || "Creative Director",
    whatsappNumber: "123-456-7890",
    businessType: "Branding, UI/UX & Web Development",
    enableQr: true,
  }));

  const [imageName, setImageName] = useState("");
  const imageRef = useRef<HTMLInputElement>(null);

  const update = <K extends keyof AiDesignBrief>(key: K, value: AiDesignBrief[K]) => {
    setBrief(current => ({ ...current, [key]: value }));
  };

  const handleTypeChange = (nextType: AiDesignType) => {
    const defaults = defaultBriefValues[nextType] || {};
    setBrief(current => ({
      ...current,
      type: nextType,
      companyName: current.companyName || defaults.companyName || "THYNK UNLIMITED",
      tagline: current.tagline || defaults.tagline || "Creative Company",
      prompt: defaults.prompt !== undefined ? defaults.prompt : current.prompt,
    }));
  };

  async function chooseImage(file?: File) {
    if (!file) return;
    try {
      const image = await readImage(file);
      setBrief(current => ({ ...current, image }));
      setImageName(file.name);
    } catch (error) {
      ctx.notify((error as Error).message, true);
    }
  }

  function generate(event: React.FormEvent) {
    event.preventDefault();
    if (!brief.companyName.trim()) {
      return ctx.notify("Please enter a Company / Business Name.", true);
    }
    ctx.applyAiDesign({
      ...brief,
      name: brief.companyName,
      contact: brief.mobileNumber,
      social: brief.socialMedia,
      logo: ctx.workspace?.logo || brief.logo || undefined,
    });
  }

  const isCard = brief.type === "Visiting card";
  const isLetterhead = brief.type === "Letterhead";
  const isCardOrId = isCard || brief.type === "ID card";

  return (
    <form className="ai-create-panel" onSubmit={generate}>
      <div className="ai-panel-hero">
        <span><Wand2 size={18} /></span>
        <div>
          <strong>AI Create Design</strong>
          <p>Generate professional Letterheads, Visiting Cards, Brochures & more in one click.</p>
        </div>
      </div>

      {/* 1. Design Category */}
      <label className="ai-field">
        <span>Design Type</span>
        <select
          aria-label="Design Type"
          value={brief.type}
          onChange={e => handleTypeChange(e.target.value as AiDesignType)}
        >
          {aiDesignTypes.map(t => (
            <option key={t} value={t}>{t}</option>
          ))}
        </select>
      </label>

      {/* 2. Company & Brand Information */}
      <label className="ai-field">
        <span>Company / Business Name *</span>
        <input
          required
          aria-label="Company / Business Name"
          value={brief.companyName}
          maxLength={100}
          placeholder="e.g. THYNK UNLIMITED"
          onChange={e => update("companyName", e.target.value)}
        />
      </label>

      <label className="ai-field">
        <span>Tagline / Slogan</span>
        <input
          aria-label="Tagline / Slogan"
          value={brief.tagline || ""}
          maxLength={120}
          placeholder="e.g. Creative Company"
          onChange={e => update("tagline", e.target.value)}
        />
      </label>

      {/* 3. Person Name & Designation (shown for Visiting Card & ID Card) */}
      {isCardOrId && (
        <div className="ai-field-grid">
          <label className="ai-field">
            <span>Person Name</span>
            <input
              aria-label="Person Name"
              value={brief.personName || ""}
              maxLength={80}
              placeholder="e.g. Alex Morgan"
              onChange={e => update("personName", e.target.value)}
            />
          </label>
          <label className="ai-field">
            <span>Designation</span>
            <input
              aria-label="Designation"
              value={brief.designation || ""}
              maxLength={80}
              placeholder="e.g. Creative Director"
              onChange={e => update("designation", e.target.value)}
            />
          </label>
        </div>
      )}

      {/* 4. Phone & WhatsApp */}
      <div className="ai-field-grid">
        <label className="ai-field">
          <span>Mobile Number</span>
          <input
            aria-label="Mobile Number"
            value={brief.mobileNumber || ""}
            maxLength={40}
            placeholder="123-456-7890"
            onChange={e => update("mobileNumber", e.target.value)}
          />
        </label>
        {isCard ? (
          <label className="ai-field">
            <span>WhatsApp Number</span>
            <input
              aria-label="WhatsApp Number"
              value={brief.whatsappNumber || ""}
              maxLength={40}
              placeholder="123-456-7890"
              onChange={e => update("whatsappNumber", e.target.value)}
            />
          </label>
        ) : (
          <label className="ai-field">
            <span>Email Address</span>
            <input
              aria-label="Email Address"
              type="email"
              value={brief.email || ""}
              maxLength={100}
              placeholder="hello@reallygreatsite.com"
              onChange={e => update("email", e.target.value)}
            />
          </label>
        )}
      </div>

      {/* 5. Email & Website (for card) or just Website (for others) */}
      {isCard ? (
        <div className="ai-field-grid">
          <label className="ai-field">
            <span>Email Address</span>
            <input
              aria-label="Email Address"
              type="email"
              value={brief.email || ""}
              maxLength={100}
              placeholder="hello@reallygreatsite.com"
              onChange={e => update("email", e.target.value)}
            />
          </label>
          <label className="ai-field">
            <span>Website</span>
            <input
              aria-label="Website"
              value={brief.website || ""}
              maxLength={100}
              placeholder="www.reallygreatsite.com"
              onChange={e => update("website", e.target.value)}
            />
          </label>
        </div>
      ) : (
        <label className="ai-field">
          <span>Website</span>
          <input
            aria-label="Website"
            value={brief.website || ""}
            maxLength={100}
            placeholder="www.reallygreatsite.com"
            onChange={e => update("website", e.target.value)}
          />
        </label>
      )}

      {/* 6. Address */}
      <label className="ai-field">
        <span>Address</span>
        <input
          aria-label="Address"
          value={brief.address || ""}
          maxLength={180}
          placeholder="123 Innovation Plaza, Silicon City"
          onChange={e => update("address", e.target.value)}
        />
      </label>

      {/* 7. Social Media & Services */}
      {(isCard || isLetterhead) && (
        <div className="ai-field-grid">
          <label className="ai-field">
            <span>Social Media</span>
            <input
              aria-label="Social Media"
              value={brief.socialMedia || ""}
              maxLength={100}
              placeholder="@reallygreatsite"
              onChange={e => update("socialMedia", e.target.value)}
            />
          </label>
          <label className="ai-field">
            <span>Services / Business Type</span>
            <input
              aria-label="Business Type / Services"
              value={brief.businessType || ""}
              maxLength={120}
              placeholder="Branding & UI/UX"
              onChange={e => update("businessType", e.target.value)}
            />
          </label>
        </div>
      )}

      {/* 8. QR Code toggle (especially relevant for visiting card) */}
      {isCard && (
        <label className="ai-checkbox-row">
          <input
            type="checkbox"
            checked={!!brief.enableQr}
            onChange={e => update("enableQr", e.target.checked)}
          />
          <span>Include QR Code on card</span>
        </label>
      )}

      {/* 9. Logo / Photo Upload */}
      <input
        ref={imageRef}
        hidden
        type="file"
        accept="image/png,image/jpeg,image/webp"
        onChange={e => { void chooseImage(e.target.files?.[0]); e.target.value = ""; }}
      />
      <button
        className={`ai-image-upload ${brief.image ? "has-image" : ""}`}
        type="button"
        onClick={() => imageRef.current?.click()}
      >
        {brief.image ? (
          <>
            <img src={brief.image} alt="Upload" />
            <span>{imageName || "Image selected"}</span>
            <X
              size={14}
              onClick={e => {
                e.stopPropagation();
                setBrief(curr => ({ ...curr, image: undefined }));
                setImageName("");
              }}
            />
          </>
        ) : (
          <>
            <Upload size={16} />
            <span>Upload Custom Logo / Image (optional)</span>
          </>
        )}
      </button>

      {/* 10. Style / Palette Prompt */}
      <label className="ai-field ai-prompt-field">
        <span>Color / Style Theme</span>
        <input
          aria-label="Style prompt"
          value={brief.prompt || ""}
          maxLength={200}
          placeholder="e.g. blue corporate clean, or gold luxury, or green eco"
          onChange={e => update("prompt", e.target.value)}
        />
        <small>Keywords like “blue”, “gold luxury”, “green eco” dynamically set brand colors.</small>
      </label>

      {/* Submit Button */}
      <button className="primary-button full-width ai-generate" type="submit">
        <Wand2 size={17} />
        Generate {brief.type}
      </button>
      <p className="ai-footnote">
        Creates a clean, pixel-perfect, 100% editable layout on canvas.
      </p>
    </form>
  );
}

export function BrandPanel({ ctx, compact = false }: { ctx: EditorContext; compact?: boolean }) {
  return <>
    <p className="editor-panel-description">{ctx.workspace?.brandName || "Your creative studio"}</p>
    {ctx.workspace?.logo && <button className="editor-brand-logo" onClick={() => ctx.add(makePhoto(ctx.doc, ctx.workspace!.logo!, .3))}><img src={ctx.workspace.logo} alt="Your brand logo" /><span>Add your logo <Plus size={14} /></span></button>}
    {!compact && <h3 className="panel-subtitle">Your brand colors</h3>}
    <div className="editor-brand-colors">{(ctx.workspace?.colors || swatches).map((color, index) => <button key={`${color}-${index}`} style={{ background: color }} title={color} aria-label={`Use brand color ${color}`} onClick={() => { if (ctx.selected && ctx.selected.type !== "image") ctx.patch(ctx.selected.id, { fill: color }); else ctx.changeDoc({ ...ctx.doc, background: color }); }} />)}</div>
    <p className="small-hint">Select an element to recolor it, or click a blank space to change the background.</p>
    {!compact && <h3 className="panel-subtitle">On-brand backgrounds</h3>}
    {!compact && <div className="gradient-grid">{(ctx.workspace?.colors || swatches).slice(0, 6).map((color, index, all) => {
      const next = all[(index + 1) % all.length];
      const value = `linear-gradient(135deg, ${color} 0%, ${next} 100%)`;
      return <button key={value} title={`${color} to ${next}`} aria-label={`Use ${color} gradient background`} style={{ background: value }} onClick={() => ctx.changeDoc({ ...ctx.doc, background: value })} />;
    })}</div>}
    {!compact && <div className="editor-tip"><Sparkles size={19} /><p>Update your palette from Brand kit on your dashboard.</p></div>}
  </>;
}

export { QRPanel } from "@/components/qr-panel";
