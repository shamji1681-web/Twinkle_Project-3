import type { DesignLayer } from "@/lib/designs";
import { opacityFadeStops } from "@/lib/opacity-fade";

/** A white-to-transparent alpha mask, not a white paint overlay. */
export default function OpacityFadeMask({ layer, id }: { layer: DesignLayer; id: string }) {
  const fade = layer.opacityFade;
  if (!fade) return null;
  const { width, height, effects } = layer;
  // The layer transform also flips its content. Compensate so the fade handles
  // still describe the visible direction after a horizontal/vertical flip.
  const x = (v: number) => (effects?.flipX ? 1 - v : v) * width;
  const y = (v: number) => (effects?.flipY ? 1 - v : v) * height;
  const pad = Math.max(24,
    (effects?.shadow?.blur || 0) * 4 + Math.max(Math.abs(effects?.shadow?.x || 0), Math.abs(effects?.shadow?.y || 0)),
    (effects?.glow?.blur || 0) * 5,
    (effects?.outline?.width || 0) * 2,
    (effects?.blur || 0) * 4,
  );
  return <defs>
    <linearGradient id={`${id}-axis`} gradientUnits="userSpaceOnUse" x1={x(fade.start.x)} y1={y(fade.start.y)} x2={x(fade.end.x)} y2={y(fade.end.y)} spreadMethod="pad">
      {opacityFadeStops(fade).map((stop, i) => <stop key={i} offset={stop.offset} stopColor="#ffffff" stopOpacity={stop.alpha} />)}
    </linearGradient>
    <mask id={id} maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" x={-pad} y={-pad} width={width + pad * 2} height={height + pad * 2} style={{ maskType: "alpha" }}>
      <rect x={-pad} y={-pad} width={width + pad * 2} height={height + pad * 2} fill={`url(#${id}-axis)`} />
    </mask>
  </defs>;
}
