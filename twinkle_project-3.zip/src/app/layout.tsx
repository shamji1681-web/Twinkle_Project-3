import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Creato — A little idea. Endless possibilities.",
  description:
    "Your ideas, beautifully made. Discover editable templates, create your next great design, and keep everything together in your personal creative space.",
  applicationName: "Creato",
  icons: [{ rel: "icon", type: "image/svg+xml", url: "/icon.svg" }],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
