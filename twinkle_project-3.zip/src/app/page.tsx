"use client";

import dynamic from "next/dynamic";

// The design studio is fully client-side (canvas, localStorage workspace, WASM tooling),
// so it is loaded without SSR.
const CreatoApp = dynamic(() => import("@/App"), { ssr: false });

export default function HomePage() {
  return <CreatoApp />;
}
